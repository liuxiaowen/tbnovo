package edu.iupui.proteomics.spec.deconvsp.reader;

import java.io.File;
import java.io.PrintWriter;


import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;

public class MsAlignSelectSpByPrecMass {
    public static void main(String[] args) throws Exception {

        String fileName = args[0];
        double precMass = Double.parseDouble(args[1]);
        double shift = Double.parseDouble(args[2]);

        Ms<DeconvPeak> sp[];
        MsAlignReader reader = new MsAlignReader(new File(fileName));
        PrintWriter out = new PrintWriter(fileName + "_selection_" + precMass);
        while ((sp = reader.getNextMses()) != null) {
            MsHeader header = sp[0].getHeader();
            double diff = Math.abs(precMass - header.getPrecMonoMass());
            if (diff < 0.5) {
                String str[] = reader.getSpectrumStr();
                out.println("BEGIN IONS");
                for (int i = 0; i < 3; i++) {
                	out.println(str[i]);
                }
                String strMz = str[3];
                String words[] = strMz.split("=");
                double mz = Double.parseDouble(words[1]);

                String strCharge = str[4];
                words = strCharge.split("=");
                int charge = Integer.parseInt(words[1]);
                double newMz = mz + shift/charge;
                
                String strMass = str[5];
                words = strMass.split("=");
                double mass = Double.parseDouble(words[1]);
                double newMass = mass + shift;
                
                out.println("PRECURSOR_MZ=" + newMz);
                out.println(strCharge);
                out.println("PRECURSOR_MASS=" + newMass);
                
                for (int i = 7; i < str.length; i++) {
                    out.println(str[i]);
                }
                out.println("END IONS");
                out.println();

            }
        }
        out.close();
    }

}
