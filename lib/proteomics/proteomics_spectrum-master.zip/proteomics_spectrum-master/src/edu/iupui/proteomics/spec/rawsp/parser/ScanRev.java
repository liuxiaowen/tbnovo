package edu.iupui.proteomics.spec.rawsp.parser;

import java.io.Serializable;


/**
 * A simple class to hold the contents of a scan from a MSXML file.
 * 
 * This is a start. For those who want to get more fancy you should only have to
 * modify the SAX2ScanHandler to replace this.
 * 
 * Note: doubleMassList and doubleIntensityList are separate entities from the
 * components of massIntensityList. dhmay noting this on 2009/03/10 but not
 * touching it, in case there are unknown dependencies on this separation.
 * 
 */
public final class ScanRev implements Serializable {

    private static final long serialVersionUID = 1L;

    public ScanHeaderRev header;

    /**
     * A 2-dimensional array, element 0 contains a list of masses of peaks,
     * element 1 contains a list of intensities of peaks.
     */

    /**
     * No matter 32-bit or 64-bit peak pair, return as double list. Support
     * mzXML
     */
    protected double[][] massIntensityList;

    /**
     * No matter 32-bit m/z or 64 bit m/z return as a double list Support for
     * mzML
     */
    public double[] doubleMassList = null;
    public double[] doubleIntensityList = null;

    public void setHeader(ScanHeaderRev header) {
        this.header = header;
    }

    public ScanHeaderRev getHeader() {
        return header;
    }

    public void setDoubleMassList(double[] newValue) {
        doubleMassList = newValue;
    }

    public double[] getDoubleMassList() {
        return doubleMassList;
    }

    public void setDoubleIntensityList(double[] newValue) {
        doubleIntensityList = newValue;
    }

    public double[] getDoubleIntensityList() {
        return doubleIntensityList;
    }

    public double[][] getMassIntensityList() {
        return massIntensityList;
    }

    /**
     * String respresentation of a Scan object.
     * 
     * Note: This is most likely not an optimal way to build the string.
     * Hopefully this method will only be used for testing.
     */
    public String toString() {
        StringBuffer tmpStrBuffer = new StringBuffer();
        tmpStrBuffer
                .append("================================================\n");
        tmpStrBuffer.append("peaks:\n");

        if (doubleMassList != null) {
            for (int i = 0; i < doubleMassList.length; i++)
                tmpStrBuffer.append("    mass="
                        + String.format("%.6f", doubleMassList[i])
                        + "    intensity="
                        + String.format("%.6f", doubleIntensityList[i]) + "\n");
        }

        else {
            for (int i = 0; i < massIntensityList[0].length; i++)
                tmpStrBuffer
                        .append("    mass="
                                + String
                                        .format("%.6f", massIntensityList[0][i])
                                + "   intensity="
                                + String
                                        .format("%.6f", massIntensityList[1][i])
                                + "\n");

        }

        return (header.toString() + tmpStrBuffer.toString());
    }

    /****************************************
     * modified by Xiaowen Liu
     ***************************************/

    public void setMassIntensityList(double[][] massIntensityList) {
        this.massIntensityList = massIntensityList;
        if (massIntensityList != null) {
            doubleMassList = massIntensityList[0];
            doubleIntensityList = massIntensityList[1];
        }
    }

    public float[] getFloatMassList() {
        float mass_list[] = new float[massIntensityList[0].length];
        for (int i = 0; i < massIntensityList[0].length; i++) {
            mass_list[i] = (float) massIntensityList[0][i];
        }
        return mass_list;
    }

    public float[] getFloatIntensityList() {
        float inte_list[] = new float[massIntensityList[1].length];
        for (int i = 0; i < massIntensityList[1].length; i++) {
            inte_list[i] = (float) massIntensityList[1][i];
        }
        return inte_list;
    }

}
