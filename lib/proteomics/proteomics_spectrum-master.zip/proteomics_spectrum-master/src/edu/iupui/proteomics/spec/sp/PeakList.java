/**
 * Describes a peak list.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.sp;

import java.util.ArrayList;
import java.util.Collections;

import edu.iupui.proteomics.spec.peak.IntensityComparator;
import edu.iupui.proteomics.spec.peak.Peak;
import edu.iupui.proteomics.spec.peak.PositionComparator;


public class PeakList<T extends Peak> extends ArrayList<T> {

	private static final long serialVersionUID = 1L;

	public PeakList() {
	}

	public PeakList(T peaks[]) {
		for (int i = 0; i < peaks.length; i++) {
			add(peaks[i]);
		}
		sortOnPos();
	}

	public PeakList(ArrayList<T> peaks) {
		for (int i = 0; i < peaks.size(); i++) {
			add(peaks.get(i));
		}
		sortOnPos();
	}

	public T findHighestPeak() {
		int idx = findHighestPeakIdx();
		if (idx >= 0) {
			return get(idx);
		} else {
			return null;
		}
	}

	public int findHighestPeakIdx() {
		int idx = -1;
		for (int i = 0; i < size(); i++) {
			if (idx < 0 || get(i).getIntensity() > get(idx).getIntensity()) {
				idx = i;
			}
		}
		return idx;
	}

	public double findMaxPos() {
		sortOnPos();
		return get(size() - 1).getPosition();
	}

	/**
	 * Sorts peaks based on position.
	 */
	public void sortOnPos() {
		Collections.sort(this, new PositionComparator());
	}

	/**
	 * Sorts peaks based on intensity.
	 */
	public void sortOnIntensity() {
		Collections.sort(this, new IntensityComparator());
	}

	public int searchPos(Peak peak) throws Exception {
		int rank = Collections.binarySearch(this, peak, new PositionComparator());
		if (rank < 0) {
			rank = -rank - 1;
		}
		return rank;
	}

	/**
	 * Finds the highest peak for a specific position with error tolerance.
	 * 
	 * @param pos
	 *            A given peak position.
	 * 
	 * @param tolerance
	 *            An error tolerance value.
	 * 
	 * @returns The highest peak for "pos" with error tolerance "tolerance".
	 */
	public int getHighPeakIdx(Peak peak, double tolerance) throws Exception {
		/* find the peak nearest to pos */
		double pos = peak.getPosition();
		int idx = searchPos(peak);
		int bestIdx = -1;
		/* extend to left */
		int i = idx - 1;
		while (i >= 0 && Math.abs(get(i).getPosition() - pos) <= tolerance) {
			if (bestIdx < 0
					|| get(i).getIntensity() > get(bestIdx).getIntensity()) {
				bestIdx = i;
			}
			i--;
		}
		/* extend to right */
		i = idx;
		while (i < size() && Math.abs(get(i).getPosition() - pos) <= tolerance) {
			if (bestIdx < 0
					|| get(i).getIntensity() > get(bestIdx).getIntensity()) {
				bestIdx = i;
			}
			i++;
		}
		return bestIdx;
	}

	/**
	 * Finds the nearest peak for a specific position with error tolerance.
	 * 
	 * @param pos
	 *            A given peak position.
	 * 
	 * @param tolerance
	 *            An error tolerance value.
	 * 
	 * @returns The highest peak for "pos" with error tolerance "tolerance".
	 */
	public int getNearPeakIdx(Peak peak, double tolerance) throws Exception {
		/* find the peak nearest to pos */
		int idx = searchPos(peak);
		double pos = peak.getPosition();
		int bestIdx = -1;
		/* extend to left */
		for (int i = idx - 1; i <= idx + 1; i++) {
			if (i >= 0 && i < size()) {
				double dist = Math.abs(pos - get(i).getPosition());

				if (Math.abs(dist) <= tolerance) {
					if (bestIdx < 0
							|| dist < Math
									.abs(get(bestIdx).getPosition() - pos)) {
						bestIdx = i;
					}
				}
			}
		}
		return bestIdx;
	}

	/**
	 * Removes all peaks in [center-interval, center+interval]
	 */
	public void rmPeaks(double center, double interval) {
		for (Peak p : this) {
			if (Math.abs(p.getPosition() - center) <= interval) {
				remove(p);
			}
		}
	}

	public void rmZeroPeaks() {
		for (Peak p : this) {
			if (p.getIntensity() == 0) {
				remove(p);
			}
		}
	}

	/**
	 * Removes a list of peaks.
	 * 
	 * @param isKeeps
	 *            If is_keep[i] == true, the ith peak will be kept.
	 */
	public void rmPeaks(boolean isKeeps[]) {
		ArrayList<T> rmPeaks = new ArrayList<T>();
		for (int i = 0; i < size(); i++) {
			if (!isKeeps[i]) {
				rmPeaks.add(get(i));
			}
		}
		for (T p : rmPeaks) {
			this.remove(p);
		}
	}

	/**
	 * Removes precursor mass. In top down data, one peak may be split to two
	 * peaks. try to combine them together.
	 * 
	 * @param tolerance
	 *            The error tolerance for combining two peaks.
	 */
	public void rmClosePeaks(double tolerance) {
		sortOnPos();
		for (int i = 0; i < size() - 1; i++) {
			T pA = get(i);
			T pB = get(i + 1);
			if (Math.abs(pA.getPosition() - pB.getPosition()) <= tolerance) {
				double a = pA.getIntensity();
				double b = pB.getIntensity();
				if (a > b) {
					pA.setIntensity(a + b);
					pB.setIntensity(0);
				} else {
					pA.setIntensity(0);
					pB.setIntensity(a + b);
				}
			}
		}
		rmZeroPeaks();
	}

	/* get functions */
	public double[] getIntensities() {
		double intensities[] = new double[this.size()];
		for (int i = 0; i < size(); i++) {
			intensities[i] = get(i).getIntensity();
		}
		return intensities;
	}

	public double getIntensity(int i) {
		return get(i).getIntensity();
	}

	public double getPosition(int i) throws Exception {
		return get(i).getPosition();
	}

	public double[] getPositions() {
		double mzs[] = new double[size()];
		for (int i = 0; i < size(); i++) {
			mzs[i] = get(i).getPosition();
		}
		return mzs;
	}

	/* set functions */
	public void setIntensities(double intensities[]) {
		for (int i = 0; i < size(); i++) {
			get(i).setIntensity(intensities[i]);
		}
	}
}
