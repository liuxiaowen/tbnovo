package edu.iupui.proteomics.spec.rawsp.simplereader;

import org.apache.log4j.Logger;


import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.rawsp.parser.MzXmlParserRev;
import edu.iupui.proteomics.spec.rawsp.parser.ScanHeaderRev;
import edu.iupui.proteomics.spec.rawsp.parser.ScanRev;
import edu.iupui.proteomics.spec.sp.MsHeader;
import edu.iupui.proteomics.spec.sp.PeakList;


public class MzXmlSingleSimpleReader extends MsSimpleReader {
    private static Logger logger = Logger.getLogger(MzXmlSingleSimpleReader.class);
    
    protected String fileName;
    protected MzXmlParserRev parser;
    protected int nextScanNum;
    
    public MzXmlSingleSimpleReader() throws Exception {
    	
    }

    public MzXmlSingleSimpleReader(String fileName) throws Exception {
    	super();
    	this.fileName = fileName;
        parser = new MzXmlParserRev(fileName);
        nextIdNum = 1; // inherited from MsReader
        nTotal = parser.getScanCount();
        nextScanNum = 1;
    }

    public MzXmlSingleSimpleReader(String fileName, int start, int end)
            throws Exception {
        parser = new MzXmlParserRev(fileName);    

        nextIdNum = start;
        nTotal = end;
    }

    public void readNext() throws Exception {
        ScanRev currentScan = null;
        int scanNum;
        double mzs[];
        double intensities[];

        peakList = null;
        header = null;
        boolean success = false;
        while (!success) {
            try {
                if (nextIdNum > nTotal) {
                    return;
                }
                //System.out.println("\n start rap " + nCurrent + " total number " + nTotal);
                while (currentScan == null) {
                    currentScan = parser.rap(nextScanNum);
                    nextScanNum++;
                    if (nextScanNum > 2 * nTotal) {
                        logger.error("Only " + nextIdNum + " spectra in " + nTotal + " spectra were found!"); 
                        return;
                    }
                }
                scanNum = currentScan.getHeader().getNum();
                mzs = currentScan.getDoubleMassList();
                intensities = currentScan.getDoubleIntensityList();
                peakList = new PeakList<RawPeak>(RawPeak.getRawPeaks(mzs, intensities));
                ScanHeaderRev h = currentScan.getHeader();
                if (h.getMsLevel() == 2) {
                    float precMz = h.getPrecursorMz();
                    if (precMz < 0) {
                        precMz = 0;
                    }
                    int precCharge = h.getPrecursorCharge();
                    if (precCharge < 0) {
                        precCharge = 1;
                    }
                    header = new MsHeader(h.getNum(), h.getMsLevel(), precCharge);
                    header.setFileName(fileName);
                    header.setTitle("Scan_" + scanNum);
                    header.setScan(scanNum);
                    /* here is average mz */
                    header.setPrecSpMz(precMz);
                    header.setActivationType(h.getPrecursorActivationMethod());
                    header.setRetentionTime(h.getRetentionTime());
                } else {
                    header = new MsHeader(h.getNum(), h.getMsLevel(), 0);
                    header.setFileName(fileName);
                    header.setTitle("Scan_" + scanNum);
                    header.setScan(scanNum);
                    header.setRetentionTime(h.getRetentionTime());
                }

                nextIdNum++;
                success = true;
                //System.out.println("\n end rap " + nCurrent);
            }
            catch (Exception e) {
            	e.printStackTrace();
                logger.error(e);
                nextIdNum++;
            }
        }
    }

}
