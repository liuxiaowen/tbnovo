package edu.iupui.proteomics.spec.extendsp;

import java.util.List;

import org.jdom.Element;

import edu.iupui.proteomics.base.util.XmlUtil;

public class ExtendSpPara {
	// if the mass is smaller than extendMinMass, the peak is not extended 
	public double extendMinMass;
	
	public double extOffsets[];
	
	public ExtendSpPara(double extendMinMass, double extOffsets[]) {
		this.extendMinMass = extendMinMass;
		this.extOffsets = extOffsets;
	}
	
	public ExtendSpPara(Element element) {
		extendMinMass = Double.parseDouble(element.getChildText("extend_min_mass"));
		@SuppressWarnings("unchecked")
		List<Element> offsetList = element.getChild("extend_offset_list").getChildren();
		extOffsets = new double[offsetList.size()];
		for (int i = 0; i < offsetList.size(); i++) {
			extOffsets[i] = Double.parseDouble(offsetList.get(i).getText());
		}
	}
	
	public Element toXml() {
		Element element = new Element("extend_sp_para");
		XmlUtil.addElement(element, "extend_min_mass", extendMinMass);
		Element offsetList = new Element("extend_offset_list");
		for (int i = 0; i < extOffsets.length; i++) {
			XmlUtil.addElement(offsetList, "extend_offset", extOffsets[i]);
		}
		element.addContent(offsetList);
		return element;
	}
}
