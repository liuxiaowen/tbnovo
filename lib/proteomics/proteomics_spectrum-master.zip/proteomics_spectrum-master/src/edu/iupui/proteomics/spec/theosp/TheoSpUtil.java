package edu.iupui.proteomics.spec.theosp;

import edu.iupui.proteomics.base.ion.BreakPoint;
import edu.iupui.proteomics.base.ion.EnumActivation;
import edu.iupui.proteomics.base.ion.EnumIonType;
import edu.iupui.proteomics.base.ion.EnumNeutralLoss;
import edu.iupui.proteomics.base.ion.Ion;
import edu.iupui.proteomics.base.theosp.BpSpec;

import edu.iupui.proteomics.spec.sp.Ms;


public class TheoSpUtil {

	public static TheoPeak[] getTheoPeaks(BpSpec pep, EnumActivation type,
			double nTermShift, double cTermShift, int bgn, int end,
			double minMass) {

		BreakPoint[] bps = pep.getExtBps();
		Ms<TheoPeak> ms = new Ms<TheoPeak>();
		double newSeqMass = pep.getResSeq().getSeqMass() + nTermShift
				+ cTermShift;
		EnumIonType nIonType = type.getNIonType();
		for (int i = bgn; i <= end; i++) {
			double nMass = bps[i].getNTermMass(type);
			double newMass = nMass + nTermShift;
			if (newMass >= minMass && newMass <= newSeqMass - minMass) {
				Ion ion = new Ion(nIonType, EnumNeutralLoss.NONE, 0, i, i);
				ms.add(new TheoPeak(ion, nMass, nTermShift));
			}
		}
		EnumIonType cIonType = type.getCIonType();
		for (int i = bgn; i <= end; i++) {
			double cMass = bps[i].getCTermMass(type);
			double newMass = cMass + cTermShift;
			if (newMass >= minMass && newMass <= newSeqMass - minMass) {
				Ion ion = new Ion(cIonType, EnumNeutralLoss.NONE, 0, i,
						bps.length - i - 1);
				ms.add(new TheoPeak(ion, cMass, cTermShift));
			}
		}
		ms.sortOnPos();
		return ms.toArray(new TheoPeak[0]);
	}
}
