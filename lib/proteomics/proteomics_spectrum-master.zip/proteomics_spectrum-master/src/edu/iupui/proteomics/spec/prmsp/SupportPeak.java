/**
 * A supporting peak of a PRM peak.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.prmsp;

import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;

public class SupportPeak {

	private DeconvPeak peak;
	private double offset;
	/* base_type: 0 for m and 1 for M-m */
	private EnumSupportPeakType peakType;
	private double score;

	public SupportPeak(DeconvPeak peak, double offset, EnumSupportPeakType peakType, double score) {
		this.peak = peak;
		this.offset = offset;
		this.peakType = peakType;
		this.score = score;
	}
	
	public EnumSupportPeakType getPeakType() {
		return peakType;
	}

	public double getOffset() {
		return offset;
	}

	public DeconvPeak getPeak() {
		return peak;
	}

	public double getScore() {
		return score;
	}
}
