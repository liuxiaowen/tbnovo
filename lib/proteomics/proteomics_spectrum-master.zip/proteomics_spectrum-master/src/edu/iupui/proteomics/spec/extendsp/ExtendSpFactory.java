package edu.iupui.proteomics.spec.extendsp;

import java.util.ArrayList;
import java.util.Arrays;


import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.deconvsp.DeconvSpFactory;
import edu.iupui.proteomics.spec.peak.PeakTolerance;
import edu.iupui.proteomics.spec.peak.PositionComparator;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;
import edu.iupui.proteomics.spec.sp.SpPara;

public class ExtendSpFactory {

	/**************************************
	 * Get Sp Three
	 **************************************/

	public static Ms<ExtendPeak> getMsThree(Ms<DeconvPeak> deconvMs,
			double delta, SpPara spPara) throws Exception {

		MsHeader header = DeconvSpFactory.getDeltaHeader(delta, deconvMs);
		DeconvPeak peaks[] = deconvMs.toArray(new DeconvPeak[0]);

		ExtendPeak extendPeaks[] = getSpThreeExtendPeak(peaks, header,
				spPara.getMinMass(), spPara.getExtendSpPara());
		msThreeSetTolerance(extendPeaks, header.getPrecMonoMass(),
				spPara.getPeakTolerance());
		return new Ms<ExtendPeak>(extendPeaks, header,
				spPara.getPeakTolerance());

	}

	/*******************
	 * private functions
	 *******************/

	/**
	 * generate type 3 PRM peak list: +/-1 Da shift is considered and do not
	 * consider activeTtype, do not add 0 and precursor mass.
	 */
	private static ExtendPeak[] getSpThreeExtendPeak(DeconvPeak peaks[],
			MsHeader header, double spMinMass, ExtendSpPara para)
			throws Exception {

		double precMonoMass = header.getPrecMonoMass();
		ArrayList<ExtendPeak> list = new ArrayList<ExtendPeak>();
		for (int i = 0; i < peaks.length; i++) {
			if (peaks[i].getMonoMass() <= para.extendMinMass) {
				double origMass = peaks[i].getMonoMass();
				ExtendPeak newPeak = new ExtendPeak(peaks[i], origMass, 1);
				list.add(newPeak);
			} else {
				for (int j = 0; j < para.extOffsets.length; j++) {
					double mass = peaks[i].getMonoMass() + para.extOffsets[j];
					ExtendPeak newPeak = new ExtendPeak(peaks[i], mass, 1);
					list.add(newPeak);
				}
			}
		}
		filterExtendPeak(list, spMinMass, precMonoMass);
		/* sort by mass */
		ExtendPeak extPeaks[] = list.toArray(new ExtendPeak[0]);
		Arrays.sort(extPeaks, new PositionComparator());
		return extPeaks;
	}

	/** remove peaks near 0 and prec mass */
	private static void filterExtendPeak(ArrayList<ExtendPeak> list,
			double blankMass, double precMass) {
		ExtendPeak peaks[] = list.toArray(new ExtendPeak[0]);
		for (int i = 0; i < peaks.length; i++) {
			double mass = peaks[i].getPosition();
			if (mass < blankMass || mass > precMass - blankMass) {
				list.remove(peaks[i]);
			}
		}
	}

	private static void msThreeSetTolerance(ExtendPeak peaks[],
			double precMass, PeakTolerance peakTolerance) {
		for (int i = 0; i < peaks.length; i++) {
			/* if peak is m */
			peaks[i].setOrigTolerance(peakTolerance
					.compStrictErrorTole(peaks[i].getBasePeak().getMonoMass()));
			peaks[i].setReverseTolerance(peakTolerance.compRelaxErrorTole(
					peaks[i].getBasePeak().getMonoMass(), precMass));
		}
	}
}
