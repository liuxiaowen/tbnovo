/**
 * Export Mass spectrum to puf format
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.iupui.proteomics.spec.deconvsp.writer;

import java.io.PrintWriter;
import java.io.FileOutputStream;

import edu.iupui.proteomics.base.ion.EnumActivation;

import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.sp.Ms;


public class PufWriter {

    PrintWriter out = null;

    public PufWriter(String fileName) throws Exception {
        /* output mgf file */
        PrintWriter out = new PrintWriter(new FileOutputStream(fileName));
        writePufHead(out);
    }

    public void close() {
        writePufTail(out);
        out = null;
    }

    public static void writePufHead(PrintWriter out) {
        out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        out.println("<data_set owner=\"\" type=\"\" version=\"1\">");
    }

    public static void writePufTail(PrintWriter out) {
        out.println("</data_set>");
    }

    /**
     * Write an MatchEnv List to a text file.
     * 
     * @throws Exception
     *             TODO
     */
    public static void writePuf(String fileName, int id, Ms<DeconvPeak> ms)
            throws Exception {
        /* output mgf file */
        PrintWriter out = new PrintWriter(new FileOutputStream(fileName));
        writePufHead(out);
        writeExpe(out, id, ms);
        writePufTail(out);
        out.close();
    }

    public static void writeExpe(PrintWriter out, int id, Ms<DeconvPeak> ms)
            throws Exception {

        out.println("<ms-ms_experiment id=\"" + ms.getHeader().getScansString() + "\" source=\"\">");
        out.println("<comment />");
        out.println("<instrument_data>");
        if (ms.getHeader().getActivationType() == EnumActivation.CID || ms.getHeader().getActivationType() == EnumActivation.HCD) {
            out.println("<fragmentation_method>CID</fragmentation_method>");
            out.println("<ion_type>BY</ion_type>");
        }
        else {
            out.println("<fragmentation_method>ETD</fragmentation_method>");
            out.println("<ion_type>CZ</ion_type>");
        }
        writeIntact(out, ms.getHeader().getPrecMonoMass());
        writeFragList(out, ms);
        out.println("</instrument_data>");
        out.println("<analysis id=\"0\" type=\"null\">");
        out.println("<comment>Null Search</comment>");
        out.println("</analysis>");
        out.println("</ms-ms_experiment>");
    }

    private static void writeIntact(PrintWriter out, double mono_mass) {
        out.println("<intact_list>");
        out.println("<intact id=\"1\">");
        out.println("<mz_monoisotopic>0</mz_monoisotopic>");
        out.println("<mz_average>0</mz_average>");
        out.println("<mass_monoisotopic>" + mono_mass + "</mass_monoisotopic>");
        out.println("<mass_average>0</mass_average>");
        out.println("<intensity>1</intensity>");
        out.println("</intact>");
        out.println("</intact_list>");
    }

    private static void writeFragList(PrintWriter out, Ms<DeconvPeak> ms) throws Exception {
        out.println("<fragment_list>");
        for (int i = 0; i < ms.size(); i++) {
            writeFrag(out, i + 1, ms.getPosition(i), ms.getIntensity(i));
        }
        out.println("</fragment_list>");
    }

    private static void writeFrag(PrintWriter out, int id, double mono_mass,
            double inte) {
        out.println("<fragment id=\"" + id + "\">");
        out.println("<mz_monoisotopic>0</mz_monoisotopic>");
        out.println("<mz_average>0</mz_average>");
        out.println("<mass_monoisotopic>" + mono_mass + "</mass_monoisotopic>");
        out.println("<mass_average>0</mass_average>");
        out.println("<intensity>" + inte + "</intensity>");
        out.println("</fragment>");
    }
}
