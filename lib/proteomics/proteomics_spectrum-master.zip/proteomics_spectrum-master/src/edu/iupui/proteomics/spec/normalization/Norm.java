/**
 * Implements several mass intensity normalization functions.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.normalization;

import java.util.Arrays;


import org.apache.log4j.Logger;

import edu.iupui.proteomics.base.util.BioArray;
import edu.iupui.proteomics.base.util.QuickSort;

public class Norm {
    private static Logger logger = Logger.getLogger(Norm.class);

    /** average residue mass */
    public final static double AVG_RES_MASS = 121.71f;

    /*
     * 1. Normalization based on GLOBAL RANK.
     */

    /**
     * Gets the global rank of each peak, the rank for the highest peak is 0.
     * 
     * @param intensities
     *            An intensity list of a spectrum.
     * 
     * @return The global ranks for each peak.
     */
    private static int[] getGlblRank(double intensities[]) {
        int sortIds[] = new int[intensities.length];
        double sortIntensities[] = (double[]) intensities.clone();
        for (int i = 0; i < intensities.length; i++) {
            sortIds[i] = i;
        }
        QuickSort.sortOnFirst(sortIntensities, sortIds);
        int rank[] = new int[intensities.length];
        for (int i = 0; i < intensities.length; i++) {
            rank[sortIds[i]] = intensities.length - i - 1;
        }
        return rank;
    }

    /**
     * Gets the global rank of the (coef * intesity) of each peak.
     * 
     * @param intensities
     *            An intensity list of a spectrum.
     * 
     * @param coef
     *            An coefficient factor.
     * 
     * @return The global ranks for each peak.
     */
    private static int[] getGlblRank(double intensities[], double coef) {
        /* sort */
        double sortIntensities[] = (double[]) intensities.clone();
        Arrays.sort(sortIntensities);
        int rank[] = new int[intensities.length];
        for (int i = 0; i < intensities.length; i++) {
            rank[i] = intensities.length - 1
                    - BioArray.search(sortIntensities, intensities[i] * coef);
            /*
             * when coef > 1.0 and inte[i]*coef > max_inte, BinarySearch.search
             * return inte.length, in this case, rank[i] = -1, so we need to
             * correct it.
             */
            if (rank[i] < 0) {
                rank[i] = 0;
            }
        }
        return rank;
    }

    /**
     * Gets the rank of each peak. Then normalize based of the breakage point
     * number of the peptide, then gets logrithm.
     * 
     * @param intensities
     *            An intensity list of a spectrum.
     * 
     * @param brkNum
     *            The breakage point number of the corresponding peptide.
     * 
     * @return The normalized global ranks for each peak.
     */
    public static double[] getNormGlblRank(double intensities[], int brkNum) {
        /* use original peak intensity coef = 1.0 */
        int ranks[] = getGlblRank(intensities);
        double result[] = new double[ranks.length];
        for (int i = 0; i < ranks.length; i++) {
            result[i] = (double) Math.log((double) ranks[i] / brkNum + 1.0);
        }
        return result;
    }

    /**
     * Gets the rank of each peak. Then normalize based of the estimated
     * breakage number of the peptide, then gets logrithm.
     * 
     * @param intensities
     *            An intensity list of a spectrum.
     * 
     * @param total_res_mass
     *            The sum of residue masses of the spectrum.
     * 
     * @return The normalized global ranks for each peak.
     */
    public static double[] getNormGlblRank(double intensities[],
            double totalResidueMass) {
        int brkNum = (int)Math.round(totalResidueMass / AVG_RES_MASS) - 1;
        if (brkNum == 0) {
            brkNum = 1;
        }
        return getNormGlblRank(intensities, brkNum);
    }

    /*
     * 2. Normalization based on LOCAL RANK.
     */

    /**
     * Gets the local [-span, span] rank of the (coef * intesity) of each peak.
     * 
     * @param mzs
     *            m/z list of peaks.
     * 
     * @param intensities
     *            An intensity list of peaks.
     * 
     * @param coef
     *            An coefficient when the peak intensity is ranked.
     * 
     * @param span
     *            An interval [-span, span] where the peaks are considered.
     * 
     * @return The local rank for each peak.
     */
    public static int[] getLoclRank(double[] mzs, double[] intensities,
            double coef, double span) {
        int localRanks[] = new int[intensities.length];
        /* consider each peak and its corresponding interval */
        double p, mzLeft, mzRight;
        /*
         * the nubmer of peaks with higher intensity than peak i in the interval
         */
        int nGreat;
        for (int i = 0; i < intensities.length; i++) {
            p = mzs[i];
            mzLeft = p - span;
            mzRight = p + span;
            /* count the number */
            /* consider peak i */
            nGreat = 0;
            /* consider the peaks to the left of peak i */
            int j = i - 1;
            while (j >= 0 && mzs[j] >= mzLeft) {
                if (intensities[j] > intensities[i] * coef) {
                    nGreat++;
                }
                j--;
            }
            /* consider the peaks to the right of peak i */
            j = i + 1;
            while (j < intensities.length && mzs[j] <= mzRight) {
                if (intensities[j] > intensities[i] * coef) {
                    nGreat++;
                }
                j++;
            }
            localRanks[i] = nGreat;
        }
        return localRanks;
    }

    /**
     * Gets the local [-span, span] rank of each peak. Then logrithm is used for
     * normalization.
     * 
     * @param mzs
     *            An m/z list of peaks.
     * 
     * @param intensities
     *            An intensity list of peaks.
     * 
     * @param span
     *            An interval [-span, span] where the peaks are considered.
     * 
     * @return The normalized local rank for each peak.
     */
    public static double[] getNormLoclRank(double mzs[], double intensities[],
            double span) {
        /* use original peak intensity coef = 1.0 */
        int ranks[] = getLoclRank(mzs, intensities, 1.0f, span);
        double result[] = new double[ranks.length];
        for (int i = 0; i < ranks.length; i++) {
            result[i] = (double) Math.log((double) ranks[i] + 1.0);
        }
        return result;
    }

    /*
     * 3. Normalization based on GLOBAL MAXIMUM INTENSITY
     */

    /**
     * Gets the normalized intensity of all peaks with log(max_inte/inte) For
     * the maximum intensity, the score is 0.
     * 
     * @param intensities
     *            An intensity list of peaks.
     * 
     * @param maxIntensity
     *            A reference maximum intensity.
     * 
     * @return normalized intensity for each peak.
     */
    public static double[] getGlblInteLogRatio(double intensities[],
            double maxIntensity) {
        if (maxIntensity <= 0.0) {
            logger.warn("Negative maximum intensity.");
        }
        /* get the relative intensity of each peak as normalized intensity */
        double logRatio[] = new double[intensities.length];
        for (int i = 0; i < intensities.length; i++) {
            /*
             * In some cases, we use the second highest intensity as max_inte so
             * the following IF is necessary.
             */
            if (maxIntensity < intensities[i]) {
                logRatio[i] = 0;
            } else {
                logRatio[i] = (double) Math.log(maxIntensity / intensities[i]);
            }
        }
        return logRatio;
    }

    /*
     * 4. Normalization based on LOCAL MAXIMUM INTENSITY
     */

    /**
     * Gets the normalized intensity of all peaks in [-span, span] with
     * log(max_inte/inte). For the maximum local intensity, the score is 0.
     * 
     * @param mzs
     *            An m/z list of peaks.
     * 
     * @param intensities
     *            An intensity list of peaks.
     * 
     * @param span
     *            An interval [-span, span] where peaks are considered.
     * 
     * @return normalized intensity for each peak.
     */
    public static double[] getLoclInteLogRatio(double[] mzs, double[] intensities,
            double span) {
        double logRatio[] = new double[intensities.length];
        double p, mzLeft, mzRight;
        double maxIntensity;
        /* consider each peak and its corresponding interval */
        for (int i = 0; i < intensities.length; i++) {
            p = mzs[i];
            mzLeft = p - span;
            mzRight = p + span;
            /* consider peak i */
            maxIntensity = intensities[i];
            /* consider the peaks to the left of peak i */
            int j = i - 1;
            while (j >= 0 && mzs[j] >= mzLeft) {
                if (intensities[j] > maxIntensity) {
                    maxIntensity = intensities[j];
                }
                j--;
            }
            /* consider the peaks to the right of peak i */
            j = i + 1;
            while (j < intensities.length && mzs[j] <= mzRight) {
                if (intensities[j] > maxIntensity) {
                    maxIntensity = intensities[j];
                }
                j++;
            }
            logRatio[i] = (double) Math.log(maxIntensity / intensities[i]);
        }
        return logRatio;
    }

    /*
     * 5. Normalization by change the maximum intensity
     */

    /**
     * Gets the average intensity of the remv_num + 1th .. remv_num + avg_num
     * th. Then change the intensities greater than the average intensity to the
     * average intensity.
     * 
     * @param intensities
     *            An intensity list of peaks.
     * 
     * @param nRemove
     *            An number of highest intensity peaks that will be ignored.
     * 
     * @param nAvg
     *            An number of highest intensity peaks for computing average.
     * 
     * @return modified intensity for each peak.
     */
    public static double[] normOnAvgMaxInte(double intensities[], int nRemove,
            int nAvg) {
        double sortIntensities[] = (double[]) intensities.clone();
        Arrays.sort(sortIntensities);
        /* get the average intensity */
        double sum = 0;
        for (int i = nRemove; i < nAvg; i++) {
            sum += sortIntensities[intensities.length - 1 - i];
        }
        double avg = sum / (nAvg - nRemove);
        double result[] = new double[intensities.length];
        for (int i = 0; i < intensities.length; i++) {
            if (intensities[i] > avg) {
                result[i] = avg;
            } else {
                result[i] = intensities[i];
            }
        }
        return result;
    }

    /**
     * Gets the second highest intensity whose distance to the highest intensity
     * peak is greater than span. Then change the intensities greater than the
     * sedond highest intensity to the second highest intensity.
     * 
     * @param mzs
     *            An m/z list of peaks.
     * 
     * @param intensities
     *            An intensity list of peaks.
     * 
     * @param span
     *            An distance from the highest intensity peak.
     * 
     * @return modified intensity for each peak.
     */
    public static double[] normOnSndMaxInte(double mzs[], double intensities[],
            double span) {
        double sortIntensities[] = (double[]) intensities.clone();
        int sortIds[] = new int[intensities.length];

        for (int i = 0; i < intensities.length; i++) {
            sortIds[i] = i;
        }

        QuickSort.sortOnFirst(sortIntensities, sortIds);
        double max = 0;
        int bestId = sortIds[intensities.length - 1];
        for (int i = intensities.length - 2; i >= 0; i--) {
            if (Math.abs(mzs[sortIds[i]] - mzs[bestId]) > span) {
                max = sortIntensities[i];
                break;
            }
        }

        double result[] = new double[intensities.length];
        for (int i = 0; i < intensities.length; i++) {
            if (intensities[i] > max) {
                result[i] = max;
            } else {
                result[i] = intensities[i];
            }
        }
        return result;
    }

    /*
     * 7. Normalization based on combination of the first four normalization
     * methods;
     */

    /**
     * Returns different modified intensity array based on type.
     * 
     * @param mzs
     *            An m/z list of peaks.
     * 
     * @param intensities
     *            An intensity list of peaks.
     * 
     * @param type
     *            A type for modifying highest peaks.
     * 
     * @return modified intensity for each peak.
     */
    private static double[] getCorrInte(double mzs[], double intensities[],
            EnumMaxInte type, NormMng pkgMng) {
        double result[] = null;
        if (type == EnumMaxInte.ORI) {
            result = intensities;
        } else if (type == EnumMaxInte.AVG) {
            result = normOnAvgMaxInte(intensities, pkgMng.nMaxRemove,
                    pkgMng.nMaxAvg);
        } else if (type == EnumMaxInte.SND) {
            result = normOnSndMaxInte(mzs, intensities,
                    pkgMng.removeMaxIntensitySpan);

        }
        return result;
    }

    /**
     * Returns a linear combination of different normalization results.
     * 
     * @param mzs
     *            An m/z list of peaks.
     * 
     * @param intensities
     *            An intensity list of peaks.
     * 
     * @param totalResidueMass
     *            The sum of mass of all residues in the peptide.
     * 
     * @param pkgMng
     * 
     * @return normalized intensity for each peak.
     */
    public static double[] getCombNorm(double mzs[], double intensities[],
            double totalResidueMass, NormMng pkgMng) {
        double globalRanks[] = getNormGlblRank(intensities, totalResidueMass);
        double localRanks[] = getNormLoclRank(mzs, intensities, pkgMng.localSpan);

        /* global intensity */
        double newIntensites[] = getCorrInte(mzs, intensities,
                pkgMng.globalIntensityMaxType, pkgMng);
        double globalIntensities[] = getGlblInteLogRatio(newIntensites, BioArray
                .getMax(newIntensites));

        /* local intensity */
        newIntensites = getCorrInte(mzs, intensities,
                pkgMng.localIntensityMaxType, pkgMng);
        double localIntensities[] = getLoclInteLogRatio(mzs, newIntensites,
                pkgMng.localSpan);

        /* combination */
        double result[] = new double[intensities.length];
        for (int i = 0; i < globalRanks.length; i++) {
            result[i] = pkgMng.coefGlobalRank * globalRanks[i]
                    + pkgMng.coefLocalRank * localRanks[i]
                    + pkgMng.coefGlobalIntensity * globalIntensities[i]
                    + pkgMng.coefLocalIntensity * localIntensities[i];
        }
        return result;
    }

    /******************************************************************
     * Other normailization
     *****************************************************************/

    /*
     * Gets the normalized intensity of all peaks with inte/max_inte.
     * 
     * @param intensities An intensity list of peaks.
     * 
     * @param maxIntensity A maximum intensity.
     * 
     * @return Normalized intensity list.
     */
    /*
     * private static double[] getRateInte(double intensities[], double
     * maxIntensity) { if (maxIntensity <= 0.0) {
     * logger.warn("Negative maximum intensity."); } // get the relative
     * intensity of each peak double relativeIntensities[] = new
     * double[intensities.length]; for (int i = 0; i < intensities.length; i++) {
     * relativeIntensities[i] = intensities[i]/ maxIntensity; } return
     * relativeIntensities; }
     */

    /*
     * Get the normalized intensity of all peaks with
     * log(1+inte)/log(1+max_inte)
     */
    /*
     * private static double[] getLogInte(double intensities[], double
     * maxIntensity) { if (maxIntensity <= 0.0) {
     * logger.warn("Negative maximum intensity."); } // get the relative
     * intensity of each peak as normalized intensity double logIntensities[] =
     * new double[intensities.length]; for (int i = 0; i < intensities.length;
     * i++) { logIntensities[i] =
     * (double)(Math.log(1+intensities[i])/Math.log(1+maxIntensity)); } return
     * logIntensities; }
     */

    /* initialize the normalized intensity array */
    public static double[] getCosineNormInte(double intensities[]) {
        double normIntensities[] = new double[intensities.length];
        double sum = 0;
        for (int i = 0; i < intensities.length; i++) {
            sum += intensities[i] * intensities[i];
        }
        sum = (double) Math.sqrt(sum);
        if (sum == 0) {
            sum = 1;
        }
        for (int i = 0; i < normIntensities.length; i++) {
            normIntensities[i] = intensities[i] / sum;
        }
        return normIntensities;
    }

    /** test */
    public static void main(String args[]) {
        double[] test = { 1, 5, 3, 2, 3 };
        /* test getGlblRank(inte[]) */
        int[] rank = getGlblRank(test);
        for (int i = 0; i < rank.length; i++) {
            System.out.println(i + "\t inte: " + test[i] + "\t rank: "
                    + rank[i]);
        }
        /* test getGlblRank(inte[], coef) */
        double coef;
        for (coef = 0.2f; coef <= 2.0f; coef += 0.2f) {
            rank = getGlblRank(test, coef);
            System.out.println("coef: " + coef);
            for (int i = 0; i < rank.length; i++) {
                System.out.println(i + "\t inte: " + test[i] + "\t rank: "
                        + rank[i]);
            }
        }
        /* test getGlblRank(inte[] coef, len */
        int brk_num;
        double norm_rank[];
        coef = 0.2f;
        brk_num = 10;
        norm_rank = getNormGlblRank(test, brk_num);
        System.out.println("coef: " + coef + " brk_num: " + brk_num);
        for (int i = 0; i < rank.length; i++) {
            System.out.println(i + "\t inte: " + test[i] + "\t rank: "
                    + norm_rank[i]);
        }
        coef = 0.8f;
        brk_num = 12;
        norm_rank = getNormGlblRank(test, brk_num);
        System.out.println("coef: " + coef + " brk_num: " + brk_num);
        for (int i = 0; i < rank.length; i++) {
            System.out.println(i + "\t inte: " + test[i] + "\t rank: "
                    + norm_rank[i]);
        }

        coef = 1.2f;
        brk_num = 14;
        norm_rank = getNormGlblRank(test, brk_num);
        System.out.println("coef: " + coef + " brk_num: " + brk_num);
        for (int i = 0; i < rank.length; i++) {
            System.out.println(i + "\t inte: " + test[i] + "\t rank: "
                    + norm_rank[i]);
        }

    }
}
