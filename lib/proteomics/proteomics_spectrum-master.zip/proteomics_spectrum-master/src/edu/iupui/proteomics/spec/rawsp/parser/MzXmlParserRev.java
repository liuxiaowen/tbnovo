package edu.iupui.proteomics.spec.rawsp.parser;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;

import org.systemsbiology.jrap.stax.EndPatternStringIterator;


public final class MzXmlParserRev {
    /** The file we are in charge of reading */
    protected String fileName = null;

    /** The indexes */
    protected Map<Integer, Long> offsets;
    protected int maxScan;
    protected long chrogramIndex;

    /* TAH Nov 2009 */
    int currentScanIndex;
    EndPatternStringIterator epsi = null;

    public void setEpsi(EndPatternStringIterator e) {
        this.epsi = e;
    }

    public EndPatternStringIterator getEpsi() {
        return epsi;
    }

    public MzXmlParserRev(String fileName) {
        this.fileName = fileName;
        randomInits();
    }
    
    private void randomInits() {
        //using IndexParser get indexes
        IndexParserRev indexParser = new IndexParserRev(fileName);
        indexParser.parseIndexes();
        offsets = indexParser.getOffsetMap();
        maxScan = indexParser.getMaxScan();
        chrogramIndex = indexParser.getChrogramIndex();
     }

    /* end TAH */

    private void closeFile(FileInputStream fileIN) {
        if (fileIN != null) {
            try {
                fileIN.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Read a particular scan from a MSXML file and return a generic Scan object
     * with it's data. Note: scanNumbers are 1-based, so scanNumber must be at
     * least 1 and be not greater than getScanCount() + 1
     * 
     * @return a scan object. It has all the infomation in a scanheader object
     *         and also peaks information that doesn't included in scanHeader
     *         object.
     */
    public ScanRev rap(int scanNumber) {
        FileInputStream fileIN = null;
        try {
            fileIN = new FileInputStream(fileName);
            long scanOffset = getScanOffset(scanNumber);
            if (scanOffset == -1) {
            	fileIN.close();
                return null;
            }

            fileIN.skip(scanOffset);
        } catch (Exception e) {
            System.out.println("File exception:" + e);
            e.printStackTrace();
        }

        ScanAndHeaderParserRev scanParser = new ScanAndHeaderParserRev();
        scanParser.setIsScan(true);
        scanParser.setFileInputStream(fileIN);
        scanParser.parseScanAndHeader();

        closeFile(fileIN);
        return (scanParser.getScan());
    }

    /**
     * Get the total number of scans in the mzXMLfile handled by this parser.
     * 
     * @return The number of scans.
     */
    public int getScanCount() /* TAH Nov 2009 */
    {
        if (epsi != null) { // sequential scan, index scan hasn't been run
            return maxScan;
        } else {
            return offsets.size();
        }
    } /* end TAH */

    /**
     *get scan offset, scan number is 1 based.
     */

    public long getScanOffset(int scanNumber) {
        if (scanNumber > 0 && offsets.containsKey(scanNumber)) {
            return ((offsets.get(scanNumber)).longValue());
        } else {
            return (-1);
        }
    }

}
