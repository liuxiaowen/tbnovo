package edu.iupui.proteomics.spec.deconvsp.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;


import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;
import edu.iupui.proteomics.spec.sp.PeakList;


public class PiitaReader {

    private String lines[];
    private int pos;
    private int id;
    
    protected PeakList<DeconvPeak> mzInteList = null;
    protected MsHeader header = null;
    protected Ms<DeconvPeak> deconvMs = null;
    


    public PiitaReader(File spectrumFile) throws Exception {

        BufferedReader piitaInput = new BufferedReader(new InputStreamReader(new FileInputStream(
                spectrumFile), "UTF-8"));
        ArrayList<String> lineList = new ArrayList<String>();
        String line;
        while ((line = piitaInput.readLine()) != null) {
            lineList.add(line);
        }
        piitaInput.close();
        lines = lineList.toArray(new String[0]);
        pos = 0;
        id = 0;
    }


    protected void readNext() throws Exception {
        deconvMs = null;
        mzInteList = null;
        header = null;
        
        if (pos >= lines.length) {
            return;
        }
        
        String activation = "CID";
        String title = "";

        String line = lines[pos]; 
        StringTokenizer st = new StringTokenizer(line);
        st.nextToken();
        String scan = st.nextToken();
     
        ArrayList<Double> massList = new ArrayList<Double>();
        ArrayList<Double> intensityList = new ArrayList<Double>();
        ArrayList<Integer> chargeList = new ArrayList<Integer>();
        int nextPos = pos + 1;
        for (int i = pos + 1; i < lines.length; i++) {
            if (lines[i].charAt(0) == 'P') {
                st = new StringTokenizer(lines[i]);
                st.nextToken();
                massList.add(Double.parseDouble(st.nextToken()));
                chargeList.add(Integer.parseInt(st.nextToken()));
                intensityList.add(Double.parseDouble(st.nextToken()));
                nextPos = i + 1;
            }
            else {
                break;
            }
        }
        
        header = new MsHeader();
        if (title.equals("")) {
            header.setTitle("sp_" + id);
        } else {
            header.setTitle(title);
        }
        header.setId(id);
        header.setScans(scan);
        if (!activation.equals("")) {
            header.setActivationType(activation);
        }
        DeconvPeak peaks[] = new DeconvPeak[massList.size()];
        int peakIds[] = new int[massList.size()];
        for (int i = 0; i < peakIds.length; i++) {
            peaks[i] = new DeconvPeak(i, massList.get(i), intensityList.get(i),
                    chargeList.get(i));
        }
        deconvMs = new Ms<DeconvPeak>(peaks, header);
        deconvMs.sortOnPos();
        pos = nextPos;
        id++;
    }

    public Ms<DeconvPeak> getNextMs() throws Exception {
        readNext();
        return deconvMs;
    }


    public ArrayList<Ms<DeconvPeak>> readAllMs() throws Exception {
        ArrayList<Ms<DeconvPeak>> msList = new ArrayList<Ms<DeconvPeak>>();
        Ms<DeconvPeak> deconvSp;
        while ((deconvSp = getNextMs()) != null) {
            msList.add(deconvSp);
        }
        return msList;
    }
}
