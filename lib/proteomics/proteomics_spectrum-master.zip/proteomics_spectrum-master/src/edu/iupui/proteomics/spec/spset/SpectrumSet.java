package edu.iupui.proteomics.spec.spset;

import org.apache.log4j.Logger;

import edu.iupui.proteomics.base.residue.EnumProtTermMod;

import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.extendsp.ExtendPeak;
import edu.iupui.proteomics.spec.extendsp.ExtendSpFactory;
import edu.iupui.proteomics.spec.prmsp.PrmPeak;
import edu.iupui.proteomics.spec.prmsp.PrmSpFactory;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.SpPara;

public class SpectrumSet {

	private static Logger logger = Logger.getLogger(SpectrumSet.class);

	Ms<DeconvPeak> deconvSp;
	double delta;

	/**
	 * convert one peak to two peaks: original and complimentary. used in fast
	 * computation of diagonal scores.
	 */
	Ms<PrmPeak> prmMsTwo;

	/**
	 * convert one peak to three peaks: consider +/- 1Da error
	 */
	Ms<ExtendPeak> extendMsThree;

	/**
	 * convert one peak to six peaks: all one--six extended peak.
	 */
	Ms<PrmPeak> prmMsSix;

	// used in E-value computation with N-terminal acetylation.
	Ms<PrmPeak> prmMsShiftSix;

	public SpectrumSet(Ms<DeconvPeak> sp, double delta, SpPara spPara)
			throws Exception {
		this.deconvSp = sp;
		this.delta = delta;
		prmMsTwo = PrmSpFactory.getMsTwo(deconvSp, delta, spPara);

		extendMsThree = ExtendSpFactory.getMsThree(deconvSp, delta, spPara);

		prmMsSix = PrmSpFactory.getSpSix(deconvSp, delta, spPara);

		prmMsShiftSix = PrmSpFactory.getShiftSpSix(deconvSp, delta,
				-EnumProtTermMod.ACETYLATION.getPepTermShift(), spPara);
	}

	public Ms<DeconvPeak> getDeconvMs() {
		return deconvSp;
	}

	public Ms<ExtendPeak> getSpThree() {
		return extendMsThree;
	}

	public Ms<PrmPeak> getSpTwo() {
		return prmMsTwo;
	}

	public Ms<PrmPeak> getSpSix() {
		return prmMsSix;
	}

	public Ms<PrmPeak> getSpShiftSix() {
		return prmMsShiftSix;
	}

	public double getDelta() {
		return delta;
	}

	public static SpectrumSet getSpectrumSet(Ms<DeconvPeak> spectrum,
			double delta, SpPara spPara) throws Exception {
		if (spectrum.size() < spPara.getMinPeakNum()
				|| spectrum.getHeader().getPrecMonoMass() < spPara.getMinMass()) {
			logger.trace("Spectrum " + spectrum.getHeader().getScansString()
					+ " is filtered. " + "Peak number:" + spectrum.size()
					+ " precursor mass "
					+ spectrum.getHeader().getPrecMonoMass());
			return null;
		}

		if (spectrum.getHeader().getActivationType() == null) {
			if (spPara.getActivationType() != null) {
				spectrum.getHeader().setActivationType(spPara.getActivationType());
			} else {
				logger.error("Scan " + spectrum.getHeader().getScansString()
						+ " has no activation type");
				return null;
			}
		}

		// convert input spectrum to several extended ones.
		return new SpectrumSet(spectrum, delta, spPara);
	}

}
