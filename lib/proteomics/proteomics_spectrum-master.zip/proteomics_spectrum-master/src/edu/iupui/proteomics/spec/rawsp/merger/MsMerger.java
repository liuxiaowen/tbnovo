/**
 * Several functions for Ms.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.rawsp.merger;

import java.util.ArrayList;


import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.PeakList;


public class MsMerger {
    public static boolean isSimilar(Ms<RawPeak> msA, double intensityA[],
            Ms<RawPeak> msB, double intensityB[], double maxDifference,
            double scoreThreshold, double tolerance) {
        double precMzA = msA.getHeader().getPrecSpMz();
        int precChrgA = msA.getHeader().getPrecChrg();
        double precMzB = msB.getHeader().getPrecSpMz();
        int precChrgB = msB.getHeader().getPrecChrg();
        if (precChrgA != precChrgB
                || Math.abs(precMzA - precMzB) * precChrgA > maxDifference) {
            return false;
        }
        double mz_a[] = msA.getPositions();
        double mz_b[] = msB.getPositions();
        double scr = getSimilarity(mz_a, intensityA, mz_b, intensityB,
                tolerance);
        if (scr >= scoreThreshold) {
            return true;
        } else {
            return false;
        }
    }

    /* compute similarity score between two spectra. */
    public static double getSimilarity(double mzA[], double intensityA[],
            double mzB[], double intensityB[], double tolerance) {
        int a = 0;
        int b = 0;
        double scr = 0;
        while (a < mzA.length && b < mzB.length) {
            if (Math.abs(mzA[a] - mzB[b]) < tolerance) {
                scr += intensityA[a] * intensityB[b];
                a++;
                b++;
            } else if (mzA[a] < mzB[b]) {
                a++;
            } else {
                b++;
            }
        }
        return scr;
    }

    /* compute average spectrum */
    public static PeakList<RawPeak> getAverage(Ms<RawPeak> ms,
            Ms<RawPeak> mses[], double tolerance) throws Exception {
        double avgMzs[];
        double avgIntensities[];
        avgMzs = ms.getPositions();
        avgIntensities = ms.getIntensities();
        for (int i = 0; i < mses.length; i++) {
            double mzs[] = mses[i].getPositions();
            double intensities[] = mses[i].getIntensities();
            double mzIntensities[][] = addSpec(avgMzs, avgIntensities, i + 1,
                    mzs, intensities, tolerance);
            avgMzs = mzIntensities[0];
            avgIntensities = mzIntensities[1];
        }
        RawPeak peaks[] = new RawPeak[mses.length];
        for (int i = 0; i < mses.length; i++) {
            peaks[i] = new RawPeak(avgMzs[i], avgIntensities[i]);
        }

        return new PeakList<RawPeak>(peaks);
    }

    /** add spectrum B to a merged spectrum A. A is merged from "cnt" spectra */
    private static double[][] addSpec(double mzA[], double intensityA[],
            int cnt, double mzB[], double internsityB[], double tolearance) {
        int a = 0;
        int b = 0;
        ArrayList<Double> newMzList = new ArrayList<Double>();
        ArrayList<Double> newIntensityList = new ArrayList<Double>();
        while (a < mzA.length || b < mzB.length) {
            if (a >= mzA.length) {
                newMzList.add(mzB[b]);
                newIntensityList.add(internsityB[b] / (cnt + 1));
                b++;
            } else if (b >= mzB.length) {
                newMzList.add(mzA[a]);
                newIntensityList.add(intensityA[a] * cnt / (cnt + 1));
                a++;
            } else if (Math.abs(mzA[a] - mzB[b]) < tolearance) {
                double tmpMz = mzA[a] * intensityA[a] * cnt + mzB[b]
                        * internsityB[b];
                double tmpIntensity = intensityA[a] * cnt + internsityB[b];
                /* include all peaks between mz_a[a] && mz_b[b] */
                if (mzA[a] >= mzB[b]) {
                    b++;
                    while (b < mzB.length && mzA[a] >= mzB[b]) {
                        tmpMz = tmpMz + mzB[b] * internsityB[b];
                        tmpIntensity = tmpIntensity + internsityB[b];
                        b++;
                    }
                    a++;

                } else {
                    a++;
                    while (a < mzA.length && mzA[a] <= mzB[b]) {
                        tmpMz = tmpMz + mzA[a] * intensityA[a] * cnt;
                        tmpIntensity = tmpIntensity + intensityA[a] * cnt;
                        a++;
                    }
                    b++;
                }
                newMzList.add(tmpMz / tmpIntensity);
                newIntensityList.add(tmpIntensity / (cnt + 1));
            } else if (mzA[a] < mzB[b]) {
                newMzList.add(mzA[a]);
                newIntensityList.add(intensityA[a] * cnt / (cnt + 1));
                a++;
            } else {
                newMzList.add(mzB[b]);
                newIntensityList.add(internsityB[b] / (cnt + 1));
                b++;
            }
        }
        double rslt[][] = new double[2][newMzList.size()];
        for (int i = 0; i < newMzList.size(); i++) {
            rslt[0][i] = newMzList.get(i);
            rslt[1][i] = newIntensityList.get(i);
        }
        return rslt;
    }
}
