package edu.iupui.proteomics.spec.peak;

import java.util.Comparator;

public class PositionComparator implements Comparator<Peak> {
	public int compare(Peak p1, Peak p2) {
		if (p1.getPosition() < p2.getPosition()) {
			return -1;
		} else if (p1.getPosition() > p2.getPosition()) {
			return 1;
		} else {
			return 0;
		}
	}
}
