package edu.iupui.proteomics.spec.deconvsp;

import edu.iupui.proteomics.base.residue.MassConstant;

import edu.iupui.proteomics.spec.peak.PeakUtil;
import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;
import edu.iupui.proteomics.spec.sp.SpPara;


public class DeconvSpFactory {

	public static Ms<DeconvPeak> getRefineMs(Ms<DeconvPeak> deconvSp,
			double calibration, double newPrecMass) throws Exception {
		MsHeader header = getHeader(newPrecMass, deconvSp);
		Ms<DeconvPeak> ms = new Ms<DeconvPeak>(header);
		for (int i = 0; i < deconvSp.size(); i++) {
			DeconvPeak peak = deconvSp.get(i).clone();
			peak.setPosition(peak.getPosition() * (1 + calibration));
			ms.add(peak);
		}
		return ms;
	}

	public static MsHeader getHeader(double newPrecMass,
			Ms<DeconvPeak> deconvSp) throws Exception{
		MsHeader deconvHeader = deconvSp.getHeader();
		MsHeader header = (MsHeader)deconvHeader.clone();
		double monoMz = PeakUtil.getMonoMz(newPrecMass, deconvHeader.getPrecChrg());
		header.setPrecMonoMz(monoMz);
		return header;
	}
	
    public static MsHeader getDeltaHeader(double delta, Ms<DeconvPeak> deconvSp) throws Exception {
        MsHeader deconvHeader = deconvSp.getHeader();
        MsHeader header = (MsHeader)deconvHeader.clone();
        double monoMz = deconvHeader.getPrecMonoMz() + delta
        / deconvHeader.getPrecChrg();
        header.setPrecMonoMz(monoMz);
        return header;
    }
    
	public static Ms<DeconvPeak> getDeconvMs(Ms<RawPeak> rawSp, SpPara spPara) throws Exception {
		MsHeader header = rawSp.getHeader();
		if (header.getActivationType() == null) {
			header.setActivationType(spPara.getActivationType());
		}
		Ms<DeconvPeak> ms = new Ms<DeconvPeak>(header);
		for (int i = 0; i < rawSp.size(); i++) {
			double pos = rawSp.getPosition(i) - MassConstant.getProtonMass();
			double intensity = rawSp.getIntensity(i);
			int charge = 1;
			DeconvPeak peak = new DeconvPeak(i, pos, intensity, charge);
			ms.add(peak);
		}
		return ms;
	}

}
