package edu.iupui.proteomics.spec.convert;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.rawsp.simplereader.MgfSimpleReader;
import edu.iupui.proteomics.spec.sp.Ms;


public class MgfToPuf {

    private static final Logger log = Logger.getLogger(MgfToPuf.class);

    private static final String EXPERIMENT_TAG = "ms-ms_experiment";
    private static final String FRAGMENT_LIST_TAG = "fragment_list";
    private static final String INTACT_TAG = "intact";
    private static final String FRAGMENT_TAG = "fragment";
    private static final String MASS_MONOISOTOPIC_TAG = "mass_monoisotopic";
    private static final String INTENSITY_TAG = "intensity";
    private static final String COMMENT_TAG = "comment";

    public static void main(String[] args) {
        File input = new File(args[0]);
        File output = new File(args.length > 1 ? args[1] : "");
        List<File> inputFiles = new ArrayList<File>();
        List<File> outputFiles = new ArrayList<File>();

        Collections.sort(inputFiles);

        if (input.isDirectory()) {
            output.mkdirs();
            for (File file : input.listFiles()) {
                if (file.isFile()) {
                    inputFiles.add(file);
                    outputFiles.add(new File(output, file.getName() + ".txt"));
                }
            }
        } else {
            inputFiles.add(input);
            outputFiles.add(output);
        }

        MgfToPuf pufConverter = new MgfToPuf();
        try {
            for (int i = 0; i < inputFiles.size(); i ++) {
                File inputFile = inputFiles.get(i);
                File outputFile = outputFiles.get(i);
                int[] stat = pufConverter.process(inputFile, outputFile);
                System.out.println("Stat for " + inputFile.getName() + " : " + stat[0] + " experiments, " + stat[1] + " fragments, " + stat[2] + " intacts.");
                MgfSimpleReader reader = new MgfSimpleReader(outputFile.getAbsolutePath(), true);
                Ms<RawPeak> ms = null;
                int counter = 0;
                int peakCounter = 0;
                while ((ms = reader.getNextMs())!= null) {
                    counter++;
                    peakCounter += ms.size();
                }
                System.out.printf("Found %s mass-spectrs with %s peaks in %s \n", counter, peakCounter, outputFile.getName());
                if (stat[0] != counter)
                    System.out.println("Number of mass-spectrs do not match!");
                if (stat[1] != peakCounter)
                    System.out.println("Number of peaks do not match!");

            }
        } catch (Exception e) {
            log.error("Error processing puf-file", e);
        }

    }

    public int[] process(File inputFile, File outputFile) throws Exception {
        try {
            final int[] stat = new int[3];
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();

            if (outputFile.exists())
                outputFile.delete();
            final PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFile), "UTF-8")));
            InputStreamReader in = new InputStreamReader(new FileInputStream(inputFile), "UTF-8");
            DefaultHandler handler = new DefaultHandler() {
                HashMap<String, String> data = new HashMap<String, String>();
                String currentField;
                StringBuilder currentValue;

                Stack<String> tags = new Stack<String>();

                @Override
                public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
                    super.startElement(uri, localName, qName, attributes);
                    if (EXPERIMENT_TAG.equals(qName)) {
                        out.println("BEGIN IONS");
                        out.println("ID=" + attributes.getValue("id"));
                        out.println("SOURCE=" + attributes.getValue("source"));
                    }
                    if (isCommentTag(qName)) {
                        currentValue = new StringBuilder();
                    }
                    if (INTACT_TAG.equals(qName) || FRAGMENT_TAG.equals(qName)) {
                        data.clear();
                    }

                    if (isValueTag(qName)) {
                        currentField = qName;
                        currentValue = new StringBuilder();
                    }
                    tags.push(qName);
                }

                private boolean isCommentTag(String qName) {
                    return COMMENT_TAG.equals(qName) && EXPERIMENT_TAG.equals(tags.peek());
                }

                @Override
                public void characters(char[] ch, int start, int length) throws SAXException {
                    super.characters(ch, start, length);
                    if (currentValue != null)
                        currentValue.append(ch, start, length);
                }

                @Override
                public void endElement(String uri, String localName, String qName) throws SAXException {
                    super.endElement(uri, localName, qName);
                    tags.pop();
                    if (FRAGMENT_LIST_TAG.equals(qName)) {
                        out.println("END IONS");
                    }
                    if (EXPERIMENT_TAG.equals(qName)) {
                        stat[0]++;
                    }

                    if (FRAGMENT_TAG.equals(qName)) {
                        out.println(extractValues(data));
                        stat[1]++;
                    }
                    if (INTACT_TAG.equals(qName)) {
                        out.println("PEPMASS=" + extractValues(data));
                        stat[2]++;
                    }
                    if (isValueTag(qName)) {
                        data.put(currentField, currentValue.toString());
                        currentValue = null;
                    }
                    if (isCommentTag(qName)) {
                        out.println("COMMENT=" + currentValue.toString());
                        currentValue = null;
                    }
                }
            };
            long start = System.currentTimeMillis();
            parser.parse(new InputSource(in), handler);
            log.debug("Puf-file " + inputFile.getAbsolutePath() + " converted to " + outputFile.getAbsolutePath() + " for " + (System.currentTimeMillis() - start) + " milliseconds");
            out.flush();
            out.close();
            return stat;
        } catch (Exception e) {
            log.error("Error processing puf-file " + inputFile.getAbsolutePath(), e);
            throw e;
        }
    }

    private boolean isValueTag(String qName) {
        return MASS_MONOISOTOPIC_TAG.equals(qName) || INTENSITY_TAG.equals(qName);
    }

    private static String extractValues(HashMap<String, String> data) {
        return data.get(MASS_MONOISOTOPIC_TAG) + " " +  data.get(INTENSITY_TAG);
    }

}
