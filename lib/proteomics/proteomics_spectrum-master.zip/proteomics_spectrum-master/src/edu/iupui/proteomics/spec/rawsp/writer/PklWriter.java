/**
 * Read an MS/MS spectrum to a file.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.rawsp.writer;

import java.io.FileOutputStream;
import java.io.PrintWriter;


import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.sp.Ms;


public class PklWriter {

	/**
	 * Write an MS/MS spectrum to a PKL file.
	 * 
	 * @param ms
	 *            An spectrum instance.
	 * 
	 * @param output_name
	 *            The output file name.
	 * @throws Exception
	 */
	public static void writePkl(Ms<RawPeak> ms, String output_name,
			boolean useMonoMz) throws Exception {
		/* output to pkl file */
		PrintWriter out = new PrintWriter(new FileOutputStream(output_name));
		if (useMonoMz) {
			out.println(ms.getHeader().getPrecMonoMz() + " 1 "
					+ ms.getHeader().getPrecChrg());
		} else {
			out.println(ms.getHeader().getPrecSpMz() + " 1 "
					+ ms.getHeader().getPrecChrg());
		}
		for (int i = 0; i < ms.size(); i++) {
			out.println(ms.getPosition(i) + " " + ms.getIntensity(i));
		}
		out.close();
	}
}
