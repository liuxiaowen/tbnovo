package edu.iupui.proteomics.spec.peak;

import java.util.Comparator;

public class IntensityComparator implements Comparator<Peak> {
	public int compare(Peak p1, Peak p2) {
		if (p1.getIntensity() > p2.getIntensity()) {
			return -1;
		} else if (p1.getIntensity() < p2.getIntensity()) {
			return 1;
		} else {
			return 0;
		}
	}
}
