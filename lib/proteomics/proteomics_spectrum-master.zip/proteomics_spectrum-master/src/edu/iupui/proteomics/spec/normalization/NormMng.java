/**
 *  Contains all parameters in this package.
 *
 *  Xiaowen Liu
 *  Jan 2, 2009
 */

package edu.iupui.proteomics.spec.normalization;

public class NormMng {

    /**
     * When the maximum intensity is removed (using second maximum), the span in
     * which the peaks are not considered.
     */
    public float removeMaxIntensitySpan = 5.0f;
    public int nMaxRemove = 2;
    public int nMaxAvg = 10;

    /**
     * When the local intensity/rank is conputed, the span for local peaks.
     */
    public float localSpan = 56f;

    /** the coefficients for linear our optimal intensity */
    public EnumMaxInte globalIntensityMaxType = EnumMaxInte.AVG;
    public EnumMaxInte localIntensityMaxType = EnumMaxInte.AVG;
    public float coefGlobalRank = 0.222f;
    public float coefLocalRank = 0.396f;
    public float coefGlobalIntensity = 0.051f;
    public float coefLocalIntensity = 0.329f;

    public NormMng() {
    }
}
