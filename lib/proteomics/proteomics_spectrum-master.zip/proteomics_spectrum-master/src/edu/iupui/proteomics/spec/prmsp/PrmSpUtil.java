/**
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.prmsp;

import java.util.ArrayList;

import edu.iupui.proteomics.spec.sp.Ms;


public class PrmSpUtil {

    public static int[][] getIntMassErrorList(Ms<PrmPeak> ms,
            double scale, boolean nStrict, boolean cStrict) throws Exception {
        ArrayList<Integer> masses = new ArrayList<Integer>();
        ArrayList<Integer> errors = new ArrayList<Integer>();
        int lastMass = -1;
        int lastError = 0;
        for (int i = 0; i < ms.size(); i++) {
            int m = (int) Math.round(ms.getPosition(i) * scale);
            int e = 0;
            if (nStrict && cStrict) {
                e = (int) Math.ceil(ms.get(i).getStrictTolerance() * scale);
            }
            else if (nStrict && !cStrict) {
                e = (int) Math.ceil(ms.get(i).getNStrictCRelaxTolerance() * scale);
            }
            else if (!nStrict && cStrict) {
                e = (int) Math.ceil(ms.get(i).getNRelaxCStrictTolerance() * scale);
            }
            if (m != lastMass) {
                masses.add(m);
                errors.add(e);
                lastMass = m;
                lastError = e;
            }
            else if (e > lastError) {
                errors.remove(errors.size() - 1);
                errors.add(e);
                lastError = e;
            }
        }
        int results[][] = new int[2][masses.size()];
        for (int i = 0; i < masses.size(); i++) {
            results[0][i] = masses.get(i);
            results[1][i] = errors.get(i);
        }
        return results;
    }

    public static double[] getMassList(Ms<PrmPeak> ms) throws Exception{
        double results[] = new double[ms.size()];
        for (int i = 0; i < ms.size(); i++) {
            results[i] = ms.getPosition(i);
        }
        return results;
    }
    
    public static double[] getScoreList(Ms<PrmPeak> ms) throws Exception{
        double results[] = new double[ms.size()];
        for (int i = 0; i < ms.size(); i++) {
            results[i] = ms.get(i).getScr();
        }
        return results;
    }
}

/*
public static int[][] getFastIntMassErrorList(AlignMs<PrmPeak> ms,
        double scale) throws Exception {
	ArrayList<Integer> masses = new ArrayList<Integer>();
    ArrayList<Integer> errors = new ArrayList<Integer>();
    int lastMass = -1;
    int lastError = 0;
    for (int i = 0; i < ms.size(); i++) {
        int m = (int) Math.round(ms.getPosition(i) * scale);
        int e = (int) Math.ceil(ms.get(i).getNStrictCRelaxTolerance() * scale);
        if (m != lastMass) {
            masses.add(m);
            errors.add(e);
            lastMass = m;
            lastError = e;
        }
        else if (e > lastError) {
            errors.remove(errors.size() - 1);
            errors.add(e);
            lastError = e;
        }
    }
    int results[][] = new int[2][masses.size()];
    for (int i = 0; i < masses.size(); i++) {
        results[0][i] = masses.get(i);
        results[1][i] = errors.get(i);
    }
    return results;
}
*/
