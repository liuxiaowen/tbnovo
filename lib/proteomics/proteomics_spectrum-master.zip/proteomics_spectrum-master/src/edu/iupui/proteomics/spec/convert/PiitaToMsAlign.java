package edu.iupui.proteomics.spec.convert;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import edu.iupui.proteomics.base.residue.MassConstant;

import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.deconvsp.reader.PiitaReader;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;


public class PiitaToMsAlign {
    public static void main(String[] args) throws Exception {

        String piitaFileName = args[0];
        String precursorFileName = args[1];
        String msalignFileName = args[2];
        Double precMz = Double.parseDouble(args[3]);
        Double error = Double.parseDouble(args[4]);

        PiitaReader reader = new PiitaReader(new File(piitaFileName)); 
        ArrayList<Ms<DeconvPeak>> msList = reader.readAllMs();
        
        reader = new PiitaReader(new File(precursorFileName));
        ArrayList<Ms<DeconvPeak>> precList = reader.readAllMs();
        double precursors[][][] = combine(precList, precMz, error);

        System.out.println("Read sp  " + msList.size());

        PrintWriter out = new PrintWriter(msalignFileName);
        for (int i = 0; i < msList.size(); i++) {
            writeText(out, msList.get(i), precursors[i]);
        }
        out.close();
    }
    
    public static double[][][] combine(ArrayList<Ms<DeconvPeak>> precList, double precMz, double error) throws Exception{
        double result[][][] = new double[precList.size()][][];
        
        for (int i = 0; i < precList.size(); i++) {
            Ms<DeconvPeak> ms = precList.get(i);
            ArrayList<Integer> peakIdxes = new ArrayList<Integer>();
            for (int j = 0; j < ms.size(); j++) {
                double mz = ms.getPosition(j)/ms.get(j).getCharge() + MassConstant.getProtonMass();
                if (Math.abs(mz - precMz) <= error) {
                    peakIdxes.add(j);
                }
            }
            if (peakIdxes.size() > 0) {
            result[i] = new double[peakIdxes.size()][3];
            for (int j = 0; j < peakIdxes.size(); j++) {
                int p = peakIdxes.get(j);
                double mz = ms.getPosition(p)/ms.get(p).getCharge() + MassConstant.getProtonMass();
                result[i][j][0] = mz;
                result[i][j][1] = ms.get(p).getCharge();
                result[i][j][2] = ms.getPosition(p);
            }
            }
            else { 
                result[i] = new double[1][3];
                result[i][0][0] = 20000 + MassConstant.getProtonMass();
                result[i][0][1] = 1;
                result[i][0][2] = 20000;
            }
        }
        return result;
    }

    public static void writeText(PrintWriter out, Ms<DeconvPeak> ms, double precursors[][])
            throws Exception {

        MsHeader header = ms.getHeader();
        out.println("BEGIN IONS");
        out.println("ID=" + header.getId());
        out.println("SCANS=" + header.getScansString());
        out.println("ACTIVATION=" + header.getActivationType().getName());
        String mz = "PRECURSOR_MZ=";
        String charge = "PRECURSOR_CHARGE=";
        String mass = "PRECURSOR_MASS=";
        for (int i= 0; i < precursors.length; i++) {
            mz = mz + precursors[i][0];
            charge = charge + Math.round(precursors[i][1]);
            mass = mass + precursors[i][2];
            if (i != precursors.length-1) {
                mz = mz + " ";
                charge = charge + " ";
                mass = mass + " ";
            }
        }
        out.println(mz);
        out.println(charge);
        out.println(mass);

        for (int i = 0; i < ms.size(); i++) {
            DeconvPeak peak = ms.get(i);
            out.print(peak.getMonoMass());
            out.print("\t" + peak.getIntensity());
            out.print("\t" + peak.getCharge());
            out.println();
        }
        out.println("END IONS");
        out.println();
    }

}

