/**
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.peak;

public interface Peak {

	public double getIntensity();

	public double getPosition();

	public void setIntensity(double intensity);

	public void setPosition(double position);
}
