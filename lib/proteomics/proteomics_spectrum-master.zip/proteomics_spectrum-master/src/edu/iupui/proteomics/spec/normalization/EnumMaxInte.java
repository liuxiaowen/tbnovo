package edu.iupui.proteomics.spec.normalization;

public enum EnumMaxInte {
    ORI, AVG, SND;
}
