/**
 * Describes the header of a mass spectrum.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.sp;

import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.jdom.Element;

import edu.iupui.proteomics.base.ion.EnumActivation;
import edu.iupui.proteomics.base.residue.MassConstant;
import edu.iupui.proteomics.base.util.XmlUtil;

import edu.iupui.proteomics.spec.peak.PeakUtil;



public class MsHeader implements Cloneable {

	private static Logger logger = Logger.getLogger(MsHeader.class);
	private int id = -1;
	/** one spectrum may have several possible precursor mass */
	private int precId = -1;
	/** data set name */
	private String fileName = "";
	private String title = "";
	/** a list of scans for merged spectra */
	private int scans[];
	/** ms level */
	private int level;
	/** activation type */
	private EnumActivation activeType;
	/** retention time */
	private String retentionTime;

	/** precursor m/z value in the MS1 spectrum */
	private double precSpMz = -1;
	/** computed monoisotopic precursor m/z value */
	private double precMonoMz = -1;
	private int precChrg = -1;

	private double errorTolerance = 0;

	public MsHeader() {
	}

	public MsHeader(int chrg) {
		this.precChrg = chrg;
	}

	public MsHeader(int scanNum, int level, int chrg) {
		this.scans = new int[1];
		scans[0] = scanNum;
		this.level = level;
		this.precChrg = chrg;
	}

	/**
	 * Clones this MsHeader.
	 */
	public Object clone() throws CloneNotSupportedException {
		Object clone = super.clone();
		((MsHeader) clone).scans = this.scans.clone();
		return clone;
	}

	public double getMaxFragMass() {
		if (precMonoMz < 0) {
			logger.warn("monoisotopic mass is not initialized");
			return PeakUtil.getMass(precSpMz, precChrg);
		} else {
			return PeakUtil.getMass(precMonoMz, precChrg);
		}
	}

	public double getPrecMonoMass() {
		if (precMonoMz < 0) {
			logger.warn("monoisotopic mass is not initialized");
			return 0f;
		} else {
			return PeakUtil.getMass(precMonoMz, precChrg);
		}
	}

	public double getPrecSpMass() {
		if (precSpMz < 0) {
			logger.warn("spectrum precursor mass is not initialized");
			return 0f;
		} else {
			return PeakUtil.getMass(precSpMz, precChrg);
		}
	}

	public double getPrecMonoMassMinusWater() {
		if (precMonoMz < 0) {
			logger.warn("monoisotopic mass is not initialized");
			return 0f;
		} else {
			return PeakUtil.getMass(precMonoMz, precChrg)
					- MassConstant.getWaterMass();
		}
	}

	public String toString() {
		StringBuffer tmp_str = new StringBuffer(1000);
		tmp_str.append("MS HEADER\n");
		tmp_str.append("==========\n");
		tmp_str.append("Title = " + title + "\n");
		tmp_str.append("Scan Number = " + scans[0] + "\n");
		tmp_str.append("MS Level = " + level + "\n");
		tmp_str.append("Activation type = " + activeType + "\n");
		tmp_str.append("Precursor Sp Mz = " + precSpMz + "\n");
		tmp_str.append("Precursor Charge = " + precChrg + "\n");
		tmp_str.append("Precursro Mono Mz = " + precMonoMz + "\n");
		return (tmp_str.toString());
	}

	/* get functions */
	public EnumActivation getActivationType() {
		return activeType;
	}

	public String getFileName() {
		return fileName;
	}

	public int getId() {
		return id;
	}

	public int getMsLevel() {
		return level;
	}

	public String getTitle() {
		return title;
	}

	public double getPrecSpMz() {
		return precSpMz;
	}

	public int getPrecChrg() {
		return precChrg;
	}

	public double getPrecMonoMz() {
		return precMonoMz;
	}

	public String getRetentionTime() {
		return retentionTime;
	}

	public String getScansString() {
		String scanList = "" + scans[0];
		for (int i = 1; i < scans.length; i++) {
			scanList = scanList + " " + scans[i];
		}
		return scanList;
	}

	public int getFirstScanNum() {
		return scans[0];
	}

	/* set function */
	public void setActivationType(String name) {
		this.activeType = EnumActivation.getActivationType(name);
	}

	/* set function */
	public void setActivationType(EnumActivation type) {
		this.activeType = type;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setPrecSpMz(double precSpMz) {
		this.precSpMz = precSpMz;
	}

	public void setPrecChrg(int precChrg) {
		this.precChrg = precChrg;
	}

	public void setPrecMonoMz(double precMonoMz) {
		this.precMonoMz = precMonoMz;
	}

	public void setRetentionTime(String retentionTime) {
		this.retentionTime = retentionTime;
	}

	public void setScan(int scanNum) {
		scans = new int[1];
		scans[0] = scanNum;
	}

	public void setScans(ArrayList<Integer> scanList) {
		scans = new int[scanList.size()];
		for (int i = 0; i < scanList.size(); i++) {
			scans[i] = scanList.get(i);
		}
	}

	public void setScans(String s) {
		if (s == "") {
			scans = new int[1];
			scans[0] = -1;
			return;
		}
		StringTokenizer st = new StringTokenizer(s);
		scans = new int[st.countTokens()];
		for (int i = 0; i < scans.length; i++) {
			scans[i] = Integer.parseInt(st.nextToken());
		}
	}

	public void setMsLevel(int level) {
		this.level = level;
	}

	public Element toXml() {
		Element header = new Element("ms_header");
		XmlUtil.addElement(header, "id", getId());
		XmlUtil.addElement(header, "scans", getScansString());
		XmlUtil.addFormatElement(header, "precursor_mz", getPrecMonoMz());
		XmlUtil.addElement(header, "precursor_charge", getPrecChrg());
		XmlUtil.addFormatElement(header, "precursor_mass", getPrecMonoMass());
		return header;
	}

	public void setPrecId(int precId) {
		this.precId = precId;
	}

	public int getPrecId() {
		return precId;
	}

	public double getErrorTolerance() {
		return errorTolerance;
	}

	public void setErrorTolerance(double errorTolerance) {
		this.errorTolerance = errorTolerance;
	}

}
