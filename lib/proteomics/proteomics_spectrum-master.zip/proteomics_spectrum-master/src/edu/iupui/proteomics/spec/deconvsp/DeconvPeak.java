/**
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.deconvsp;

import edu.iupui.proteomics.spec.peak.Peak;
import edu.iupui.proteomics.spec.peak.PeakUtil;

public class DeconvPeak implements Peak, Cloneable {

	private int id;
	private int charge;
    private double intensity;
    private double monoMass;
    private double score;

	public DeconvPeak(int id, double monoMass, double intensity, int charge)
			throws Exception {
		if (monoMass < 0 || intensity < 0) {
			throw new Exception("monoMass/intensity are negative values");
		}
		this.id = id;
        this.charge = charge;
        this.intensity = intensity;
        this.monoMass = monoMass;
        this.score = 1.0;
	}

	public DeconvPeak clone() throws CloneNotSupportedException {
		return (DeconvPeak)super.clone();
	}
	
	public int getCharge() {
		return charge;
	}

	public int getId() {
		return id;
	}

    public double getIntensity() {
        return intensity;
    }

	public double getMonoMass() {
		return getPosition();
	}
	
    public double getMonoMz() {
        return PeakUtil.getMonoMz(monoMass, charge);
    }

    public double getPosition() {
        return monoMass;
    }
    
	public double getScore() {
		return score;
	}

	public void setId(int id) {
		this.id = id;
	}

    public void setIntensity(double intensity) {
        this.intensity = intensity;
    }

    public void setPosition(double position) {
        this.monoMass = position;
    }
}
