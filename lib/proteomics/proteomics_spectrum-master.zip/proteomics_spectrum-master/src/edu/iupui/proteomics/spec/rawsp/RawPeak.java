/**
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.rawsp;

import java.util.ArrayList;

import edu.iupui.proteomics.base.util.BioIo;

import edu.iupui.proteomics.spec.peak.Peak;


public class RawPeak implements Peak {

    double mz;
    double intensity;

	public RawPeak(double mz, double intensity) throws Exception {
		if (mz < 0 || intensity < 0) {
			throw new Exception("mz/intensity values are negative. mz:" + mz 
                    + " intensity:" + intensity);
		}
        this.mz = mz;
        this.intensity = intensity;
	}

	public double getIntensity() {
		return intensity;
	}

	public double getMz() {
		return getPosition();
	}
    
    public double getPosition() {
        return mz;
    }

    public void setIntensity(double intensity) {
        this.intensity = intensity;
    }

    public void setPosition(double position) {
        this.mz = position;
    }

	public static RawPeak[] getRawPeaks(double mzs[],
			double intensities[]) throws Exception {
	    ArrayList<RawPeak> peakList = new ArrayList<RawPeak>();
		for (int i = 0; i < mzs.length; i++) {
		    try {
		        RawPeak peak = new RawPeak(mzs[i], intensities[i]);
		        peakList.add(peak);
		    }
		    catch (Exception e) {
		        System.out.println(BioIo.getStackTraceAsString(e));
		    }
		}
		return peakList.toArray(new RawPeak[0]);
	}
}
