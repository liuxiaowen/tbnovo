package edu.iupui.proteomics.spec.prmsp;

public enum EnumSupportPeakType {
	   N_TERM(0, "N_TERM"), C_TERM(1, "C_TERM");

	    private int id;
	    private String name;


	    EnumSupportPeakType(int id, String name) {
	        this.id = id;
	        this.name = name;
	    }
	    
	    public int getId () {
	        return id;
	    }
	    
	    public String getName() {
	        return name;
	    }

}
