/**
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.peak;

import edu.iupui.proteomics.base.residue.MassConstant;

public class PeakUtil {

    public static double getMass(double monoMz, int charge) {
        return monoMz * charge - charge * MassConstant.getProtonMass();
    }
    
    public static double getMonoMz(double monoMass, int charge) {
        return monoMass / charge + MassConstant.getProtonMass();
    }
    
}
