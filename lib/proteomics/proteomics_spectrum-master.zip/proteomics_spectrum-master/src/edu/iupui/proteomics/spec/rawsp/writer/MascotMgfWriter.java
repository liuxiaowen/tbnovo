/**
 * Read an MS/MS spectrum to a file.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.rawsp.writer;

import java.io.PrintWriter;

import org.apache.log4j.Logger;

import edu.iupui.proteomics.base.residue.MassConstant;

import edu.iupui.proteomics.spec.sp.MsHeader;


public class MascotMgfWriter extends MgfWriter {

    private static Logger logger = Logger.getLogger(MascotMgfWriter.class);

	public MascotMgfWriter(String fileName) throws Exception {
		/* output mgf file */
		super(fileName);
	}
	/**
	 * Write an MatchEnv List to a mgf file.
	 * 
	 * @throws Exception
	 */
	public static void writeMgf(PrintWriter out, MsHeader header, String seq,
			double mzs[], double intensities[], boolean useMonoMz, boolean usePrecChargeOne) throws Exception {
		/* output mgf file */

		/* the parameter pepmass is confusing. It is in fact peptide m/z */
		/* the parameter pepmass is confusing. It is in fact peptide m/z */
		double pepmass;
		if (useMonoMz) {
			pepmass = header.getPrecMonoMz();
		}
		else {
			pepmass = header.getPrecSpMz();
		}
		int charge = header.getPrecChrg();
		if (usePrecChargeOne) {
			charge = 1;
			if (useMonoMz) {
				pepmass = header.getPrecMonoMass() + MassConstant.getProtonMass();
			}
			else {
				pepmass = header.getPrecSpMass() + MassConstant.getProtonMass();
			}
		}
		if (pepmass <= 50) {
			logger.warn("pep mass is not valid " + pepmass);
			return;
		}

		out.println("BEGIN IONS");
		String title = header.getTitle();
		if (title != null) {
			out.println("TITLE=" + title);
		}
		int scanNum = header.getFirstScanNum();
		if (scanNum > 0) {
			out.println("SCANS=" + scanNum);
		}
	    out.println("PEPMASS=" + pepmass);
		if (charge > 0) {
			out.println("CHARGE=" + charge + "+");
		}
		for (int i = 0; i < mzs.length; i++) {
			if (intensities[i] > 0) {
				out.println(mzs[i] + " " + intensities[i]);
			}
		}
		out.println("END IONS");
		out.println();
	}
}
