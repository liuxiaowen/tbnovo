package edu.iupui.proteomics.spec.extendsp;


import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.peak.Peak;


public class ExtendPeak implements Peak{

	private DeconvPeak basePeak; /* base peak */
	private double monoMass;
	private double intensity;
	protected double score;
	private double origTolerance;
	private double reverseTolerance;
	
	public ExtendPeak() {
		
	}
	
	public ExtendPeak(DeconvPeak basePeak, double monoMass, double score)
			throws Exception {
		this.monoMass = monoMass;
		this.basePeak = basePeak;
        this.score = score;
	}

	/* gets */
	public DeconvPeak getBasePeak() {
		return basePeak;
	}
    
	public double getIntensity() {
		return intensity;
	}
	
	public double getMonoMass() {
		return monoMass;
	}
	
	public double getPosition() {
		return monoMass;
	}

	public double getScore() {
		return score;
	}

	public double getOrigTolerance() {
		return origTolerance;
	}
	
	public double getReverseTolerance() {
		return reverseTolerance;
	}

	public void setPosition(double p) {
		monoMass = p;
	}
	
	public void setIntensity(double i) {
		intensity = i;
	}
	
	public void setOrigTolerance(double tolerance) {
		this.origTolerance = tolerance;
	}
	
	public void setReverseTolerance(double tolerance) {
		this.reverseTolerance = tolerance;
	}
}
