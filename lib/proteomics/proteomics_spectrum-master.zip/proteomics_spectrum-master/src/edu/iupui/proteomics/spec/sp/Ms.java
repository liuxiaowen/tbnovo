/**
 * Describes a mass spectrum.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.sp;

import java.util.ArrayList;

import edu.iupui.proteomics.spec.peak.Peak;
import edu.iupui.proteomics.spec.peak.PeakTolerance;


public class Ms<T extends Peak> extends PeakList<T> {

	private static final long serialVersionUID = 1L;
	private MsHeader header;

	public Ms() {
	}

	public Ms(MsHeader header) {
		this.header = header;
	}

	public Ms(Ms<T> ms) throws Exception {
		super(ms);
		this.header = ms.getHeader();
	}

	public Ms(ArrayList<T> peakList, MsHeader header) throws Exception {
		super(peakList);
		this.header = header;
	}

	public Ms(T peaks[], MsHeader header) throws Exception {
		super(peaks);
		this.header = header;
	}

	public Ms(T peaks[], MsHeader header, PeakTolerance peakTolerance)
			throws Exception {
		super(peaks);
		header.setErrorTolerance(peakTolerance.compStrictErrorTole(header
				.getPrecMonoMass()));
		this.header = header;
	}

	/**
	 * Removes precursor mass. In ETD data, MSMS may contain a high precursor
	 * mass peak. So we use the following to remove it.
	 * 
	 * @param tolerance
	 *            The error tolerance for removing precursor peak.
	 */
	public void rmPrec(double tolerance) {
		rmPeaks(header.getPrecSpMz(), tolerance);
	}

	public void recalibrate(double recal) throws Exception {
		for (int i = 0; i < size(); i++) {
			double newMass = (1 + recal) * getPosition(i);
			get(i).setPosition(newMass);
		}
	}

	public String toString() {
		return header.toString() + super.toString();
	}

	public MsHeader getHeader() {
		return header;
	}

	public void setHeader(MsHeader header) {
		this.header = header;
	}
}
