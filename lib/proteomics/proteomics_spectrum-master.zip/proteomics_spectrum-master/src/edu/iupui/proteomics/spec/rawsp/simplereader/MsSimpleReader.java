package edu.iupui.proteomics.spec.rawsp.simplereader;


import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;
import edu.iupui.proteomics.spec.sp.PeakList;


public abstract class MsSimpleReader {
	/* current spectrum */
    protected int nextIdNum = 1;
    /* number of total spectra */
    protected int nTotal = 0;
    protected Ms<RawPeak> ms = null;
    protected PeakList<RawPeak> peakList = null;
    protected MsHeader header = null;
    
    public MsSimpleReader () throws Exception {
    }

    public Ms<RawPeak> getNextMs() throws Exception {
        readNext();
        if (peakList == null) {
            return null;
        }
        Ms<RawPeak> ms = new Ms<RawPeak>(peakList, header);
        return ms;
    }

    public abstract void readNext() throws Exception;

    public int getTotalScanNum() {
        return nTotal;
    }
    
    public int getNextIdNum() {
    	return nextIdNum;
    }
    
    public PeakList<RawPeak> getPeakList() {
    	return peakList;
    }
    
    public MsHeader getMsHeader() {
    	return header;
    }
}
