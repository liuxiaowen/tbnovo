/**
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.prmsp;


import java.util.ArrayList;


import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.peak.Peak;

public class PrmPeak implements Peak{

	private DeconvPeak basePeak; /* base vertex */
	private double monoMass;
	private double intensity;
	protected double score;
	private EnumPrmPeakType baseType;
	private double strictTolerance;
    /* tolerance fo strict n-terminal masses and relax c-terminal masses */
	private double nStrictCRelaxTolerance;
	private double nRelaxCStrictTolerance;
	
	private ArrayList<SupportPeak> neighborList;

	public PrmPeak(DeconvPeak basePeak, double monoMass, EnumPrmPeakType baseType, double score)
			throws Exception {
		this.monoMass = monoMass;
		this.intensity = basePeak.getIntensity();
		this.basePeak = basePeak;
        this.score = score;
		this.baseType = baseType;
		neighborList = new ArrayList<SupportPeak>();
	}

	/** add a new edge */
	public void addNghbEdge(DeconvPeak p, double offset, EnumSupportPeakType peakType,
			double score) {
		this.score += score;
		neighborList.add(new SupportPeak(p, offset, peakType, score));
	}

	public int getNeighborSize() {
		return neighborList.size();
	}
	
	/* gets */
	public DeconvPeak getBasePeak() {
		return basePeak;
	}

    
	public double getIntensity() {
		return intensity;
	}
    
	
	public double getMonoMass() {
		return monoMass;
	}
	
	public double getPosition() {
		return monoMass;
	}

	public double getScr() {
		return score;
	}

	public double getStrictTolerance() {
		return strictTolerance;
	}
	

	public void setPosition(double p) {
		monoMass = p;
	}
	
	public void setIntensity(double i) {
		intensity = i;
	}
	
	public void setStrictTolerance(double tolerance) {
		this.strictTolerance = tolerance;
	}

	public EnumPrmPeakType getBaseType() {
		return baseType;
	}
	
	public double getNStrictCRelaxTolerance() {
		return nStrictCRelaxTolerance;
	}
	
	public double getNRelaxCStrictTolerance() {
	        return nRelaxCStrictTolerance;
	}

	public int getBreakType() {
		// 0 for no match; 1 for b-ion; 2 for y-ion; 3 for both b and y-ions
		int breakType = 0;
		for (int i = 0; i < neighborList.size(); i++) {
			if (neighborList.get(i).getPeakType() == EnumSupportPeakType.N_TERM) {
				if (breakType == 0) {
					breakType = 1;
				} else if (breakType == 2) {
					breakType = 3;
				}
			} else {
				if (breakType == 0) {
					breakType = 2;
				} else if (breakType == 1) {
					breakType = 3;
				}
			}
		}
		return breakType;
	}
	
	public void setNStrictCRelaxTolerance(double tolerance) {
		this.nStrictCRelaxTolerance = tolerance;
	}
	
	public void setNRelaxCStrictTolerance(double tolerance) {
	    this.nRelaxCStrictTolerance = tolerance;
	}
}
