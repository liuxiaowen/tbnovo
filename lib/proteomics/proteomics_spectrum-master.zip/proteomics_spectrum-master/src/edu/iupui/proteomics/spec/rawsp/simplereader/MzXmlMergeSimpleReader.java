package edu.iupui.proteomics.spec.rawsp.simplereader;

import java.util.ArrayList;
import java.util.LinkedList;

import org.apache.log4j.Logger;


import edu.iupui.proteomics.spec.normalization.Norm;
import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.rawsp.merger.MsMerger;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.PeakList;


public class MzXmlMergeSimpleReader extends MsSimpleReader {


	/* ms with normalized intensity */
    public class MsNorm {
        private Ms<RawPeak> ms;
        private double[] normIntensities;

        public MsNorm(Ms<RawPeak> ms, double normIntensities[]) {
            this.ms = ms;
            this.normIntensities = normIntensities;
        }

        public Ms<RawPeak> getMs() {
            return ms;
        }

        public double[] getNormInte() {
            return normIntensities;
        }
    }

    private static Logger logger = Logger.getLogger(MzXmlMergeSimpleReader.class);

    public static int MERGE_DIST = 300;
    private static float ERROR_TOLE = 0.01f;
    public static float SCORE_THRE = 0.5f;
    private static float MAX_DIFF = 0.1f;

    private MzXmlSingleSimpleReader reader;
    private int currentBgn;
    private int currentEnd;
    private LinkedList<MsNorm> msNormList;
    
	public MzXmlMergeSimpleReader() throws Exception {
		super();
	}

    public MzXmlMergeSimpleReader(String file_name)
            throws Exception {
    	super();
        reader = new MzXmlSingleSimpleReader(file_name);
        msNormList = new LinkedList<MsNorm>();
        currentBgn = 0;
        currentEnd = 0;
        updateMsList();
    }

    /** update scan group list */
    private void updateMsList() throws Exception {
        do {
            /* update cur bgn and cur end */
            int lastEndPos = currentEnd;
            if (msNormList.size() == 0) {
                currentBgn = lastEndPos + 1;
            } else {
                currentBgn = msNormList.get(0).getMs().getHeader().getFirstScanNum();
            }
            currentEnd = currentBgn + MERGE_DIST - 1;
            if (currentEnd > reader.getTotalScanNum()) {
                currentEnd = reader.getTotalScanNum();
            }
            int lastScanNum = lastEndPos;
            while (lastScanNum < currentEnd) {
                Ms<RawPeak> ms = reader.getNextMs();
                if (ms == null) {
                    currentEnd = reader.getTotalScanNum();
                    return;
                }
                /* important for later similarity computation */
                double norm_inte[] = Norm.getCosineNormInte(ms.getIntensities());
                msNormList.add(new MsNorm(ms, norm_inte));
                lastScanNum = ms.getHeader().getFirstScanNum();
            }
            currentEnd = lastScanNum;
        } while (msNormList.size() == 0
                && currentEnd != reader.getTotalScanNum());
    }

    /* get next mergered mass spectrum */
    public void readNext() throws Exception {
        logger.debug("scan number " + currentBgn + " "
                + reader.getTotalScanNum());
        logger.debug("Scan list size " + msNormList.size());
        peakList = null;
        header = null;
        if (msNormList.size() == 0) {
            return;
        }
        MsNorm msNorm = msNormList.remove(0);
        Ms<RawPeak> ms = msNorm.getMs();
        /* if it is ms level 1 */
        if (ms.getHeader().getMsLevel() == 1) {
            peakList = (PeakList<RawPeak>) ms;
            header = ms.getHeader();
            updateMsList();
            return;
        }
        MsNorm sameMsNorms[] = getSameList(msNorm, msNormList);
        logger.debug("same list size " + sameMsNorms.length);
        updateMzInteListHeader(msNorm, sameMsNorms);
    }

    private MsNorm[] getSameList(MsNorm msNormA, LinkedList<MsNorm> msNormList) {
        ArrayList<MsNorm> sameNormList = new ArrayList<MsNorm>();
        for (int i = 0; i < msNormList.size(); i++) {
            MsNorm msNormB = msNormList.get(i);
            if (msNormB.getMs().getHeader().getMsLevel() == 2
                    && MsMerger.isSimilar(msNormA.getMs(), msNormA.getNormInte(),
                            msNormB.getMs(), msNormB.getNormInte(), MAX_DIFF,
                            SCORE_THRE, ERROR_TOLE)) {
                sameNormList.add(msNormB);
            }
        }
        return (MsNorm[]) sameNormList.toArray(new MsNorm[0]);
    }

    @SuppressWarnings("unchecked")
	private void updateMzInteListHeader(MsNorm msNorm, MsNorm sameNorms[])
            throws Exception {
        int num = msNorm.getMs().getHeader().getFirstScanNum();
        Ms<RawPeak> sameMses[] = new Ms[sameNorms.length];
        for (int i = 0; i < sameNorms.length; i++) {
            sameMses[i] = sameNorms[i].getMs();
        }
        /* update mz_inte_list */
        peakList = MsMerger.getAverage(msNorm.getMs(), sameMses, ERROR_TOLE);
        String title = "Scan_" + num;
        ArrayList<Integer> scanList = new ArrayList<Integer>();
        scanList.add(num);
        //int len = 1;
        if (sameNorms.length > 0) {
            //len += sameNorms.length;
            title = title
                    + "_"
                    + sameNorms[sameNorms.length - 1].getMs().getHeader()
                            .getFirstScanNum();
            for (int i = 0; i < sameNorms.length; i++) {
                scanList.add(sameNorms[i].getMs().getHeader().getFirstScanNum());
            }
        }
        /* update header */
        header = msNorm.getMs().getHeader();
        header.setTitle(title);
        header.setScans(scanList);
        /* update list */
        for (int i = 0; i < sameNorms.length; i++) {
            msNormList.remove(sameNorms[i]);
        }
        updateMsList();
    }

}
