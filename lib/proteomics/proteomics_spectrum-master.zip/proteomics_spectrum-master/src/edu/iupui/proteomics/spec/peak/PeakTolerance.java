package edu.iupui.proteomics.spec.peak;

import org.jdom.Element;

import edu.iupui.proteomics.base.util.XmlUtil;

public class PeakTolerance {

	private double ppo;
    /* whether or not use minimum tolerance */
	private boolean useMinTolerance;
	private double minTolerance;

	public PeakTolerance(double ppo, boolean useMinTolerance,
			double minTolerance) {
		this.ppo = ppo;
		this.useMinTolerance = useMinTolerance;
		this.minTolerance = minTolerance;
	}
	
	public PeakTolerance(Element element) {
		ppo = Double.parseDouble(element.getChildText("ppo"));
		useMinTolerance = Boolean.parseBoolean(element.getChildText("use_min_tolerance"));
		minTolerance = Double.parseDouble(element.getChildText("min_tolerance"));
	}

	public double compStrictErrorTole(double mass) {
		double tolerance = mass * ppo;
		if (useMinTolerance && tolerance < minTolerance) {
			tolerance = minTolerance;
		}
		return tolerance;
	}

	// consider zero ptm relaxed error
	public double compRelaxErrorTole(double m1, double m2) {
		return compStrictErrorTole(m1 + m2);
	}
	
	public void setPpo(double ppo) {
		this.ppo = ppo;
	}
	
	public double getPpo() {
		return ppo;
	}
	
	public boolean isUseMinTolerance() {
		return useMinTolerance;
	}
	
	public void setUseMinTolerance(boolean useMinTolerance) {
		this.useMinTolerance = useMinTolerance;
	}
	
	public double getMinTolerance() {
		return minTolerance;
	}
	
	public void setMinTolerance(double minTolerance) {
		this.minTolerance = minTolerance;
	}
	
	public Element toXml() {
		Element element = new Element("peak_tolerance");
		XmlUtil.addElement(element, "ppo", ppo);
		XmlUtil.addElement(element, "use_min_tolerance", useMinTolerance);
		XmlUtil.addElement(element, "min_tolerance", minTolerance);
		return element;
	}
	
}
