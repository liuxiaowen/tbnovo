/**
 * Read an MS/MS spectrum to a file.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.rawsp.writer;

import java.io.FileOutputStream;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

import edu.iupui.proteomics.base.residue.MassConstant;

import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;


public class MgfWriter {

	private static Logger logger = Logger.getLogger(MgfWriter.class);

	PrintWriter out = null;

	public MgfWriter(String fileName) throws Exception {
		/* output mgf file */
		out = new PrintWriter(new FileOutputStream(fileName));
	}

	public void close() {
		out.close();
	}

	/**
	 * Write several MS/MS spectra to a MGF file.
	 * 
	 * @param fileName
	 *            The output file name.
	 * @param mses
	 *            An spectrum array.
	 * @throws Exception
	 */
	public static void writeMgf(String fileName, Ms<RawPeak> mses[],
			boolean useMonoMz, boolean usePrecChargeOne) throws Exception {
		/* output mgf file */
		PrintWriter out = new PrintWriter(new FileOutputStream(fileName));
		for (int i = 0; i < mses.length; i++) {
			writeMgf(out, mses[i], useMonoMz, usePrecChargeOne);
		}
		out.close();
	}

	/**
	 * Write an MS/MS spectrum to a MGF file.
	 * 
	 * @param fileName
	 *            The output file name.
	 * @param mses
	 *            An spectrum instance.
	 * @throws Exception
	 */
	public static void writeMgf(String fileName, Ms<RawPeak> mses,
			boolean useMonoMz, boolean usePrecChargeOne) throws Exception {
		/* output mgf file */
		PrintWriter out = new PrintWriter(new FileOutputStream(fileName));
		writeMgf(out, mses, useMonoMz, usePrecChargeOne);
		out.close();
	}

	/**
	 * Write an MS/MS spectrum to a MGF file format.
	 * 
	 * @param out
	 *            The print class.
	 * @param mses
	 *            An spectrum instance.
	 */
	public static void writeMgf(PrintWriter out, Ms<RawPeak> mses,
			boolean useMonoMz, boolean usePrecChargeOne) throws Exception {
		writeMgf(out, mses.getHeader(), null, mses.getPositions(),
				mses.getIntensities(), useMonoMz, usePrecChargeOne);
	}

	public void writeMgf(MsHeader header, double mzs[], double intensities[], boolean useMonoMz, boolean usePrecChargeOne)
			throws Exception {
		writeMgf(out, header, null, mzs, intensities, useMonoMz, usePrecChargeOne);
	}

	public void writeMgf(MsHeader header, String seq, double mzs[],
			double intensities[], boolean useMonoMz, boolean usePrecChargeOne) throws Exception {
		writeMgf(out, header, seq, mzs, intensities, useMonoMz, usePrecChargeOne);
	}

	/**
	 * Write an MatchEnv List to a mgf file.
	 * 
	 * @throws Exception
	 *             TODO
	 */
	public static void writeMgf(PrintWriter out, MsHeader header, String seq,
			double mzs[], double intensities[], boolean useMonoMz, boolean usePrecChargeOne) throws Exception {
		/* output mgf file */

		/* the parameter pepmass is confusing. It is in fact peptide m/z */
		double pepmass;
		if (useMonoMz) {
			pepmass = header.getPrecMonoMz();
		}
		else {
			pepmass = header.getPrecSpMz();
		}
		int charge = header.getPrecChrg();
		if (usePrecChargeOne) {
			charge = 1;
			if (useMonoMz) {
				pepmass = header.getPrecMonoMass() + MassConstant.getProtonMass();
			}
			else {
				pepmass = header.getPrecSpMass() + MassConstant.getProtonMass();
			}
		}
		if (pepmass <= 50) {
			logger.warn("pep mass is not valid " + pepmass);
			return;
		}
		out.println("BEGIN IONS");
		String title = header.getTitle();
		if (title != null) {
			out.println("TITLE=" + title);
		} else {
			out.println("TITLE=" + header.getFirstScanNum());
		}
		if (seq != null) {
			out.println("SEQ=" + seq);
		}
		out.println("PEPMASS=" + pepmass);
		if (charge > 0) {
			out.println("CHARGE=" + charge + "+");
		}
		for (int i = 0; i < mzs.length; i++) {
			if (intensities[i] > 0) {
				out.println(mzs[i] + " " + intensities[i]);
			}
		}
		out.println("END IONS");
		out.println();
	}
}
