package edu.iupui.proteomics.spec.theosp;

import edu.iupui.proteomics.base.ion.Ion;

import edu.iupui.proteomics.spec.peak.Peak;


public class TheoPeak implements Peak {

	double mass;
	double intensity;

	double unmodMass;
	double shift;

	Ion ion;

	public TheoPeak(Ion ion, double unmodMass, double shift) {

		this.ion = ion;
		this.unmodMass = unmodMass;
		this.shift = shift;
		this.mass = unmodMass + shift;
		this.intensity = 1.0;
	}

	public double getIntensity() {
		return intensity;
	}

	public Ion getIon() {
		return ion;
	}

	public double getModMass() {
		return mass;
	}

	public double getPosition() {
		return mass;
	}

	public double getShift() {
		return shift;
	}

	public void setIntensity(double intensity) {
		this.intensity = intensity;
	}

	public void setPosition(double position) {
		this.mass = position;
	}
}
