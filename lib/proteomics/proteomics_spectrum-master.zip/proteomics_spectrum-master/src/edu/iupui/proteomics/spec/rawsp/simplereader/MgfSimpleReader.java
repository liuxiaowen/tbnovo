package edu.iupui.proteomics.spec.rawsp.simplereader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.log4j.Logger;

import edu.iupui.proteomics.base.util.ReaderUtil;

import edu.iupui.proteomics.spec.rawsp.RawPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;
import edu.iupui.proteomics.spec.sp.PeakList;


public class MgfSimpleReader extends MsSimpleReader {
    private static Logger logger = Logger.getLogger(MgfSimpleReader.class);

    private BufferedReader input = null;
    private boolean useMonoMz;

    public MgfSimpleReader(String fileName, boolean useMonoMz) throws Exception {
        getSpCount(fileName);
        this.useMonoMz = useMonoMz;
        input = new BufferedReader(new FileReader(fileName));
    }

    public void getSpCount(String fileName) throws Exception {
        input = new BufferedReader(new FileReader(fileName));
        nTotal = 0;
        String line;
        while ((line = input.readLine()) != null) {
            line = line.trim();
            if (line.equals("BEGIN IONS")) {
                nTotal = nTotal + 1;
            }
        }
        input.close();
    }

    public Ms<RawPeak> getNextMs() throws Exception {
        readNext();
        if (peakList == null) {
            return null;
        }
        PeakList<RawPeak> resultList;
        resultList = peakList;

        header.setMsLevel(2);

        Ms<RawPeak> ms = new Ms<RawPeak>(resultList, header);
        return ms;
    }
    
    public static String[] readOneSpectrum(BufferedReader input) throws IOException {
        String line;
        ArrayList<String> lineList = null;
        while ((line = input.readLine()) != null) {
            line = line.trim();
            if (line.equals("BEGIN IONS")) {
                lineList = new ArrayList<String>();
            }
            else if (line.equals("END IONS")) {
                if (lineList == null) {
                    return null;
                }
                else {
                    return lineList.toArray(new String[0]);
                }
            }
            else if (line.equals("")) {
                continue;
            }
            else {
                if (lineList != null) {
                    lineList.add(line);
                }
            }
        }
        return null;
    }

    public void readNext() throws Exception {
        peakList = null;
        header = null;
        String[] lines = readOneSpectrum(input);
        if (lines == null) {
            input.close();
            return;
        }
        Properties properties = ReaderUtil.getProperties(lines);
        String title = properties.getProperty("TITLE");
        
        // precursor mass
        String massProp = properties.getProperty("PEPMASS");
        double precMz = 0;
        if (massProp != null) {
            String s[] = massProp.split("\\s+");
            precMz = Double.parseDouble(s[0]);
        }
        // precursor charge
        int precCharge = 0;
        String chargeProp = properties.getProperty("CHARGE");
        if (chargeProp != null) {
            String[] chargeStrings = chargeProp.split("[\\s\\+]+");
            precCharge = Integer.parseInt(chargeStrings[0]);
        }
        String scans = properties.getProperty("SCANS");
        if (scans == null) {
        	scans = "";
        }
       
        // check if the header is valid 
        if (precMz < 0) {
            logger.warn("Input file format error: sp title " + title + " prec_chrg "
                    + precCharge + " prec mass " + precMz);
            precMz = 0;
        }
        if (precCharge < 0 || precMz < 0) {
            logger.error("Input file format error: sp title " + title + " prec_chrg "
                    + precCharge + " prec mass " + precMz);
            System.exit(1);
        }
        
        // peaks
        peakList = new PeakList<RawPeak>();
        String peakLines[] = ReaderUtil.getPeakLines(lines);
        for (int i = 0; i < peakLines.length; i++) {
            String[] items = peakLines[i].split("\\s+");
            peakList.add(new RawPeak(Double.parseDouble(items[0]), Double.parseDouble(items[1])));
        }
        header = new MsHeader(precCharge);
        header.setTitle(title);
        header.setScans(scans);
        if (useMonoMz) {
        	header.setPrecMonoMz(precMz);
        }
        else {
        	header.setPrecSpMz(precMz);
        }
        nextIdNum++;
    }
}
