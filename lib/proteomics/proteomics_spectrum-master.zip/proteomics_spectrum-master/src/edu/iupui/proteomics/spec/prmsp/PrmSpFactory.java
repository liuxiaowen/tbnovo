package edu.iupui.proteomics.spec.prmsp;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Logger;

import edu.iupui.proteomics.base.ion.EnumActivation;
import edu.iupui.proteomics.base.ion.EnumIonType;

import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.deconvsp.DeconvSpFactory;
import edu.iupui.proteomics.spec.extendsp.ExtendSpPara;
import edu.iupui.proteomics.spec.peak.PeakTolerance;
import edu.iupui.proteomics.spec.peak.PositionComparator;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;
import edu.iupui.proteomics.spec.sp.SpPara;

//import edu.ucsd.msalign.align.AlignMng;

public class PrmSpFactory {

    private static Logger logger = Logger.getLogger(PrmSpFactory.class);

    public static Ms<PrmPeak> getMsTwo(Ms<DeconvPeak> deconvSp,
            double delta, SpPara spPara)
            throws Exception {
        logger.trace("start sp two generation");
        MsHeader header = DeconvSpFactory.getDeltaHeader(delta, deconvSp);
        DeconvPeak peaks[] = deconvSp.toArray(new DeconvPeak[0]);

        PrmPeak prmPeaks[] = getSpTwoPrmPeak(peaks, header, spPara.getMinMass());

        setTolerance(prmPeaks, header.getPrecMonoMass(), spPara.getPeakTolerance());
        return new Ms<PrmPeak>(prmPeaks, header, spPara.getPeakTolerance());
    }
    
    

    /**************************************
     * Get Sp six
     **************************************/
    public static Ms<PrmPeak> getSpSix(Ms<DeconvPeak> deconvSp,
            double delta, SpPara spPara) throws Exception {
        
        MsHeader header = DeconvSpFactory.getDeltaHeader(delta, deconvSp);
        DeconvPeak peaks[] = deconvSp.toArray(new DeconvPeak[0]);

        return getSpSix(header, peaks, delta, spPara);
    }

    public static Ms<PrmPeak> getShiftSpSix(Ms<DeconvPeak> deconvSp,
            double delta, double shift, SpPara spPara)  throws Exception {
                
        MsHeader header = DeconvSpFactory.getDeltaHeader(delta, deconvSp);
        DeconvPeak peaks[] = deconvSp.toArray(new DeconvPeak[0]);

        Ms<PrmPeak> ms = getSpSix(header, peaks, delta, spPara);
        double monoMz = (ms.getHeader().getPrecMonoMass() + shift)
                / ms.getHeader().getPrecChrg();
        ms.getHeader().setPrecMonoMz(monoMz);
        // keep zero mass, i = 1
        PrmPeak prmPeaks[] = ms.toArray(new PrmPeak[0]);
        for (int i = 1; i < prmPeaks.length; i++) {
            double pos = prmPeaks[i].getPosition() + shift;
            if (pos > 0) {
                prmPeaks[i].setPosition(pos);
            } else {
                ms.remove(peaks[i]);
            }
        }
        return ms;
    }

    private static Ms<PrmPeak> getSpSix(MsHeader header,
            DeconvPeak peaks[], double delta, SpPara spPara)
            throws Exception {

        PrmPeak prmPeaks[] = getSpSixPrmPeak(peaks, header, spPara.getMinMass(), spPara.getExtendSpPara());

        setTolerance(prmPeaks, header.getPrecMonoMass(), spPara.getPeakTolerance());
        return new Ms<PrmPeak>(prmPeaks, header, spPara.getPeakTolerance());

    }
    
    /*******************
     * private functions
     *******************/

    private static void addTwoMasses(ArrayList<PrmPeak> list, DeconvPeak peak,
            double precMonoMass, EnumActivation activeType) throws Exception {
        /* generate extended vertex based on m */
        double origMass = peak.getMonoMass() - activeType.getNShift();
        PrmPeak newPeak = new PrmPeak(peak, origMass, EnumPrmPeakType.ORIGINAL, 1);
        list.add(newPeak);
        double reverseMass = precMonoMass
                - (peak.getMonoMass() - activeType.getCShift());
        newPeak = new PrmPeak(peak, reverseMass, EnumPrmPeakType.REVERSED, 1);
        list.add(newPeak);

    }

    private static void addSixMasses(ArrayList<PrmPeak> list, DeconvPeak peak,
            double precMonoMass, EnumActivation activeType, double offsets[])
            throws Exception {
        for (int i = 0; i < offsets.length; i++) {
            double mass = peak.getMonoMass() - activeType.getNShift()
                    + offsets[i];
            PrmPeak newPeak = new PrmPeak(peak, mass, EnumPrmPeakType.ORIGINAL, 1);
            list.add(newPeak);
        }
        /* generate extended vertex based on M-m */
        for (int i = 0; i < offsets.length; i++) {
            double mass = precMonoMass
                    - (peak.getMonoMass() - activeType.getCShift() + offsets[i]);
            PrmPeak newPeak = new PrmPeak(peak, mass, EnumPrmPeakType.REVERSED, 1);
            list.add(newPeak);
        }
    }

    /**
     * generate type 2 PRM peak list: both original spectrum and reverse
     * spectrum. But +/-1 Da shift is not considered.
     */
    private static PrmPeak[] getSpTwoPrmPeak(DeconvPeak peaks[],
            MsHeader header, double blankMass) throws Exception {
        double precMonoMass = header.getPrecMonoMass();
        EnumActivation activeType = header.getActivationType();
        ArrayList<PrmPeak> list = new ArrayList<PrmPeak>();
        for (int i = 0; i < peaks.length; i++) {
        	//System.out.println("peak " + peaks[i] + " activeType " + activeType);
            addTwoMasses(list, peaks[i], precMonoMass, activeType);
        }
        filterPrmPeak(list, blankMass, precMonoMass);
        /* add 0 and precursor mass - 18 */
        DeconvPeak zeroPeak = new DeconvPeak(-1, 0, 0, 0);
        list.add(new PrmPeak(zeroPeak, 0, EnumPrmPeakType.ORIGINAL, 1));
        DeconvPeak precPeak = new DeconvPeak(-1, precMonoMass
                - EnumIonType.PREC.getShift(), 0, 0);
        list.add(new PrmPeak(precPeak, precMonoMass
                - EnumIonType.PREC.getShift(), EnumPrmPeakType.ORIGINAL, 1));
        /* sort by mass */
        PrmPeak extPeaks[] = list.toArray(new PrmPeak[0]);
        Arrays.sort(extPeaks, new PositionComparator());
        return extPeaks;
    }

    /**
     * generate type 6 PRM peak list: both original spectrum and reverse
     * spectrum. +/-1 Da shift is considered.
     */
    private static PrmPeak[] getSpSixPrmPeak(DeconvPeak peaks[],
            MsHeader header, double spMinMass, ExtendSpPara para) throws Exception {

        double precMonoMass = header.getPrecMonoMass();
        EnumActivation activeType = header.getActivationType();
        ArrayList<PrmPeak> list = new ArrayList<PrmPeak>();
        for (int i = 0; i < peaks.length; i++) {
            if (peaks[i].getMonoMass() <= para.extendMinMass) {
                addTwoMasses(list, peaks[i], precMonoMass, activeType);
            } else {
                addSixMasses(list, peaks[i], precMonoMass, activeType, para.extOffsets);
            }
        }
        filterPrmPeak(list, spMinMass, precMonoMass);
        /* add 0 and precursor mass - 18 */
        DeconvPeak zeroPeak = new DeconvPeak(-1, 0, 0, 0);
        list.add(new PrmPeak(zeroPeak, 0, EnumPrmPeakType.ORIGINAL, 1));
        DeconvPeak precPeak = new DeconvPeak(-1, precMonoMass
                - EnumIonType.PREC.getShift(), 0, 0);
        list.add(new PrmPeak(precPeak, precMonoMass
                - EnumIonType.PREC.getShift(), EnumPrmPeakType.ORIGINAL, 1));
        /* sort by mass */
        PrmPeak extPeaks[] = list.toArray(new PrmPeak[0]);
        Arrays.sort(extPeaks, new PositionComparator());
        return extPeaks;
    }

    /** remove peaks near 0 and prec mass */
    private static void filterPrmPeak(ArrayList<PrmPeak> list,
            double blankMass, double precMass) {
        PrmPeak peaks[] = list.toArray(new PrmPeak[0]);
        for (int i = 0; i < peaks.length; i++) {
            double mass = peaks[i].getPosition();
            if (mass < blankMass || mass > precMass - blankMass) {
                list.remove(peaks[i]);
            }
        }
    }


    private static void setTolerance(PrmPeak peaks[], double precMass,
            PeakTolerance peakTolerance) {
        peaks[0].setStrictTolerance(peakTolerance.compStrictErrorTole(0));
        peaks[0].setNStrictCRelaxTolerance(peakTolerance.compStrictErrorTole(0));
        peaks[0].setNRelaxCStrictTolerance(peakTolerance.compStrictErrorTole(precMass));
        peaks[peaks.length - 1].setStrictTolerance(peakTolerance
                .compStrictErrorTole(precMass));
        peaks[peaks.length - 1].setNStrictCRelaxTolerance(peakTolerance
                .compStrictErrorTole(precMass));
        peaks[peaks.length - 1].setNRelaxCStrictTolerance(peakTolerance
                .compStrictErrorTole(0));

        for (int i = 1; i < peaks.length - 1; i++) {
            /* if peak is m */
            peaks[i].setStrictTolerance(peakTolerance
                    .compStrictErrorTole(peaks[i].getBasePeak().getMonoMass()));
            if (peaks[i].getBaseType() == EnumPrmPeakType.ORIGINAL) {
                peaks[i].setNStrictCRelaxTolerance(peakTolerance
                        .compStrictErrorTole(peaks[i].getBasePeak()
                                .getMonoMass()));
                peaks[i].setNRelaxCStrictTolerance(peakTolerance
                        .compRelaxErrorTole(peaks[i].getBasePeak()
                                .getMonoMass(), precMass));

            } else {
                /*
                 * if the peak is M-m, use base peak and parent mass to compute
                 * the error tolerance
                 */
                peaks[i].setNStrictCRelaxTolerance(peakTolerance.compRelaxErrorTole(
                        peaks[i].getBasePeak().getMonoMass(), precMass));
                peaks[i].setNRelaxCStrictTolerance(peakTolerance
                        .compStrictErrorTole(peaks[i].getBasePeak().getMonoMass()));
            }
        }
    }
    
}
