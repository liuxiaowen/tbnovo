/**
 * Read an MS/MS spectrum from a peak list file.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.iupui.proteomics.spec.deconvsp.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.log4j.Logger;

import edu.iupui.proteomics.base.residue.MassConstant;
import edu.iupui.proteomics.base.util.ReaderUtil;

import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;


public class MsAlignReader {
    private static Logger logger = Logger.getLogger(MsAlignReader.class);

    private BufferedReader input = null;
    protected String[] spectrumStr;
    protected int nCurrent = 1;
    protected Ms<DeconvPeak>[] deconvMses = null;

    public MsAlignReader(File spectrumFile) throws Exception {
        input = new BufferedReader(new InputStreamReader(new FileInputStream(
                spectrumFile), "UTF-8"));
    }

    public static int countSpNum(File spectrumFile) throws Exception {
        MsAlignReader reader = new MsAlignReader(spectrumFile);
        int cnt = 0;
        @SuppressWarnings("unused")
		Ms<DeconvPeak> ms[];
        while ((ms = reader.getNextMses()) != null) {
                cnt++;
        }
        reader.close();
        return cnt;
    }
    
    public String[] readOneSpectrum() throws IOException {
        String line;
        ArrayList<String> lineList = null;
        while ((line = input.readLine()) != null) {
            line = line.trim();
            if (line.equals("BEGIN IONS")) {
                lineList = new ArrayList<String>();
            }
            else if (line.equals("END IONS")) {
                if (lineList == null) {
                    return null;
                }
                else {
                    return lineList.toArray(new String[0]);
                }
            }
            else if (line.equals("")) {
                continue;
            }
            else {
                if (lineList != null) {
                    lineList.add(line);
                }
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    protected void readNext() throws Exception {
        deconvMses = null;
        spectrumStr = readOneSpectrum();
        if (spectrumStr == null) {
            input.close();
            return;
        }
        Properties properties = ReaderUtil.getProperties(spectrumStr);
        int id = -1;
        if (properties.getProperty("ID") != null) {
            id = ReaderUtil.getIntValue(properties, "ID");
        }
        String scans = properties.getProperty("SCANS");
        String activation = properties.getProperty("ACTIVATION");
        String title = properties.getProperty("TITLE");
        
        // precursor mass
        ArrayList<Double> precMass = new ArrayList<Double>();
        String massProp = properties.getProperty("PRECURSOR_MASS");
        if (massProp != null) {
            String[] massStrings = massProp.split("[\\s]+");
            logger.trace("precMassStr " + massProp);
            logger.trace("token number " + massStrings.length);
            for (int i = 0; i < massStrings.length; i++) {
                precMass.add(Double.parseDouble(massStrings[i]));
            }
        }
        // precursor charge
        ArrayList<Integer> precCharge = new ArrayList<Integer>();
        String chargeProp = properties.getProperty("PRECURSOR_CHARGE");
        if (chargeProp != null) {
            String[] chargeStrings = chargeProp.split("[\\s]+");
            for (int i = 0; i < chargeStrings.length; i++) {
                precCharge.add(Integer.parseInt(chargeStrings[i]));
            }
        }
        // check if the header is valid 
        if (precMass.get(0) < 0) {
            logger.warn("Input file format error: sp id " + id + " prec_chrg "
                    + precCharge + " prec mass " + precMass);
            precMass.set(0, new Double(0));
        }
        if (id < 0 || precCharge.get(0) < 0 || precMass.get(0) < 0) {
            logger.error("Input file format error: sp id " + id + " prec_chrg "
                    + precCharge + " prec mass " + precMass);
            System.exit(1);
        }
        
        // peaks
        String peakLines[] = ReaderUtil.getPeakLines(spectrumStr);
        
        DeconvPeak peaks[] = new DeconvPeak[peakLines.length];
        int peakIds[] = new int[peakLines.length];
        for (int i = 0; i < peakIds.length; i++) {
            String[] items = peakLines[i].split("\\s+");
            peaks[i] = new DeconvPeak(i, Double.parseDouble(items[0]), Double.parseDouble(items[1]), Integer.parseInt(items[2]));
        }
        ArrayList<MsHeader> headerList = new ArrayList<MsHeader>();
        logger.trace("PresMass List size " + precMass.size());
        for (int i = 0; i < precMass.size(); i++) {
            MsHeader header = new MsHeader(precCharge.get(i));
            header.setId(id);
            header.setPrecId(i);
            if (title != null) {
                header.setTitle("sp_" + id);
            } else {
                header.setTitle(title);
            }
            if (scans != null) {
                header.setScans(scans);
            }
            else {
                header.setScans("");
            }

            if (activation != null) {
                header.setActivationType(activation);
            }
            header.setPrecMonoMz(precMass.get(i) / precCharge.get(i)
                    + MassConstant.getProtonMass());
            headerList.add(header);
        }
        logger.trace("header list size " + headerList.size());
        deconvMses = new Ms[headerList.size()];
        for (int i = 0; i < headerList.size(); i++) {
            deconvMses[i] = new Ms<DeconvPeak>(peaks, headerList.get(i));
            deconvMses[i].sortOnPos();
        }
        nCurrent++;
    }

    public Ms<DeconvPeak>[] getNextMses() throws Exception {
        readNext();
        return deconvMses;
    }
    
    public String[] getSpectrumStr() {
        return spectrumStr;
    }

    public void close() {
        try {
            input.close();
        } catch (Exception err) {
            logger.fatal(err);
            System.exit(1);
        }
    }

    public ArrayList<Ms<DeconvPeak>> readAllMs() throws Exception {
        ArrayList<Ms<DeconvPeak>> msList = new ArrayList<Ms<DeconvPeak>>();
        Ms<DeconvPeak> deconvSp;
        while ((deconvSp = getNextMses()[0]) != null) {
            msList.add(deconvSp);
        }
        return msList;
    }
}

//public static int countSpNum(File spectrumFile, int minPeakNum,
//double minMass) throws Exception {
//PeakListReader reader = new PeakListReader(spectrumFile);
//int cnt = 0;
//Ms<DeconvPeak> ms[];
//while ((ms = reader.getNextMses()) != null) {
//if (ms[0].size() >= minPeakNum
//      && ms[0].getHeader().getPrecMonoMass() >= minMass) {
//  cnt++;
//}
//}
//reader.close();
//return cnt;
//}
