/**
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.spec.rawsp.simplereader;

public enum EnumInputType {

    MGF("mgf"), MZXML("mzXML");

    String extension;

    EnumInputType(String s) {
        extension = s;
    }

    public String getExtension() {
        return extension;
    }

}
