package edu.iupui.proteomics.spec.convert;

import java.io.File;

import edu.iupui.proteomics.base.ion.EnumActivation;
import edu.iupui.proteomics.base.residue.MassConstant;

import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.deconvsp.reader.MsAlignReader;
import edu.iupui.proteomics.spec.rawsp.writer.MgfWriter;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;


public class MsAlignToMgf {

	public static void main(String[] args) throws Exception {

		String fileName = args[0];
		Ms<DeconvPeak> sp[];
		MsAlignReader reader = new MsAlignReader(new File(fileName));
		MgfWriter writer = new MgfWriter(fileName + "mgf");
		while ((sp = reader.getNextMses()) != null) {
			MsHeader header = sp[0].getHeader();
			if (header.getActivationType() == EnumActivation.CID
					|| header.getActivationType() == EnumActivation.HCD) {
				double mzes[] = new double[sp[0].size()];
				double intensities[] = new double[sp[0].size()];
				for (int i = 0; i < sp[0].size(); i++) {
					mzes[i] = sp[0].getPosition(i)
							+ MassConstant.getIsotopeMass();
					intensities[i] = sp[0].getIntensity(i);
				}
				writer.writeMgf(header, mzes, intensities, true, true);
			}
		}
		writer.close();
	}

}
