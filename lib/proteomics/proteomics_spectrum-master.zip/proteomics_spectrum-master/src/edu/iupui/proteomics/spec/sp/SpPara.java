package edu.iupui.proteomics.spec.sp;

import org.jdom.Element;

import edu.iupui.proteomics.base.ion.EnumActivation;
import edu.iupui.proteomics.base.util.XmlUtil;

import edu.iupui.proteomics.spec.extendsp.ExtendSpPara;
import edu.iupui.proteomics.spec.peak.PeakTolerance;

public class SpPara {
	
	private int minPeakNum;
	private double minMass;
	private PeakTolerance peakTolerance;
	private ExtendSpPara extendSpPara;
	private EnumActivation activationType;

	public SpPara(int minPeakNum, double minMass, PeakTolerance peakTolerance, ExtendSpPara extendSpPara,
			EnumActivation activationType) {
		setMinPeakNum(minPeakNum);
		setMinMass(minMass);
		setPeakTolerance(peakTolerance);
		setExtendSpPara(extendSpPara);
		setActivationType(activationType);
	}

	public PeakTolerance getPeakTolerance() {
		return peakTolerance;
	}

	public void setPeakTolerance(PeakTolerance peakTolerance) {
		this.peakTolerance = peakTolerance;
	}

	public ExtendSpPara getExtendSpPara() {
		return extendSpPara;
	}

	public void setExtendSpPara(ExtendSpPara extendSpPara) {
		this.extendSpPara = extendSpPara;
	}

	public EnumActivation getActivationType() {
		return activationType;
	}

	public void setActivationType(EnumActivation activationType) {
		this.activationType = activationType;
	}

	public int getMinPeakNum() {
		return minPeakNum;
	}

	public void setMinPeakNum(int minPeakNum) {
		this.minPeakNum = minPeakNum;
	}

	public double getMinMass() {
		return minMass;
	}

	public void setMinMass(double minMass) {
		this.minMass = minMass;
	}
	
	public SpPara(Element element) {
		minPeakNum = Integer.parseInt(element.getChildText("min_peak_num"));
		minMass = Double.parseDouble(element.getChildText("min_mass"));
		Element extendSpParaElem = element.getChild("extend_sp_para");
		extendSpPara = new ExtendSpPara(extendSpParaElem);
		Element peakToleElem = element.getChild("peak_tolerance");
		peakTolerance = new PeakTolerance(peakToleElem);
	}
	
	public Element toXml() {
		Element element = new Element("sp_para");
		XmlUtil.addElement(element, "min_peak_num", minPeakNum);
		XmlUtil.addElement(element, "min_mass", minMass);
		element.addContent(extendSpPara.toXml());
		element.addContent(peakTolerance.toXml());
		return element;
	}

}
