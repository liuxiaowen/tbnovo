package edu.iupui.proteomics.spec.deconvsp.reader;

import java.io.File;
import java.io.PrintWriter;

import edu.iupui.proteomics.base.ion.EnumActivation;

import edu.iupui.proteomics.spec.deconvsp.DeconvPeak;
import edu.iupui.proteomics.spec.sp.Ms;
import edu.iupui.proteomics.spec.sp.MsHeader;


public class MsAlignSelectSpByType {

    public static void main(String[] args) throws Exception {

        String fileName = args[0];

        Ms<DeconvPeak> sp[];
        MsAlignReader reader = new MsAlignReader(new File(fileName));
        PrintWriter out = new PrintWriter(fileName + "selection");
        while ((sp = reader.getNextMses()) != null) {
            MsHeader header = sp[0].getHeader();
            if (header.getActivationType() == EnumActivation.CID
                    || header.getActivationType() == EnumActivation.HCD) {
                String str[] = reader.getSpectrumStr();
                out.println("BEGIN IONS");
                for (int i = 0; i < str.length; i++) {
                    out.println(str[i]);
                }
                out.println("END IONS");
                out.println();

            }
        }
        out.close();
    }

}
