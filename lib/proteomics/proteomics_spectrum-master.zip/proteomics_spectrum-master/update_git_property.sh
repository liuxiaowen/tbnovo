echo -n "build=" > git.properties
git rev-list --count HEAD >> git.properties
