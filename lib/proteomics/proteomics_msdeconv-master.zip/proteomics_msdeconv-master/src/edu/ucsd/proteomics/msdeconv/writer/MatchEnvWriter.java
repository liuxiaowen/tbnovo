/**
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.writer;

import java.io.FileOutputStream;
import java.io.PrintWriter;

import com.jap.proteomics.spec.deconvsp.DeconvPeak;
import com.jap.proteomics.spec.deconvsp.writer.PufWriter;
import com.jap.proteomics.spec.rawsp.writer.MascotMgfWriter;
import com.jap.proteomics.spec.rawsp.writer.MgfWriter;
import com.jap.proteomics.spec.sp.Ms;
import com.jap.proteomics.spec.sp.MsHeader;

import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.env.MatchEnvArrayUtil;

public class MatchEnvWriter {

    private PrintWriter out;
    private int id;
    private EnumOutputType type;

    public MatchEnvWriter(String fileName, EnumOutputType type)
            throws Exception {
        /* output mgf file */
        out = new PrintWriter(new FileOutputStream(fileName + "."
                + type.getExtension()));
        id = 1;
        this.type = type;
        if (type == EnumOutputType.PUF) {
            PufWriter.writePufHead(out);
        }
    }

    /**
     * Write an MatchEnv List.
     */
    public void write(MatchEnv oriEnvs[], MsHeader header) throws Exception {

        MatchEnv envs[] = MatchEnvArrayUtil.sortOnMass(oriEnvs);
        double mzs[] = MatchEnvArrayUtil.getMassList(envs);
        double chargeOneMzs[] = MatchEnvArrayUtil.getChargeOneMassList(envs);
        double intensities[] = MatchEnvArrayUtil.getIntensitySums(envs);
        if (type == EnumOutputType.TEXT) {
            // order in original envs
            TextWriter.writeText(out, oriEnvs, header);
        } else if (type == EnumOutputType.MSALIGN) {
            // order in original envs
            MsAlignWriter.writeText(out, oriEnvs, header, id - 1);
        } else if (type == EnumOutputType.HARDKLOR) {
            // order in original envs
            HardklorWriter.writeText(out, oriEnvs, header);
        } else if (type == EnumOutputType.PUF) {
            // order based on mass
            Ms<DeconvPeak> ms = new Ms<DeconvPeak>(header);
            for (int i = 0; i < envs.length; i++) {
            	ms.add(new DeconvPeak(i, mzs[i], intensities[i], envs[i].getRealEnv().getCharge()));
            }
            PufWriter.writeExpe(out, id, ms);
        } else if (type == EnumOutputType.MGF) {
            // order based on mass
            MgfWriter.writeMgf(out, header, null, chargeOneMzs, intensities, true, true);
        } else if (type == EnumOutputType.MASCOT) {
            MascotMgfWriter.writeMgf(out, header, null, chargeOneMzs, intensities, true, true);
        } else if (type == EnumOutputType.DETAIL) {
            out = new PrintWriter(new FileOutputStream("scan_" + header.getScansString() + ".env"));
            DetailWriter.writeEnv(out, envs, header);
            out.close();
        } else {
            throw new Exception("Invalid output type!");
        }
        id++;
    }

    public void close() throws Exception {
        if (type == EnumOutputType.PUF) {
            PufWriter.writePufTail(out);
        }
        out.close();
    }
}
