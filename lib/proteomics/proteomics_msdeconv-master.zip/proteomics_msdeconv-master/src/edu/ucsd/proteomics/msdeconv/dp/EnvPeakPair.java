/**
 * A pair of envelope and peak position idx;
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.dp;

import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class EnvPeakPair implements Cloneable {

    private MatchEnv env;
    private int posIdx;

    public EnvPeakPair(MatchEnv env, int posIdx) {
        this.env = env;
        this.posIdx = posIdx;
    }

    public MatchEnv getMatchEnv() {
        return env;
    }

    public int getPosIdx() {
        return posIdx;
    }

    public double getTheoIntensity() {
        return env.getTheoEnv().getIntensity(posIdx);

    }

    public Object clone() throws CloneNotSupportedException {
        Object clone = super.clone();
        return clone;
    }

    public double getPeakScore(double intensitySum, double tolerance) {
        return env.calcPeakScr(posIdx, intensitySum, tolerance);
    }
}
