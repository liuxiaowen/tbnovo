/**
 * DP algorithm
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.dp;

import java.util.ArrayList;
import java.util.Collections;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.data.DeconvData;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class DpB extends Dp {

    private VertexB vertices[][];

    public DpB(DeconvData data, MatchEnv winEnvs[][], DeconvMng mng)
            throws Exception {
        super(data, winEnvs, mng);
        initGraph();
        dp();
        backtrace();
    }

    public void initGraph() throws Exception {
        /* use win_num + 2 columns */
        vertices = new VertexB[nWindow + 2][];
        MatchEnv empty[] = new MatchEnv[0];
        vertices[0] = VertexListFactory.getVertexBList(data, -1, empty, empty,
                mng);
        vertices[1] = VertexListFactory.getVertexBList(data, 0, empty,
                winEnvs[0], mng);
        for (int i = 1; i < nWindow; i++) {
            vertices[i + 1] = VertexListFactory.getVertexBList(data, i,
                    winEnvs[i - 1], winEnvs[i], mng);
        }
        vertices[nWindow + 1] = VertexListFactory.getVertexBList(data, nWindow,
                winEnvs[nWindow - 1], empty, mng);
    }

    public void dp() {
        for (int i = 1; i < nWindow + 2; i++) {
            for (int j = 0; j < vertices[i].length; j++) {
                VertexB curVertex = vertices[i][j];
                for (int k = 0; k < vertices[i - 1].length; k++) {
                    VertexB prevVertex = vertices[i - 1][k];
                    if (Vertex.checkConsist(prevVertex, curVertex,
                            mng.maxEnvNumPerPeak)) {
                        double newScore = VertexB.getShareScr(prevVertex,
                                curVertex);
                        for (int curNum = 0; curNum <= mng.dpEnvNum; curNum++) {
                            int prevNum = curNum
                                    - curVertex.getPreMatchEnvSize();
                            if (prevNum >= 0) {
                                double curScore = prevVertex.getScoreB(prevNum)
                                        + newScore;
                                if (curScore > curVertex.getScoreB(curNum)) {
                                    curVertex.setScoreB(curNum, curScore);
                                    curVertex.setPrevB(curNum, k);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /** backtracking */
    public void backtrace() {
        int bestVertex = -1;
        double bestScore = Float.NEGATIVE_INFINITY;
        for (int i = 0; i < vertices[nWindow + 1].length; i++) {
            double curScore = vertices[nWindow + 1][i].getScoreB(mng.dpEnvNum);
            if (curScore > bestScore) {
                bestVertex = i;
                bestScore = curScore;
            }
        }
        result = new ArrayList<MatchEnv>();
        int num = mng.dpEnvNum;
        for (int i = nWindow + 1; i >= 1; i--) {
            if (vertices[i][bestVertex].getPrevB(num) >= 0) {
                addEnv(result, vertices[i][bestVertex].getPreMatchEnv());
            }
            bestVertex = vertices[i][bestVertex].getPrevB(num);
            num = mng.dpEnvNum - result.size();
            if (bestVertex < 0) {
                break;
            }
        }
        Collections.sort(result);
    }
}
