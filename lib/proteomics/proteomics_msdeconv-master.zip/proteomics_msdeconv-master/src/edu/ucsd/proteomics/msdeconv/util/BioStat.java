/**
 * Describes an MS/MS spectrum.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.util;

import org.apache.log4j.Logger;

import com.jap.proteomics.base.util.BioArray;


public class BioStat {
    private static Logger logger = Logger.getLogger(BioStat.class);
    private static double intervalWidth = 10f;

    public static IntvDens[] getDensity(double inte[]) {
        double maxInte = BioArray.getMax(inte);
        if (maxInte > 10000) {
            intervalWidth = maxInte / 1000;
        }
        int nTotal = inte.length;
        int nInterval = (int)Math.round(maxInte / intervalWidth) + 1;
        IntvDens dens[] = new IntvDens[nInterval];
        for (int i = 0; i < nInterval; i++) {
            double bgn = i * intervalWidth;
            double end = (i + 1) * intervalWidth;
            int num = 0;
            for (int j = 0; j < nTotal; j++) {
                if (inte[j] > bgn && inte[j] <= end) {
                    num++;
                }
            }
            dens[i] = new IntvDens(bgn, end, num, num / (float) nTotal);
        }
        return dens;
    }

    public static void outputDens(IntvDens dens[]) {
        for (int i = 0; i < dens.length; i++) {
            System.out.println(dens[i].getBgn() + " " + dens[i].getEnd() + " "
                    + dens[i].getNum() + " " + dens[i].getPerc());
        }
    }

    public static int getMaxPos(IntvDens dens[]) {
        int maxPos = -1;
        int maxNum = -1;
        for (int i = 0; i < dens.length; i++) {
            if (dens[i].getNum() > maxNum) {
                maxNum = dens[i].getNum();
                maxPos = i;
            }
        }
        return maxPos;
    }

    public static double getBaseLine(double inte[]) {
        logger.debug("get density ");
        IntvDens dens[] = getDensity(inte);
        logger.debug("get max pos ");
        int maxPos = getMaxPos(dens);
        return dens[maxPos].getBgn();
    }
}
