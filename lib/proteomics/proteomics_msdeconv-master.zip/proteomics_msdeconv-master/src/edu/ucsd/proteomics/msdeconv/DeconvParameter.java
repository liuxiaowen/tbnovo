/**
 *  Xiaowen Liu
 *  Jan 2, 2009
 *  
 *  This class is used to store the input parameters.
 */

package edu.ucsd.proteomics.msdeconv;


import com.jap.proteomics.spec.rawsp.simplereader.EnumInputType;

import edu.ucsd.proteomics.msdeconv.writer.EnumOutputType;

public class DeconvParameter {

    private String dataFileName;
    public EnumInputType inputType = EnumInputType.MZXML;
    public EnumOutputType outputType;

    public boolean doCentroid;
    public boolean doRefinePrecMass;
    public int msLevel; //ms level
    public boolean missingLevelOne;

    public int maxCharge;
    public double maxMass;
    public double tolerance;
    public double snRatio;
    public boolean keepUnusedPeaks;

    public boolean outputMultipleMass = false; 

    public double precursorWindow;

    public int setOutputType (String format) {
        if (format.equals("mgf")) {
            outputType = EnumOutputType.MGF;
        } else if (format.equals("mascot")) {
            outputType = EnumOutputType.MASCOT;
        } else if (format.equals("text")) {
            outputType = EnumOutputType.TEXT;
        } else if (format.equals("puf")) {
            outputType = EnumOutputType.PUF;
        } else if (format.equals("detail")) {
            outputType = EnumOutputType.DETAIL;
        } else if (format.equals("msalign")) {
            outputType = EnumOutputType.MSALIGN;
        } else if (format.equals("hardklor")) {
            outputType = EnumOutputType.HARDKLOR;
        } else {
            return 1;
        }

        return 0;
    }

    public int setInputType (String format) {
        if (format.equals("mgf")) {
            inputType = EnumInputType.MGF;
        } else if (format.equals("mzXML")) {
            inputType = EnumInputType.MZXML;
        } else {
            return 1;
        }
        return 0;
    }
    
    public void setDataFileName(String fileName) {
        this.dataFileName = fileName;
    }
    
    public String getDataFileName() {
        return dataFileName;
    }
}
