/**
 * A base class for Ms reader.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */
package edu.ucsd.proteomics.msdeconv.sp.reader;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.rawsp.simplereader.MsSimpleReader;
import com.jap.proteomics.spec.sp.Ms;
import com.jap.proteomics.spec.sp.MsHeader;
import com.jap.proteomics.spec.sp.PeakList;

import edu.ucsd.proteomics.msdeconv.PrecDeconv;
import edu.ucsd.proteomics.msdeconv.sp.centroid.Centroid;

public abstract class MsReader {

    private static PrecDeconv deconv;

    protected boolean doCentroid = false;
    protected boolean doRefinePrecMass = false;
    MsSimpleReader reader;
    Ms<RawPeak> msOne;
    
    public MsReader () throws Exception {
    }

    public MsReader(double windowSize) throws Exception {
    	deconv = new PrecDeconv(windowSize);
    }


    public Ms<RawPeak> getNextMs() throws Exception {
        reader.readNext();
        PeakList<RawPeak> peakList = reader.getPeakList();
        if (peakList == null) {
            return null;
        }
        PeakList<RawPeak> resultList;
        if (doCentroid) {
            Centroid centroid = new Centroid();
            resultList = centroid.go(peakList);
        } else {
            resultList = peakList;
        }
        MsHeader header = reader.getMsHeader();
        Ms<RawPeak> ms = new Ms<RawPeak>(resultList, header);
        
        /* update ms_1 */
        if (header.getMsLevel() == 1) {
            msOne = ms;
        }
        if (doRefinePrecMass && header.getMsLevel() == 2 && msOne != null) {
            refinePrecChrg(msOne, ms);
        } else {
            if (header.getPrecSpMz() != 0.0) {
                header.setPrecMonoMz(header.getPrecSpMz());
            }
        }
        return ms;
    }

    /** refine precursor charge and mz */
    public static void refinePrecChrg(Ms<RawPeak> msOne, Ms<RawPeak> msTwo) {
        MsHeader headerTwo = msTwo.getHeader();
        double precAvgMz = headerTwo.getPrecSpMz();
        int precChrg = headerTwo.getPrecChrg();

        try {
            deconv.setData(msOne, precAvgMz, precChrg);
            deconv.run();
            if (deconv.getNewPrecChrg() > 0 && deconv.getNewPrecMonoMz() > 0) {        
                headerTwo.setPrecMonoMz(deconv.getNewPrecMonoMz());
                headerTwo.setPrecChrg(deconv.getNewPrecChrg());
            }
        } catch (Exception e) {
        }
    }

    public void setCentroid(boolean centroid) {
        this.doCentroid = centroid;
    }

    public void setRefinePrec(boolean doRefinePrecMass) {
        this.doRefinePrecMass = doRefinePrecMass;
    }
    
    public MsSimpleReader getSimpleReader() {
    	return reader;
    }
    
    public Ms<RawPeak> getMsOne() {
    	return msOne;
    }
}
