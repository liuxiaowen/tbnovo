/**
 * DP algorithm
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.dp;

import java.util.ArrayList;
import java.util.Collections;

import org.apache.log4j.Logger;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.data.DeconvData;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class DpA extends Dp {

    private static Logger logger = Logger.getLogger(DpA.class);

    private VertexA vertices[][];

    public DpA(DeconvData data, MatchEnv winEnvs[][], DeconvMng mng)
            throws Exception {
        super(data, winEnvs, mng);
        initGraph();
        dp();
        backtrace();
    }

    public void initGraph() throws Exception {
        /* use win_num + 2 columns */
        vertices = new VertexA[nWindow + 2][];
        MatchEnv empty[] = new MatchEnv[0];
        vertices[0] = VertexListFactory.getVertexAList(data, -1, empty, empty,
                mng);
        vertices[1] = VertexListFactory.getVertexAList(data, 0, empty,
                winEnvs[0], mng);
        for (int i = 1; i < nWindow; i++) {
            vertices[i + 1] = VertexListFactory.getVertexAList(data, i,
                    winEnvs[i - 1], winEnvs[i], mng);
        }
        vertices[nWindow + 1] = VertexListFactory.getVertexAList(data, nWindow,
                winEnvs[nWindow - 1], empty, mng);
        int cnt = 0;
        for (int i = 0; i <= nWindow + 1; i++) {
            cnt += vertices[i].length;
        }
        logger.debug("Vertex count " + cnt);
    }

    public void dp() {
        int cnt = 0;
        for (int i = 1; i < nWindow + 2; i++) {
            for (int j = 0; j < vertices[i].length; j++) {
                VertexA curVertex = vertices[i][j];
                for (int k = 0; k < vertices[i - 1].length; k++) {
                    VertexA prevVertex = vertices[i - 1][k];
                    if (Vertex.checkConsist(prevVertex, curVertex,
                            mng.maxEnvNumPerPeak)) {
                        cnt++;
                        double newScore = VertexA.getShareScr(prevVertex,
                                curVertex);
                        double curScore = prevVertex.getScrA() + newScore;
                        if (curScore > curVertex.getScrA()) {
                            curVertex.setScrA(curScore);
                            curVertex.setPreA(k);
                        }
                    }
                }
            }
        }
        logger.debug("Edge count :" + cnt);
    }

    /** backtracking */
    public void backtrace() {
        int bestVertex = -1;
        double bestScore = Float.NEGATIVE_INFINITY;
        for (int i = 0; i < vertices[nWindow + 1].length; i++) {
            double curScore = vertices[nWindow + 1][i].getScrA();
            if (curScore > bestScore) {
                bestVertex = i;
                bestScore = curScore;
            }
        }
        result = new ArrayList<MatchEnv>();
        for (int i = nWindow + 1; i >= 1; i--) {
            if (vertices[i][bestVertex].getPreA() >= 0) {
                addEnv(result, vertices[i][bestVertex].getPreMatchEnv());
            }
            bestVertex = vertices[i][bestVertex].getPreA();
            if (bestVertex < 0) {
                break;
            }
        }
        Collections.sort(result);
    }
}
