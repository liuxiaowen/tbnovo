/**
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.ucsd.proteomics.msdeconv.writer;

public enum EnumOutputType {

    MGF("mgf"), MASCOT("mgf"), TEXT("txt"), PUF("puf"), DETAIL("detail"), MSALIGN("msalign"), HARDKLOR(
            "hdk");

    String extension;

    EnumOutputType(String s) {
        extension = s;
    }

    public String getExtension() {
        return extension;
    }

}
