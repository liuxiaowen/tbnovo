package edu.ucsd.proteomics.msdeconv.util;

public class IntvDens {

    private double bgn, end;
    private int num;
    private double perc;

    public IntvDens(double bgn, double end, int num, double perc) {
        this.bgn = bgn;
        this.end = end;
        this.num = num;
        this.perc = perc;
    }

    public double getBgn() {
        return bgn;
    }

    public double getEnd() {
        return end;
    }

    public double getMiddle() {
        return (bgn + end) / 2;
    }

    public int getNum() {
        return num;
    }

    public double getPerc() {
        return perc;
    }
}
