/**
 * Describes an envolope
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.env;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.jap.proteomics.base.residue.MassConstant;
import com.jap.proteomics.base.util.BioArray;
import com.jap.proteomics.spec.peak.PeakUtil;
import com.jap.proteomics.spec.rawsp.RawPeak;


public class Env {
    private static Logger logger = Logger.getLogger(Env.class);
    /**
     * Index of the reference peak in the envelope. The refernce peak is higest
     * peak in the theoretical envelope. In a real-theretical envelope pair,
     * their reference peak should have the same m/z.
     */
    protected int referIdx;
    /** Charge of the envolope */
    protected int charge;
    /** Theoretical m/z value of monoisotopic ion */
    protected double monoMz;
    /** m/z list of all peaks in this envelope */
    protected double[] mzs;
    /** intensity list of all peaks in this envelope */
    protected double[] intensities;

    protected ArrayList<RawPeak> peakList;
    
    public Env() {
    }
    
    public Env(Env env) {
    	this.referIdx = env.referIdx;
    	this.charge = env.charge;
    	this.monoMz = env.monoMz;
    	this.mzs = (double[])env.mzs.clone();
    	this.intensities = (double[])env.intensities.clone();
    }

    /**
     * Constructs an envelop with an output string from EMASS.
     * 
     * @param num
     *            The number of peaks.
     * @param str
     *            The output string of EMASS.
     */
    public Env(int num, String str) throws Exception {
        int nPeak = num;
        charge = 1;
        BufferedReader reader = new BufferedReader(new StringReader(str));
        String line = reader.readLine();
        StringTokenizer st = new StringTokenizer(line);
        for (int i = 0; i < 8; i++) {
            st.nextToken();
        }
        monoMz = Double.parseDouble(st.nextToken());
        mzs = new double[nPeak];
        intensities = new double[nPeak];
        for (int i = 0; i < nPeak; i++) {
            line = reader.readLine();
            st = new StringTokenizer(line);
            mzs[i] = Double.parseDouble(st.nextToken());
            intensities[i] = Double.parseDouble(st.nextToken()) / 100;
        }
        referIdx = BioArray.getMaxPos(intensities);
    }

    public Env(int referIdx, int charge, double monoMz,
            double mzs[], double intensities[]) {
        this.referIdx = referIdx;
        this.charge = charge;
        this.monoMz = monoMz;
        this.mzs = mzs;
        this.intensities = intensities;
    }

    /**
     * Convert a theoretical distribution to a theoretical envelope
     * 
     * @param newBaseMz
     *            The m/z value of base peak.
     * @param newCharge
     *            The charge of theoretical envelope.
     */
    public Env distrToTheoBase(double newBaseMz, int newCharge) {
        double massDifference = newBaseMz * newCharge - mzs[referIdx];
        return convertToTheo(massDifference, newCharge);
    }

    /**
     * Convert a theoretical distribution to a theoretical envelope based on the
     * monoisotopic m/z
     * 
     * @param newMonoMz
     *            The m/z value of new monoisotopic peak.
     * @param newCharge
     *            The charge of theoretical envelope.
     */
    public Env distrToTheoMono(double newMonoMz, int newCharge) {
        double massDifference = newMonoMz * newCharge - monoMz;
        return convertToTheo(massDifference, newCharge);
    }

    public Env convertToTheo(double massDifference, int newCharge) {
        Env theoEnv = null;
        try {
            theoEnv = new Env(this);
        } catch (Exception e) {
            logger.fatal(e);
            System.exit(1);
        }
        theoEnv.charge = newCharge;
        /* here mono_mz is from isotopoic mass distribution */
        theoEnv.monoMz = (monoMz + massDifference) / newCharge;
        for (int i = 0; i < mzs.length; i++) {
            theoEnv.mzs[i] = (mzs[i] + massDifference) / newCharge;
        }
        return theoEnv;
    }

    /**
     * Change the absolute intensities of peaks.
     * 
     * @param ratio
     *            The ratio between new intensity and old intensity.
     */
    public void changeIntensity(double ratio) {
        for (int i = 0; i < intensities.length; i++) {
            intensities[i] *= ratio;
        }
    }

    /**
     * Change the absolute intensities of peaks.
     * 
     * @param ratio
     *            The ratio between new intensity and old intensity.
     */
    public void changeToAbsInte(double absoluteIntensity) {
        double ratio = absoluteIntensity / getReferIntensity();
        changeIntensity(ratio);
    }

    /**
     * Change the mz value of theoretical envelopes.
     * 
     * @param ratio
     *            The ratio between new intensity and old intensity.
     */
    public void changeMz(double shift) {
        for (int i = 0; i < mzs.length; i++) {
            mzs[i] += shift;
        }
        monoMz += shift;
    }

    /**
     * Get a short version of the theoretical envelope
     */
    public Env getSubEnv(double percentageBound, double absoluteMinIntensity,
            int maxBackwardPeakNum, int maxForwardPeakNum) {

        int bounds[] = calcBound(percentageBound, absoluteMinIntensity,
                maxBackwardPeakNum, maxForwardPeakNum);
        return getSubEnv(bounds[0], bounds[1]);
    }

    /**
     * Get a short version of the theoretical envelope
     */
    public Env getSubEnv(int nBack, int nForw) {
        Env subEnv = new Env();
        subEnv.referIdx = nBack;
        subEnv.charge = charge;
        subEnv.monoMz = monoMz;
        int nPeak = nBack + nForw + 1;
        subEnv.mzs = new double[nPeak];
        subEnv.intensities = new double[nPeak];
        int baseIdx = referIdx - nBack;
        for (int i = referIdx - nBack; i <= referIdx + nForw; i++) {
            subEnv.mzs[i - baseIdx] = mzs[i];
            subEnv.intensities[i - baseIdx] = intensities[i];
        }
        return subEnv;
    }

    /**
     * Add zero to the side of the envelope.
     */
    public Env addZero(int num) {
        Env newEnv = new Env();
        int nPeak = mzs.length;
        double newMzs[] = new double[nPeak + num + num];
        double newIntensities[] = new double[nPeak + num + num];
        for (int i = num - 1; i >= 0; i--) {
            newIntensities[i] = 0;
            newMzs[i] = newMzs[i + 1] - MassConstant.getIsotopeMass() / charge;
        }
        for (int i = 0; i < nPeak; i++) {
            newMzs[i + num] = mzs[i];
            newIntensities[i + num] = intensities[i];
        }
        for (int i = nPeak + num; i < nPeak + num * 2; i++) {
            newIntensities[i] = 0;
            newMzs[i] = newMzs[i - 1] + MassConstant.getIsotopeMass() / charge;
        }
        newEnv.referIdx = referIdx + num;
        newEnv.charge = charge;
        newEnv.monoMz = monoMz;
        newEnv.mzs = newMzs;
        newEnv.intensities = newIntensities;
        return newEnv;
    }

    /**
     * Compute the bound of highest peaks with intensity 85%.
     */
    private int[] calcBound(double percentageBound, double absoluteMinIntensity,
            int maxBackwardPeakNum, int maxForwardPeakNum) {
        double forwardIntensity;
        double backwardIntensity;
        int forwardIdx; /* forward index */
        int backwardIdx; /* backward index */
        /*
         * current sum of intensities
         */
        double sum = intensities[referIdx];
        forwardIdx = referIdx + 1;
        backwardIdx = referIdx - 1;
        /* if sum of intensity is above 85%, stop */
        double intensitySum = compIntensitySum();
        int nPeak = mzs.length;
        while (sum / intensitySum < percentageBound) {
            /* if all peaks are included, stop */
            if (backwardIdx == -1 && forwardIdx == nPeak) {
                break;
            }
            /* compute intensity at forward index */
            if (forwardIdx == nPeak) {
                forwardIntensity = 0;
            } else {
                forwardIntensity = intensities[forwardIdx];
            }
            /* compute intensity at backward index */
            if (backwardIdx == -1) {
                backwardIntensity = 0;
            } else {
                backwardIntensity = intensities[backwardIdx];
            }
            /* if both forw and back intensities are less than a threshold, stop */
            if (backwardIntensity < absoluteMinIntensity
                    && forwardIntensity < absoluteMinIntensity) {
                break;
            }
            if (backwardIntensity > forwardIntensity) {
                sum += backwardIntensity;
                backwardIdx--;
            } else {
                sum += forwardIntensity;
                forwardIdx++;
            }
        }
        int maxBackNum = referIdx - backwardIdx - 1;
        int maxForwNum = forwardIdx - referIdx - 1;

        if (maxBackNum > maxBackwardPeakNum) {
            maxBackNum = maxBackwardPeakNum;
        }
        if (maxForwNum > maxForwardPeakNum) {
            maxForwNum = maxForwardPeakNum;
        }
        /* return results */
        int result[] = new int[2];
        result[0] = maxBackNum;
        result[1] = maxForwNum;
        return result;
    }

    /**
     * Change the mz value of theoretical envelopes.
     */

    public void shift(int shift) {
        referIdx += shift;
        monoMz += shift * MassConstant.getIsotopeMass() / charge;
    }
    
    public double compIntensitySum() {
        double intensitySum = 0f;
        for (int i = 0; i < intensities.length; i++) {
            intensitySum += intensities[i];
        }
        return intensitySum;
    }

    public double getAvgMz() {
        double sum = 0;
        for (int i = 0; i < mzs.length; i++) {
            if (mzs[i] >= 0) {
                sum = sum + mzs[i] * intensities[i];
            }
        }
        return sum / compIntensitySum();
    }

    public double getAvgMass() {
        return getAvgMz() * charge - charge * MassConstant.getProtonMass();
    }

    /* Get and set */
    public int getCharge() {
        return charge;
    }

    /* get the the number of extra nucleons of a peak */
    public int getLabel(int i) {
        return (int)Math.round((mzs[i] - monoMz) * charge);
    }

    public double getIntensity(int i) {
        return intensities[i];
    }

    public double[] getIntensities() {
        return intensities;
    }

    public double getMonoMass() {
        return PeakUtil.getMass(monoMz, charge);
    }

    public double getMonoMz() {
        return monoMz;
    }

    /** get the m/z difference between mono_mz and reference peak */
    public double getMonoReferDistance() {
        return mzs[referIdx] - monoMz;
    }

    public double getMz(int i) {
        return mzs[i];
    }

    public int getPeakNum() {
        return mzs.length;
    }

    public int getReferIdx() {
        return referIdx;
    }

    public double getReferIntensity() {
        return intensities[referIdx];
    }

    public double getReferMz() {
        return mzs[referIdx];
    }

    public void setIntensity(int i, double intensity) {
        this.intensities[i] = intensity;
    }
}

/*
 * public void setMonoMassShift(double shift) { mono_mass = mono_mass + shift; }
 */
