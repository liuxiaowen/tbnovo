/**
 * Read an MS/MS spectrum from a mgf file.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.sp.reader;

import com.jap.proteomics.spec.rawsp.simplereader.MgfSimpleReader;

public class MgfReader extends MsReader {
    
    public MgfReader(String fileName) throws Exception {
    	reader = new MgfSimpleReader(fileName, true);
    }
}
