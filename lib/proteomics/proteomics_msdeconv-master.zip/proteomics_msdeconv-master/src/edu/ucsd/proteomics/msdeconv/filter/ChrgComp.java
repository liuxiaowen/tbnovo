package edu.ucsd.proteomics.msdeconv.filter;

import java.util.ArrayList;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;

import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.env.RealEnv;

/** compare neighboring charges */
public class ChrgComp {

	/**
	 * compare the envelope with neighboring charge states
	 * 
	 * @param tol
	 *            : mz tolerance for charge comparison
	 */
	public static int comp(PeakList<RawPeak> sp, MatchEnv a, MatchEnv b,
			double tolerance) throws Exception {

		if (isSecondBetter(sp, a, b, tolerance)) {
			return -1;
		}
		if (isSecondBetter(sp, b, a, tolerance)) {
			return 1;
		}
		return 0;
	}

	/** get common peaks in two peak lists */
	private static int[] getCommonPeak(RealEnv envA, RealEnv envB) {
		int[] listA = envA.getPeakIdxList();
		int[] listB = envB.getPeakIdxList();
		int len = listA.length;
		int commonPeaks[] = new int[len];
		for (int i = 0; i < len; i++) {
			commonPeaks[i] = -1;
			for (int j = 0; j < listB.length; j++) {
				if (envA.isExist(i) && listA[i] == listB[j]) {
					commonPeaks[i] = listA[i];
				}
			}
		}
		return commonPeaks;
	}

	/** count the number of common peaks. */
	private static int cntCommonPeak(int listA[]) {
		int cnt = 0;
		for (int i = 0; i < listA.length; i++) {
			if (listA[i] >= 0) {
				cnt++;
			}
		}
		return cnt;
	}

	/** check if the second charge state is better */
	private static boolean isSecondBetter(PeakList<RawPeak> sp, MatchEnv a,
			MatchEnv b, double tolerance) throws Exception {

		/* get common peak */
		int commonPeaks[] = getCommonPeak(a.getRealEnv(), b.getRealEnv());
		int nCommon = cntCommonPeak(commonPeaks);
		if (nCommon <= 6) {
			return false;
		}
		/* get distance list */
		ArrayList<Double> dist = new ArrayList<Double>();
		for (int i = 0; i < commonPeaks.length; i++) {
			for (int j = i + 1; j < commonPeaks.length; j++) {
				if (commonPeaks[i] >= 0 && commonPeaks[j] >= 0) {
					dist.add((sp.getPosition(commonPeaks[j]) - sp
							.getPosition(commonPeaks[i]))
							/ (j - i));
				}
			}
		}
		/* check if the distance is near to 1/(chrg_a) or 1/(chrg+b) */
		int cntA = 0;
		int cntB = 0;
		double centerA = 1f / a.getTheoEnv().getCharge();
		double centerB = 1f / b.getTheoEnv().getCharge();
		for (int i = 0; i < dist.size(); i++) {
			double d = dist.get(i);
			if (Math.abs(d - centerA) < Math.abs(d - centerB)
					&& Math.abs(d - centerA) < tolerance) {
				cntA++;
			}
			if (Math.abs(d - centerB) < Math.abs(d - centerA)
					&& Math.abs(d - centerB) < tolerance) {
				cntB++;
			}
		}
		if (cntB > cntA) {
			return true;
		} else {
			return false;
		}
	}
}
