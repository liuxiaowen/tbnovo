/**
 * MSDeconv using mzXML files as input and merge similar MS/MS spectra
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.rawsp.simplereader.EnumInputType;
import com.jap.proteomics.spec.sp.Ms;
import com.jap.proteomics.spec.sp.MsHeader;
import com.jap.proteomics.spec.sp.PeakList;

import edu.ucsd.proteomics.msdeconv.Deconv;
import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.sp.reader.MgfReader;
import edu.ucsd.proteomics.msdeconv.sp.reader.MsReader;
import edu.ucsd.proteomics.msdeconv.sp.reader.MzXmlSingleReader;
import edu.ucsd.proteomics.msdeconv.version.Version;
import edu.ucsd.proteomics.msdeconv.writer.MatchEnvWriter;


public class DeconvProcess extends Thread {

    private static Logger logger = Logger.getLogger(DeconvProcess.class);

    DeconvParameter para;

	String msg = "";
	int result = 0;

	public DeconvProcess(DeconvParameter para) {
        this.para = para;
    }

    public void run() {
		try {
			process();
		} catch (Exception e) {
			logger.warn(e);
			result = 1;
			msg = "Error in MS-Deconv\n" + e.getMessage();
			return;
		}
		result = 0;
    }

	public synchronized void updateMsg(MsHeader header, int scan, int nTotalScan) {
		String percentage = Integer.toString(scan * 100
				/ nTotalScan);
		msg = "Processing spectrum " + header.getTitle() + "...";
		while (msg.length() < 40) {
			msg += " ";
		}
		msg = msg + percentage + "% finished.";
	}


    public void process() throws Exception {

        DeconvMng mng = new DeconvMng();
        copyParameters(mng);
        printParameter(mng);

        String fileName = para.getDataFileName();
        // writer
        String baseName = fileName.substring(0, fileName.lastIndexOf('.'))
                + "_msdeconv";
        MatchEnvWriter writer = new MatchEnvWriter(baseName, para.outputType);

        Deconv deconv = new Deconv(mng);

        if (para.inputType == EnumInputType.MZXML) {
            MsReader reader = (MsReader) (new MzXmlSingleReader(fileName, mng.precDeconvInterval));
            reader.setCentroid(para.doCentroid);
            reader.setRefinePrec(para.doRefinePrecMass);
            processSp(writer, deconv, baseName, reader);
        }
        else if (para.inputType == EnumInputType.MGF) {
            MsReader reader = (MsReader) (new MgfReader(fileName));
            processSp(writer, deconv, baseName, reader);
        }
    }

    public void processSp(MatchEnvWriter writer, Deconv deconv, String baseName, MsReader reader) throws Exception {
        // reader
        int nTotalScan = reader.getSimpleReader().getTotalScanNum();
        Ms<RawPeak> sp;
        MsHeader header;
        int count = 0;
        while ((sp = reader.getNextMs()) != null) {
            if (sp.size() == 0) {
                continue;
            }
            header = sp.getHeader();
            if (header.getMsLevel() == 1 &&  para.msLevel != 1) {
                continue;
            }
            count++;
            int scanNum;
            if (para.inputType == EnumInputType.MGF) {
                scanNum = count;
            }
            else {
                scanNum = header.getFirstScanNum();
            }
			updateMsg(header, scanNum, nTotalScan);
            if (Logger.getRootLogger().getLevel() == Level.ERROR) {
                System.out.print(msg  + "\r");
            }
            logger.info(msg);

            logger.debug("set data....");
            if (header.getMsLevel() == 1) {
                deconv.setData((PeakList<RawPeak>)sp);
            }
            else {
            	if (para.missingLevelOne) {
            		header.setPrecChrg(DeconvMng.defaultMaxCharge);
            		double precMz = DeconvMng.defaultMaxMass/DeconvMng.defaultMaxCharge;
            		header.setPrecMonoMz(precMz);
            		header.setPrecMonoMz(precMz);
            		deconv.setData((PeakList<RawPeak>) sp, DeconvMng.defaultMaxMass, DeconvMng.defaultMaxCharge);
            	}
            	else {
            		deconv.setData((PeakList<RawPeak>) sp, header.getMaxFragMass(), header
                        .getPrecChrg());
            	}
            }
            deconv.run();
            writer.write(deconv.getResult(), header);
        }
        writer.close();
		msg = "Deconvolution finished.\nResult is in " + baseName + "."
				+ para.outputType.getExtension();
        System.out.println("\n" + msg);
    }

    private void copyParameters(DeconvMng mng) throws Exception {
        mng.maxCharge = para.maxCharge;
        mng.maxMass = para.maxMass;
        mng.setTolerance(para.tolerance);
        mng.snRatio = para.snRatio;
        mng.keepUnusedPeaks = para.keepUnusedPeaks;
        mng.outputMultipleMass = para.outputMultipleMass;
        mng.precDeconvInterval = para.precursorWindow;
        //System.out.println("precursor deconvolution interval: " + mng.precDeconvInterval);
    }

    private void printParameter(DeconvMng mng) throws Exception {
        Version version = new Version();
        System.out.println("MS-Deconv " + version.getVersion() + " " + version.getDate());
        System.out.println("********* parameters begin **********");
         System.out.println("output file format:    " +  para.outputType.getExtension());
        if (para.doCentroid) {
            System.out.println("data type:             " + "profile");
        } else {
            System.out.println("data type:             " + "centroided");
        }
        System.out.println("orignal precursor:     " + (!para.doRefinePrecMass));
        System.out.println("maximum charge:        " + mng.maxCharge);
        System.out.println("maximum mass:          " + mng.maxMass);
        System.out.println("m/z error tolerance:   " + mng.mzTolerance);
        System.out.println("sn ratio:              " + mng.snRatio);
        System.out.println("keep unused peak:      " + mng.keepUnusedPeaks);
        System.out.println("output multiple mass:  " + mng.outputMultipleMass);
        System.out.println("********* parameters end   **********");
    }

	public int getResult() {
		return result;
	}

	public String getMsg() {
		return msg;
	}
}
