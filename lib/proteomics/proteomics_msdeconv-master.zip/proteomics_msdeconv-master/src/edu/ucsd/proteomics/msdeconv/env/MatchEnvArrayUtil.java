/**
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.env;

import java.util.Arrays;
import java.util.ArrayList;

import com.jap.proteomics.base.residue.MassConstant;
import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;


public class MatchEnvArrayUtil {

	public static MatchEnv[] sortOnMz(MatchEnv oriEnvs[]) {
		MatchEnv envs[] = new MatchEnv[oriEnvs.length];
		for (int i = 0; i < oriEnvs.length; i++) {
			envs[i] = oriEnvs[i];
		}
		for (int i = 0; i < envs.length; i++) {
			for (int j = i + 1; j < envs.length; j++) {
				if (envs[i].getRealEnv().getReferPeakIdx() > envs[j]
						.getRealEnv().getReferPeakIdx()) {
					MatchEnv tmp = envs[i];
					envs[i] = envs[j];
					envs[j] = tmp;
				}
			}
		}
		return envs;
	}

	public static MatchEnv[] sortOnMass(MatchEnv oriEnvs[]) {
		MatchEnv envs[] = new MatchEnv[oriEnvs.length];
		for (int i = 0; i < oriEnvs.length; i++) {
			envs[i] = oriEnvs[i];
		}
		for (int i = 0; i < envs.length; i++) {
			for (int j = i + 1; j < envs.length; j++) {
				if (envs[i].getRealEnv().getMonoMass() > envs[j].getRealEnv()
						.getMonoMass()) {
					MatchEnv tmp = envs[i];
					envs[i] = envs[j];
					envs[j] = tmp;
				}
			}
		}
		return envs;
	}

	public static double[] getMassList(MatchEnv envs[]) {
		double masses[] = new double[envs.length];
		for (int i = 0; i < envs.length; i++) {
			masses[i] = envs[i].getRealEnv().getMonoMass();
		}
		return masses;
	}

	public static double[] getFloatMassList(MatchEnv envs[]) {
		double masses[] = new double[envs.length];
		for (int i = 0; i < envs.length; i++) {
			masses[i] = envs[i].getRealEnv().getMonoMass();
		}
		return masses;
	}

	public static int[] getChargeList(MatchEnv envs[]) {
		int charges[] = new int[envs.length];
		for (int i = 0; i < envs.length; i++) {
			charges[i] = envs[i].getRealEnv().getCharge();
		}
		return charges;
	}

	public static double[] getChargeOneMassList(MatchEnv envs[]) {
		double masses[] = new double[envs.length];
		for (int i = 0; i < envs.length; i++) {
			masses[i] = envs[i].getRealEnv().getMonoMass()
					+ MassConstant.getProtonMass();
		}
		return masses;
	}

	public static double[] getIntensitySums(MatchEnv envs[]) {
		double intensitySums[] = new double[envs.length];
		for (int i = 0; i < envs.length; i++) {
			intensitySums[i] = envs[i].getTheoEnv().compIntensitySum();
		}
		return intensitySums;
	}

	public static void assignIntensity(PeakList<RawPeak> sp, MatchEnv envs[]) {
		double intensitySums[];
		int nPeak = sp.size();
		intensitySums = new double[nPeak];
		for (int i = 0; i < envs.length; i++) {
			MatchEnv env = envs[i];
			for (int j = 0; j < env.getRealEnv().getPeakNum(); j++) {
				int peak = env.getRealEnv().getPeakIdx(j);
				if (peak >= 0) {
					intensitySums[peak] += env.getTheoEnv().getIntensity(j);
				}
			}
		}
		for (int i = 0; i < envs.length; i++) {
			MatchEnv env = envs[i];
			for (int j = 0; j < env.getRealEnv().getPeakNum(); j++) {
				int peak = env.getRealEnv().getPeakIdx(j);
				if (peak >= 0) {
					Env realEnv = env.getRealEnv();
					double intensity = realEnv.getIntensity(j)
							* env.getTheoEnv().getIntensity(j)
							/ intensitySums[peak];
					realEnv.setIntensity(j, intensity);
				}
			}
		}
	}

	public static PeakList<RawPeak> rmAnnoPeak(PeakList<RawPeak> sp, MatchEnv envs[])
			throws Exception {
		PeakList<RawPeak> newList = new PeakList<RawPeak>(sp);
		int nPeak = newList.size();
		boolean isKeeps[] = new boolean[nPeak];
		Arrays.fill(isKeeps, true);
		for (int i = 0; i < envs.length; i++) {
			int peaks[] = envs[i].getRealEnv().getPeakIdxList();
			for (int j = 0; j < peaks.length; j++) {
				if (peaks[j] >= 0) {
					isKeeps[peaks[j]] = false;
				}
			}
		}
		newList.rmPeaks(isKeeps);
		return newList;
	}

	public static MatchEnv[] addLowMassPeak(MatchEnv envs[], PeakList<RawPeak> sp,
			double tolerance) throws Exception {
		boolean isUses[] = new boolean[sp.size()];
		Arrays.fill(isUses, false);
		for (int i = 0; i < envs.length; i++) {
			MatchEnv env = envs[i];
			for (int j = 0; j < env.getRealEnv().getPeakNum(); j++) {
				int peak = env.getRealEnv().getPeakIdx(j);
				if (peak >= 0) {
					isUses[peak] = true;
				}
			}
		}

		ArrayList<MatchEnv> lowMassEnvList = new ArrayList<MatchEnv>();
		for (int i = 0; i < isUses.length; i++) {
			if (!isUses[i]) {
				lowMassEnvList.add(getNewMatchEnv(sp, i, tolerance));
			}
		}

		MatchEnv result[] = new MatchEnv[lowMassEnvList.size() + envs.length];
		int cnt = 0;
		for (int i = 0; i < lowMassEnvList.size(); i++) {
			result[cnt] = lowMassEnvList.get(i);
			cnt++;
		}
		for (int i = 0; i < envs.length; i++) {
			result[cnt] = envs[i];
			cnt++;
		}
		Arrays.sort(result);
		return result;
	}

	public static MatchEnv getNewMatchEnv(PeakList<RawPeak> sp, int idx, double tolerance)
			throws Exception {
		double mzs[] = new double[1];
		double intensities[] = new double[1];
		mzs[0] = sp.getPosition(idx);
		intensities[0] = sp.getIntensity(idx);
		System.out.println(mzs[0] + "\t" + intensities[0]);
		Env theoEnv = new Env(0, 1, mzs[0], mzs, intensities);
		RealEnv realEnv = new RealEnv(sp, theoEnv, tolerance, 0);
		int massGroup = 0;
		return new MatchEnv(massGroup, theoEnv, realEnv);
	}

    public static MatchEnv[] addMultipleMass(MatchEnv envs[], MatchEnv candidates[][],
            double multiMinMass, int multiMinCharge, double minRatio) {
        ArrayList<MatchEnv> massEnvList = new ArrayList<MatchEnv>();
        for (int i = 0; i < envs.length; i++) {
            /* check if we can use another charge state */
            int charge = envs[i].getRealEnv().getCharge();
            int referPeak = envs[i].getRealEnv().getReferPeakIdx();
            MatchEnv chargeEnvs[] = new MatchEnv[2];
            /** we use non-overlapping envelopes here */
            //System.out.println("refer peak " + referPeak + " charge " + charge);
            chargeEnvs[0] = candidates[referPeak][charge-1];
            double minScore = chargeEnvs[0].getScore() * minRatio;
            chargeEnvs[1] = null;
            if (charge >= multiMinCharge) {
                double scoreMinusOne  = 0;
                if (charge > 1 && candidates[referPeak][charge-2] != null) {
                    scoreMinusOne = candidates[referPeak][charge-2].getScore();
                }
                double scorePlusOne = 0;
                if (charge < candidates[0].length && candidates[referPeak][charge] != null) {
                    scorePlusOne = candidates[referPeak][charge].getScore();
                }
                if (scoreMinusOne > scorePlusOne && scoreMinusOne >= minScore) {
                    chargeEnvs[1] = candidates[referPeak][charge-2];
                }
                else if (scorePlusOne >= minScore) {
                    chargeEnvs[1] = candidates[referPeak][charge];
                }
            }
            for (int j = 0; j < chargeEnvs.length; j++) {
                if (chargeEnvs[j] == null) {
                    continue;
                }
                massEnvList.add(chargeEnvs[j]);
                double mono_mass = chargeEnvs[j].getRealEnv().getMonoMass();
                int peaks[] = chargeEnvs[j].getRealEnv().getPeakIdxList();
                int referIdx = chargeEnvs[j].getRealEnv().getReferIdx();
                if (mono_mass >= multiMinMass) {
                    /* check left shift */
                    if (referIdx > 0) {
                        int p = peaks[referIdx-1];
                        if (p >=0 && candidates[p][charge-1] != null && 
                                candidates[p][charge-1].getScore() >= minScore) {
                            massEnvList.add(candidates[p][charge-1]);
                                }
                    }
                    if (referIdx < peaks.length - 1) {
                        int p = peaks[referIdx+1];
                        if (p >=0 && candidates[p][charge-1] != null && 
                                candidates[p][charge-1].getScore() >= minScore) {
                            massEnvList.add(candidates[p][charge-1]);
                                }
                    }
                }
            }
        }

        return (MatchEnv[])massEnvList.toArray(new MatchEnv[0]);
    }
}
