/**
 * The factory for theoretical peak intensity distributions.
 *
 * @author  Xiaowen Liu
 * @date    2010-3-10
 */

package edu.ucsd.proteomics.msdeconv.detect;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Arrays;

import org.apache.log4j.Logger;

import edu.ucsd.proteomics.msdeconv.env.Env;

public class DistrEnvFactory {

    private static Logger logger = Logger.getLogger(DistrEnvFactory.class);
    /** number of distribution entries */
    private int nEntry;
    /** the mass interval between two neighboring entries */
    private double massInterval;
    /** the list of distribution envelopes */
    private Env envs[];
    /** mapping distribution envelopes to the mass value of base peak */
    private int baseMassIdxes[];

    /**
     * Constructs a theoreticl envelop factory.
     * 
     * @param nEntry
     *            The entry number of the array env[].
     * @param massInterval
     *            The mass difference between two neighboring entries.
     */
    public DistrEnvFactory(String fileName, int nEntry, double massInterval)
            throws Exception {
        logger.debug("Distribution envelope file name " + fileName);
        this.nEntry = nEntry;
        this.massInterval = massInterval;
        envs = new Env[nEntry];
        BufferedReader reader;
        reader = new BufferedReader(new InputStreamReader(this.getClass()
                .getResourceAsStream(fileName)));
        for (int i = 0; i < nEntry; i++) {
            int nPeak = 0;
            String line;
            String str = "";
            while ((line = reader.readLine()) != null) {
                if (line.equals("")) {
                    break;
                }
                nPeak++;
                str = str + line + "\n";
            }
            envs[i] = new Env(nPeak - 1, str);
        }
        reader.close();
        initBaseMassIdx();
    }

    /**
     * Initialize the mappping array between base peak masses and monoisotopic
     * masses
     */
    private void initBaseMassIdx() {
        baseMassIdxes = new int[nEntry];
        Arrays.fill(baseMassIdxes, -1);
        for (int i = 0; i < nEntry; i++) {
            double mz = envs[i].getReferMz();
            int idx = (int) (mz / massInterval);
            if (idx >= 0 && idx < nEntry) {
                baseMassIdxes[idx] = i;
            }
        }
        baseMassIdxes[0] = 0;
        for (int i = 1; i < nEntry; i++) {
            if (baseMassIdxes[i] < 0) {
                baseMassIdxes[i] = baseMassIdxes[i - 1];
            }
        }
    }

    /**
     * Get a distribution envelope based on its monoisotopic mass.
     */
    public Env getEnvByMonoMass(double mass) {
        int idx = (int) (mass / massInterval);
        if (idx < 0) {
            logger.fatal("Invalid mass");
            System.exit(1);
        } else if (idx >= nEntry) {
            logger.trace("mass out of bound");
            return null;
        }
        return envs[idx];
    }

    /**
     * Get a distribution envelope based on its mass of base peak.
     */
    public Env getEnvByBaseMass(double mass) {
        int idx = (int) (mass / massInterval);
        if (idx < 0) {
            logger.fatal("Invalid mass");
            System.exit(1);
        } else if (idx >= nEntry) {
            logger.trace("Mass out of bound");
            return null;
        }
        return envs[baseMassIdxes[idx]];
    }
}
