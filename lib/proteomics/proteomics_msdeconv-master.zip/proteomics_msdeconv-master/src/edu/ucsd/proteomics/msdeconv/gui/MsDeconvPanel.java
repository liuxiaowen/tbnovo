/**
 * @author  Xiaowen Liu
 * @date    2011-05-01
 */

package edu.ucsd.proteomics.msdeconv.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import org.apache.log4j.Logger;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.DeconvParameter;
import edu.ucsd.proteomics.msdeconv.DeconvProcess;


public class MsDeconvPanel extends JPanel
                           implements ActionListener {

 	private static final long serialVersionUID = 1L;

	private Logger logger = Logger.getLogger(MsDeconvPanel.class);

    public static final int NOT_RUNNING = 0;
    public static final int RUNNING = 1;

    private int status = NOT_RUNNING;

    protected int    charge   = DeconvMng.defaultMaxCharge;
    protected double  mass = DeconvMng.defaultMaxMass;
    protected float  tolerance = 0.02f;
    protected float  ratio = 1f;

    private JTextField fileNameField;
    private JButton openButton;

    private JTextField chargeField;
    private JTextField massField;
    private JTextField toleranceField;
    private JTextField ratioField;

    private JComboBox outputComboBox;
    private JComboBox inputComboBox;

    private JCheckBox precursorBox;
    private JCheckBox msOneBox;
    private JCheckBox keepPeakBox;

    private JButton  runButton;
    private JLabel   infoLabel;

    public MsDeconvPanel() {
        setLayout(new BorderLayout());


        //file name
        fileNameField = new JTextField(60);
        fileNameField.setText("");
        fileNameField.addActionListener(this);

        JLabel fileNameLabel = new JLabel("Input file: ");
        //fileNameLabel.setLabelFor(fileNameField);

        openButton = new JButton("Open a File...");
        openButton.addActionListener(this);


        //Lay out the text controls and the labels.
        JPanel fileNamePanel = new JPanel();
        fileNamePanel.setLayout(new FlowLayout());
        fileNamePanel.add(fileNameLabel);
        fileNamePanel.add(fileNameField);
        fileNamePanel.add(openButton);
        add(fileNamePanel, BorderLayout.PAGE_START);

        //charge
        chargeField = new JTextField(10);
        chargeField.setText(Integer.toString(charge));
        chargeField.addActionListener(this);

        //mass
        massField = new JTextField(10);
        massField.setText(Double.toString(mass));
        massField.addActionListener(this);

        //tolerance
        toleranceField = new JTextField(10);
        toleranceField.setText(Float.toString(tolerance));
        toleranceField.addActionListener(this);

        //ratio
        ratioField = new JTextField(10);
        ratioField.setText(Float.toString(ratio));
        ratioField.addActionListener(this);

        //Create some labels for the fields.
        JLabel chargeLabel = new JLabel("Maximum charge: ");
        JLabel massLabel = new JLabel("Maximum mass: ");
        JLabel toleranceLabel = new JLabel("M/z tolerance: ");
        JLabel ratioLabel = new JLabel("S/n ratio: ");

        JCheckBox precursorButton = new JCheckBox("Original precursor mass");
        precursorButton.setSelected(false);
                      
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.LINE_END;
        c.gridx = 0;
        c.gridy = 0;
        leftPanel.add(chargeLabel, c);
        c.gridy = 1;
        leftPanel.add(massLabel, c);
        c.gridy = 2;
        leftPanel.add(toleranceLabel,c);
        c.gridy = 3;
        leftPanel.add(ratioLabel, c);
        c.gridx = 1;
        c.gridy = 0;
        leftPanel.add(chargeField, c);
        c.gridy = 1;
        leftPanel.add(massField, c);
        c.gridy = 2;
        leftPanel.add(toleranceField, c);
        c.gridy = 3;
        leftPanel.add(ratioField, c);
        add(leftPanel, BorderLayout.LINE_START);

        String[] outputFormatStrings = {"MSALIGN", "MASCOT", "MGF", "TEXT"};
        outputComboBox = new JComboBox(outputFormatStrings);

        JLabel outputLabel = new JLabel("Output format: ");

        String[] inputTypeStrings = { "Centroided", "Profile"};
        inputComboBox = new JComboBox(inputTypeStrings);

        JLabel inputLabel = new JLabel("Input type: ");

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridBagLayout());
        c.gridx = 0;
        c.gridy = 0;
        centerPanel.add(outputLabel,c);
        c.gridy = 1;
        centerPanel.add(inputLabel,c);
        c.anchor = GridBagConstraints.LINE_START;
        c.gridx = 1;
        c.gridy = 0;
        centerPanel.add(outputComboBox,c );
        c.gridy = 1;
        centerPanel.add(inputComboBox,c );
        add(centerPanel, BorderLayout.CENTER);

        precursorBox = new JCheckBox("Original Precursor");
        precursorBox.setSelected(false);

        msOneBox = new JCheckBox("Report MS1");
        msOneBox.setSelected(false);

        keepPeakBox = new JCheckBox("Keep peaks not in envelopes");
        keepPeakBox.setSelected(false);

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new GridBagLayout());
        c.gridx = 0;
        c.gridy = 0;
        rightPanel.add(msOneBox,c );
        c.gridy = 1;
        rightPanel.add(keepPeakBox,c );
        c.gridy = 2;
        //rightPanel.add(precursorBox,c );
        add(rightPanel, BorderLayout.LINE_END);

        // run panel
        runButton = new JButton("Run Ms-Deconv");
        runButton.addActionListener(this);

        infoLabel = new JLabel("      ");

        //Lay out the text controls and the labels.
        JPanel runPanel = new JPanel();
        runPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        runPanel.add(runButton);
        runPanel.add(infoLabel);
        add(runPanel, BorderLayout.PAGE_END);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == openButton) {
            JFileChooser chooser = new JFileChooser();
            MzXmlFileFilter filter = new MzXmlFileFilter();
            chooser.setFileFilter(filter);
            int returnVal = chooser.showOpenDialog(this);
            if(returnVal == JFileChooser.APPROVE_OPTION) {
                String name = chooser.getSelectedFile().getAbsolutePath();
                fileNameField.setText(name);
            }
        }
        else if (e.getSource() == runButton) {
            runButton.setEnabled(false);
            process();
        }
    }

    public void process() {
        DeconvParameter para = parse();
        if (para != null) {
            DeconvProcess proc = new DeconvProcess(para);
            proc.start();
            logger.debug("called msdeconv");
            status = RUNNING;
            CheckThread checkThread = new CheckThread(proc, this);
            checkThread.start();
            logger.debug("called checkThread");
        }

    }

    public void setInfoLabel (String msg) {
        infoLabel.setText(msg);
    }
    
    public void activeButton () {
        runButton.setEnabled(true);
    }

    public void setStatus (int status) {
        this.status = status;
    }

    public int getStatus () {
        return status;
    }

	public DeconvParameter parse() {
        try {

            DeconvParameter para = new DeconvParameter();
            // file name
            para.setDataFileName(fileNameField.getText());
            para.maxCharge = Integer.parseInt(chargeField.getText());
            para.maxMass = Float.parseFloat(massField.getText());
            para.tolerance = Float.parseFloat(toleranceField.getText());
            para.snRatio = Float.parseFloat(ratioField.getText());
            String format = (String)outputComboBox.getSelectedItem();
            format = format.trim().toLowerCase();
            int result = para.setOutputType(format);
            if (result > 0) {
                throw new Exception("invalid output type:" + format);
            }

            String type = (String) inputComboBox.getSelectedItem();
            // centroid
            para.doCentroid = false;
            type = type.trim().toLowerCase();
            if (type.equals("profile")) {
                para.doCentroid = true;
            }

            boolean useOriPrec = precursorBox.isSelected();
            // original precursor mass
            para.doRefinePrecMass = true;
            if (useOriPrec) {
                para.doRefinePrecMass = false;
            }

            boolean reportMsOne = msOneBox.isSelected();
            // level
            if (reportMsOne) {
                para.msLevel = 1;
            } else {
                para.msLevel = 2;
            }
            para.keepUnusedPeaks = keepPeakBox.isSelected();
            return para;
        }
        catch (Exception e) {
		    JOptionPane.showMessageDialog(this, e.getMessage());
            return null;
        }
	}
}

