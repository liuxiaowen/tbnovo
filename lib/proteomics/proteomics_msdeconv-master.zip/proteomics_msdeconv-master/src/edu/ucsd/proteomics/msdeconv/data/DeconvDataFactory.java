/**
 * spectrum data factory.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.data;

import org.apache.log4j.Logger;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;

import edu.ucsd.proteomics.msdeconv.DeconvMng;

public class DeconvDataFactory {

	private static Logger logger = Logger.getLogger(DeconvDataFactory.class);

	/**
	 * generate deconvolution data using default max mass, max charge and window
	 * size.
	 */
	public static DeconvData getData(PeakList<RawPeak> peakList, DeconvMng mng)
			throws Exception {

		if (peakList.findMaxPos() > mng.maxMass) {
			logger.warn("Max mz is too large: " + peakList.findMaxPos());
			return null;
		}
		return new DeconvData(peakList, mng.maxMass,
				mng.maxCharge, mng.windowSize);
	}

	/**
	 * generate deconvolution data using given max mass, max charge
	 */
	public static DeconvData getData(PeakList<RawPeak> peakList, double maxMass,
			int maxCharge, DeconvMng mng) throws Exception {

		if (maxCharge < 1) {
			logger.warn("Max charge < 1");
			maxCharge = mng.maxCharge;
		}
		if (maxMass <= 0) {
			logger.warn("Max mass <= 0");
			maxMass = mng.maxMass;
		}
		if (maxMass > mng.maxMass) {
			logger.warn("Max mass is greater than default max mass " + maxMass);
			maxMass = mng.maxMass;
		}
		if (peakList.findMaxPos() > maxMass) {
			logger.warn("Max mz is too large: " + peakList.findMaxPos());
		}
		for (int i = 0; i < peakList.size(); i++) {
			if (peakList.getPosition(i) < 0 || peakList.getIntensity(i) < 0) {
				logger.warn("mz intensity are negative values");
				return null;
			}
		}
		return new DeconvData(peakList, maxMass, maxCharge,
				mng.windowSize);
	}
}
