/**
 * MSDeconv using mzXML files as input and merge similar MS/MS spectra
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.console;

import com.jap.proteomics.base.util.BioIo;

import jargs.gnu.CmdLineParser;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.DeconvParameter;
import edu.ucsd.proteomics.msdeconv.DeconvProcess;
import edu.ucsd.proteomics.msdeconv.version.Version;

public class MsDeconvConsole {

    public static void main(String[] args) throws Exception {
        try {
            DeconvParameter para = parseArgs(args);
            DeconvProcess process = new DeconvProcess(para);
            process.process();
        } catch (Exception e) {
            System.out.println(BioIo.getStackTraceAsString(e));
            System.exit(1);
        } catch (Error e) {
            System.out.println(BioIo.getStackTraceAsString(e));
            System.exit(1);
        }
    }

    private static void printUsage() throws Exception {
        Version version = new Version();
        String usage = "\nMS-Deconv" + version.getVersion() + "\n";
        usage += "\nUsage: java -Xmx2000M -jar MsDeconvConsole.jar input_file [options]\n";
        usage += "\n";
        usage += "-o, --output <mgf|text|msalign>\n";
        usage += "       Output file format: mgf, text or msalign. Default format is mgf.\n";
        usage += "-t, --type <centroided|profile>\n";
        usage += "       Input file type: centroided or profile. Default type is centroided.\n";
        usage += "-p, --precusor\n";
        usage += "       Using precursor masses of MS2 spectra in original data files.\n";
        usage += "-l, --level-one\n";
        usage += "       Report deconvolution results for MS1 spectra.\n";
        usage += "-k, --keep\n";
        usage += "       Report peaks not in good isotopic envelopes.\n";
        usage += "-c  --max-charge <integer value>\n";
        usage += "       Set the maximum charge state of spectra. Default value is 30.\n";
        usage += "-m  --max-mass   <float value>\n";
        usage += "       Set the maximum monoisopotic mass of fragment ions.\n";
        usage += "       Default value is 49000.\n";
        usage += "-e  --mz-error   <float value>\n";
        usage += "       Set the error tolerance of m/z values of peaks.\n";
        usage += "       Default value is 0.02.\n";
        usage += "-s  --sn-ratio   <float value>\n";
        usage += "       Set the signal/noise ratio. Default value is 1.\n";
        usage += "-u, --multiple-mass\n";
        usage += "       Output multiple masses for one envelope.\n";
	usage += "-n, --missing-level-one\n";
	usage += "       No MS1 spectra.\n";
	usage += "-w, --precursor-window\n";
	usage += "       Precursor window size.\n";
        usage += "\n";
        usage += "Examples:\n";
        usage += "\n";
        usage += "# deconvolute centroided data spectra.mzXML to mgf file spectra_msdeconv.mgf\n\n";
        usage += "java -jar msdeconv.jar spectra.mzXML\n";
        usage += "\n";
        usage += "# deconvolute centroided data spectra.mzXML to text file spectra_msdeconv.txt\n\n";
        usage += "java -jar msdeconv.jar spectra.mzXML -o text\n";
        usage += "\n";
        usage += "# deconvolute profile data spectra.mzXML to spectra_msdeconv.mgf\n\n";
        usage += "java -jar msdeconv.jar spectra.mzXML -t profile\n";
        usage += "\n";
        usage += "# deconvolute centroided data spectra.mzXML to spectra_msdeconv.mgf by using orignial precursor masses\n\n";
        usage += "java -jar msdeconv.jar spectra.mzXML -p\n";
        usage += "\n";
        usage += "# deconvolute centroided data spectra.mzXML to spectra_msdeconv.mgf and report results of both MS1 and MS2 spectra\n\n";
        usage += "java -jar msdeconv.jar spectra.mzXML -l\n";
        usage += "\n";
        System.err.print(usage);
    }

    private static DeconvParameter parseArgs(String args[]) throws Exception {
        CmdLineParser parser = new CmdLineParser();
        CmdLineParser.Option inputOption = parser.addStringOption('i', 
                "input");
        CmdLineParser.Option outputOption = parser.addStringOption('o',
                "output");
        CmdLineParser.Option typeOption = parser.addStringOption('t', "type");
        CmdLineParser.Option precOption = parser.addBooleanOption('p',
                "precursor");
        CmdLineParser.Option levelOption = parser.addBooleanOption('l',
                "level-one");
        CmdLineParser.Option chargeOption = parser.addIntegerOption('c',
                "max-charge");
        CmdLineParser.Option massOption = parser.addDoubleOption('m',
                "max-mass");
        CmdLineParser.Option errorOption = parser.addDoubleOption('e',
                "mz-error");
        CmdLineParser.Option ratioOption = parser.addDoubleOption('s',
                "sn-ratio");
        CmdLineParser.Option keepOption = parser.addBooleanOption('k', "keep");
        CmdLineParser.Option multipleOption = parser.addBooleanOption('u', 
                "multiple-mass");
        CmdLineParser.Option missingOption = parser.addBooleanOption('n', "missing-level-one");

        CmdLineParser.Option windowOption = parser.addDoubleOption('w', "precursor-window");
        	
        try {
            parser.parse(args);
        }
        catch (Exception e) {
            printUsage();
            System.exit(1);
        }
        /* file name */
        String remain[] = parser.getRemainingArgs();
        if (remain == null || remain.length == 0) {
            printUsage();
            System.exit(1);
        }
        DeconvParameter para = new DeconvParameter();
        para.setDataFileName(remain[0]);
        /* input type */
        String input = (String) parser.getOptionValue(inputOption, "mzXML");
        int result = para.setInputType(input);
        if (result > 0) {
            printUsage();
            System.exit(1);
        }

        /* output type */
        String format = (String) parser.getOptionValue(outputOption, "mgf");
        result = para.setOutputType(format);

        if (result > 0) {
            printUsage();
            System.exit(1);
        }
        
        /* centroid */
        para.doCentroid = false;
        String type = (String) parser.getOptionValue(typeOption, "centroided");
        if (type.equals("profile")) {
            para.doCentroid = true;
        }

        /* original precursor mass */
        para.doRefinePrecMass = true;
        Boolean useOriPrec = (Boolean) parser.getOptionValue(precOption,
                Boolean.FALSE);
        if (useOriPrec) {
            para.doRefinePrecMass = false;
        }
        /* level */
        Boolean reportLevelOne = (Boolean) parser.getOptionValue(levelOption,
                Boolean.FALSE);
        if (reportLevelOne) {
            para.msLevel = 1;
        } else {
            para.msLevel = 2;
        }
        
        Boolean missingLevelOne = (Boolean) parser.getOptionValue(missingOption,
                Boolean.FALSE);
        para.missingLevelOne = missingLevelOne;

        /* multiple mass */
        para.outputMultipleMass = false;
        Boolean multiple = (Boolean) parser.getOptionValue(multipleOption,
                Boolean.FALSE);
        if (multiple) {
            para.outputMultipleMass = true;
        }

        para.maxCharge = (Integer) parser
                .getOptionValue(chargeOption, DeconvMng.defaultMaxCharge);
        Double mass = (Double) parser.getOptionValue(massOption, DeconvMng.defaultMaxMass);
        para.maxMass = mass.floatValue();
        Double tolerance = (Double) parser.getOptionValue(errorOption, 0.02);
        para.tolerance = tolerance;
        Double ratio = (Double)(parser.getOptionValue(ratioOption, 1.0));
        para.snRatio = ratio.floatValue();
        para.keepUnusedPeaks = (Boolean) parser
                .getOptionValue(keepOption, false);
        para.precursorWindow = (Double)parser.getOptionValue(windowOption, 2.0);
        return para;
    }
}
