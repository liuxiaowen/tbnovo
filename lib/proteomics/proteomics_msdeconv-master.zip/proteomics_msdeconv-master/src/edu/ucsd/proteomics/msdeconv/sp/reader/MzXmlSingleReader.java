/**
 * Read an MS/MS spectrum from a file.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.sp.reader;


import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.rawsp.simplereader.MzXmlSingleSimpleReader;
import com.jap.proteomics.spec.sp.Ms;
import com.jap.proteomics.spec.sp.MsHeader;
import com.jap.proteomics.spec.sp.PeakList;

public class MzXmlSingleReader extends MsReader {

    public Ms<RawPeak> getNextRawMs() throws Exception {
        reader.readNext();
        PeakList<RawPeak> peakList = reader.getPeakList();
        if (peakList == null) {
            return null;
        }
        MsHeader header = reader.getMsHeader();
        //System.out.println("scan " + header.getFirstScanNum());
        Ms<RawPeak> ms = new Ms<RawPeak>(peakList, header);
        return ms;
    }
   
    public MzXmlSingleReader(String fileName, double precWindowSize) throws Exception {
    	super(precWindowSize);
    	reader = new MzXmlSingleSimpleReader(fileName);
    }
}
