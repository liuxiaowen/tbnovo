/**
 * Matching Envelope Coexist Table used in DP
 * 
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.dp;

import java.util.ArrayList;

import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class CoexistTbl {

    private static int cntTableSize(MatchEnv winEnvs[][], int win, int pnt) {
        int size = 0;
        if (win - 2 >= 0) {
            size += winEnvs[win - 2].length;
        }
        if (win - 1 >= 0) {
            size += winEnvs[win - 1].length;
        }
        size += pnt;
        return size;
    }

    private static boolean checkCoexist(MatchEnv envA, MatchEnv envB, int posA,
            int posB, double tolerance) {
        double intensityA = envA.getTheoEnv().getIntensity(posA);
        double intensityB = envB.getTheoEnv().getIntensity(posB);
        double intensitySum = intensityA + intensityB;
        double scoreA = envA.calcPeakScr(posA, intensityA, tolerance);
        double newScoreA = envA.calcPeakScr(posA, intensitySum, tolerance);
        if (newScoreA < scoreA) {
            return false;
        }
        double scoreB = envB.calcPeakScr(posB, intensityB, tolerance);
        double newScoreB = envB.calcPeakScr(posB, intensitySum, tolerance);
        if (newScoreB < scoreB) {
            return false;
        }
        return true;
    }

    private static boolean checkCoexist(MatchEnv envA, MatchEnv envB,
            double tolerance) {
        int listA[] = envA.getRealEnv().getPeakIdxList();
        int listB[] = envB.getRealEnv().getPeakIdxList();
        int cntShare = 0;
        int cntCoexist = 0;
        for (int i = 0; i < listA.length; i++) {
            int peakA = listA[i];
            for (int j = 0; j < listB.length; j++) {
                int peakB = listB[j];
                if (envA.getRealEnv().isExist(i) && peakA == peakB) {
                    cntShare++;
                    if (checkCoexist(envA, envB, i, j, tolerance)) {
                        cntCoexist++;
                    }
                }
            }
        }
        if (cntShare <= 1 || cntCoexist == cntShare) {
            return true;
        } else {
            return false;
        }
    }

    private static void compTableEntry(ArrayList<MatchEnv> envList,
            MatchEnv winEnvs[][], boolean rows[], int id, int win,
            double tolerance) {
        if (win < 0) {
            return;
        }
        for (int k = 0; k < winEnvs[win].length; k++) {
            int prevId = winEnvs[win][k].getId();
            if (prevId >= id) {
                return;
            }
            rows[id - prevId - 1] = checkCoexist(envList.get(prevId), envList
                    .get(id), tolerance);
        }
    }

    /** initialize coexist table */
    public static boolean[][] initCoexistTable(MatchEnv winEnvs[][],
            double tolerance) {
        ArrayList<MatchEnv> envList = new ArrayList<MatchEnv>();
        for (int i = 0; i < winEnvs.length; i++) {
            for (int j = 0; j < winEnvs[i].length; j++) {
                envList.add(winEnvs[i][j]);
            }
        }
        for (int i = 0; i < envList.size(); i++) {
            envList.get(i).setId(i);
        }
        boolean coexistTable[][] = new boolean[envList.size()][];
        for (int i = 0; i < winEnvs.length; i++) {
            for (int j = 0; j < winEnvs[i].length; j++) {
                int id = winEnvs[i][j].getId();
                int size = cntTableSize(winEnvs, i, j);
                coexistTable[id] = new boolean[size];
                compTableEntry(envList, winEnvs, coexistTable[id], id, i - 2,
                        tolerance);
                compTableEntry(envList, winEnvs, coexistTable[id], id, i - 1,
                        tolerance);
                compTableEntry(envList, winEnvs, coexistTable[id], id, i,
                        tolerance);
            }
        }
        return coexistTable;
    }
}
