/**
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.writer;

import java.io.PrintWriter;

import com.jap.proteomics.spec.sp.MsHeader;

import edu.ucsd.proteomics.msdeconv.env.Env;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.env.RealEnv;

public class TextWriter {

    public static void writeText(PrintWriter out, MatchEnv envs[],
            MsHeader header) throws Exception {
//        if (envs.length == 0) {
//            return;
//        }
        out.println("Result of scan(s): " + header.getScansString());
        out.println("Ms level: " + header.getMsLevel());
        if (header.getMsLevel() > 1) {
            out.println("Precursor information: monoisotopic m/z: "
                    + header.getPrecMonoMz() + " charge: "
                    + header.getPrecChrg() + " monoisotopic mass: "
                    + header.getPrecMonoMass());
        }
        out.println("Scans" + "\tMs_Level" + "\tEnvelope" + "\tReference_Idx"
                + "\tCharge" + "\tScore" + "\tTheo_Peak_Num"
                + "\tReal_Peak_Num" + "\tTheo_Mono_Mz" + "\tReal_Mono_Mz"
                + "\tTheo_Mono_Mass" + "\tReal_Mono_Mass"
                + "\tTheo_Intensity_Sum" + "\tReal_Intensity_Sum");
        for (int i = 0; i < envs.length; i++) {
            out.print(header.getFirstScanNum() + "\t" + header.getMsLevel() + "\t"
                    + (i + 1));
            MatchEnv env = envs[i];
            Env theo_env = env.getTheoEnv();
            RealEnv real_env = env.getRealEnv();
            out.print("\t" + theo_env.getReferIdx());
            out.print("\t" + theo_env.getCharge());
            out.print("\t" + env.getScore());
            out.print("\t" + theo_env.getPeakNum());
            out.print("\t"
                    + (real_env.getPeakNum() - real_env.getMissPeakNum()));
            out.print("\t" + theo_env.getMonoMz());
            out.print("\t" + real_env.getMonoMz());
            out.print("\t" + theo_env.getMonoMass());
            out.print("\t" + real_env.getMonoMass());
            out.print("\t" + theo_env.compIntensitySum());
            out.print("\t" + real_env.compIntensitySum());
            out.println();
        }
        out.println();
    }
}
