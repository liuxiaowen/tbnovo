/**
 * Read an MS/MS spectrum from a file.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.sp.reader;


import com.jap.proteomics.spec.rawsp.simplereader.MzXmlMergeSimpleReader;


public class MzXmlMergeReader extends MsReader {

    public MzXmlMergeReader(String file_name, boolean do_centroid, double precWindowSize)
            throws Exception {
    	super(precWindowSize);
        reader = new MzXmlMergeSimpleReader(file_name);
        this.doCentroid = do_centroid;
        doRefinePrecMass = true;
    }
}
