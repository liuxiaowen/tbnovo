/**
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.env;

import java.util.Arrays;
import java.util.ArrayList;

import edu.ucsd.proteomics.msdeconv.DeconvMng;

public class MatchEnvArrayFilter {

    public static MatchEnv[] filter(MatchEnv oriEnvs[], double precursorMass,
            DeconvMng mng) {
        ArrayList<MatchEnv> lowMassEnvList = new ArrayList<MatchEnv>();
        ArrayList<MatchEnv> highMassEnvList = new ArrayList<MatchEnv>();
        Arrays.sort(oriEnvs);
        int nLowMass = (int) (mng.lowHighDividor / mng.aaAvgMass * mng.peakDensity);
        int nHighMass = (int) ((precursorMass - mng.lowHighDividor)
                / mng.aaAvgMass * mng.peakDensity);
        for (int i = 0; i < oriEnvs.length; i++) {
            if (oriEnvs[i].getRealEnv().getMonoMass() <= mng.lowHighDividor) {
                if (lowMassEnvList.size() < nLowMass) {
                    lowMassEnvList.add(oriEnvs[i]);
                }
            } else {
                if (highMassEnvList.size() < nHighMass) {
                    highMassEnvList.add(oriEnvs[i]);
                }
            }
        }
        MatchEnv result[] = new MatchEnv[lowMassEnvList.size()
                + highMassEnvList.size()];
        int cnt = 0;
        for (int i = 0; i < lowMassEnvList.size(); i++) {
            result[cnt] = lowMassEnvList.get(i);
            cnt++;
        }
        for (int i = 0; i < highMassEnvList.size(); i++) {
            result[cnt] = highMassEnvList.get(i);
            cnt++;
        }
        Arrays.sort(result);
        return result;
    }
}
