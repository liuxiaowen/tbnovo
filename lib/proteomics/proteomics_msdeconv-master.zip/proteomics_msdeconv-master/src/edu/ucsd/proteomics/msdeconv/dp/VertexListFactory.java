/**
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.dp;

import java.util.ArrayList;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.data.DeconvData;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class VertexListFactory {

    private static int getBgnPeak(int preWin, DeconvData data) {
        int bgnPeak;
        if (preWin < 0) {
            bgnPeak = 0;
        } else {
            bgnPeak = data.getBgnPeak(preWin);
        }
        return bgnPeak;
    }

    private static int getWinPkNum(int win, DeconvData data) {
        if (win < 0 || win >= data.getWinNum()) {
            return 0;
        } else {
            return data.getIntervalPeakNum(win);
        }
    }

    /* add an empty vertexA */
    private static void addEmptyVertexA(ArrayList<VertexA> result,
            DeconvData data, int curWin) {
        int preWin = curWin - 1;
        int bgnPeak = getBgnPeak(preWin, data);
        int nPreWinPeak = getWinPkNum(preWin, data);
        int nCurWinPeak = getWinPkNum(curWin, data);
        VertexA vertex = new VertexA(bgnPeak, nPreWinPeak, nCurWinPeak);
        vertex.trim();
        result.add(vertex);
    }

    public static VertexA[] getVertexAList(DeconvData data, int curWin,
            MatchEnv prevMatchEnv[], MatchEnv curMatchEnv[], DeconvMng mng)
            throws Exception {
        ArrayList<VertexA> result = new ArrayList<VertexA>();
        /* add an empty vertex */
        addEmptyVertexA(result, data, curWin);
        int curSize = 1;
        /* add envelopes in previous window */
        for (int i = 0; i < prevMatchEnv.length; i++) {
            curSize = result.size();
            for (int j = 0; j < curSize; j++) {
                if (result.get(j).getMatchEnvSize() < mng.maxEnvNumPerVertex) {
                    VertexA vetex = (VertexA) (result.get(j).clone());
                    if (vetex.addPreEnv(prevMatchEnv[i], mng.maxEnvNumPerPeak)) {
                        vetex.trim();
                        result.add(vetex);
                    }
                }
            }
        }
        /* add envelopes in current window */
        for (int i = 0; i < curMatchEnv.length; i++) {
            curSize = result.size();
            for (int j = 0; j < curSize; j++) {
                if (result.get(j).getMatchEnvSize() < mng.maxEnvNumPerVertex) {
                    VertexA vertex = (VertexA) (result.get(j).clone());
                    if (vertex.addCurEnv(curMatchEnv[i], mng.maxEnvNumPerPeak)) {
                        vertex.trim();
                        result.add(vertex);
                    }
                }
            }
        }
        return (VertexA[]) result.toArray(new VertexA[0]);
    }

    /**
     * this is a copy of the previous two methods except that env_num is added
     */
    /* add an empty vertexB */
    private static void addEmptyVertexB(ArrayList<VertexB> result,
            DeconvData data, int curWin, int nEnv) {
        int prevWin = curWin - 1;
        int bgnPeak = getBgnPeak(prevWin, data);
        int nPrevWinPeak = getWinPkNum(prevWin, data);
        int nCurWinPeak = getWinPkNum(curWin, data);
        VertexB vertex = new VertexB(bgnPeak, nPrevWinPeak, nCurWinPeak, nEnv);
        vertex.trim();
        result.add(vertex);
    }

    public static VertexB[] getVertexBList(DeconvData data, int curWin,
            MatchEnv prevMatchEnv[], MatchEnv curMatchEnv[], DeconvMng mng)
            throws Exception {
        ArrayList<VertexB> result = new ArrayList<VertexB>();
        /* add an empty vertex */
        addEmptyVertexB(result, data, curWin, mng.dpEnvNum);
        int curSize = 1;
        /* add envelopes in previous window */
        for (int i = 0; i < prevMatchEnv.length; i++) {
            curSize = result.size();
            for (int j = 0; j < curSize; j++) {
                if (result.get(j).getMatchEnvSize() < mng.maxEnvNumPerVertex) {
                    VertexB vertex = (VertexB) (result.get(j).clone());
                    if (vertex.addPreEnv(prevMatchEnv[i], mng.maxEnvNumPerPeak)) {
                        vertex.trim();
                        result.add(vertex);
                    }
                }
            }
        }
        /* add envelopes in current window */
        for (int i = 0; i < curMatchEnv.length; i++) {
            curSize = result.size();
            for (int j = 0; j < curSize; j++) {
                if (result.get(j).getMatchEnvSize() < mng.maxEnvNumPerVertex) {
                    VertexB vertex = (VertexB) (result.get(j).clone());
                    if (vertex.addCurEnv(curMatchEnv[i], mng.maxEnvNumPerPeak)) {
                        vertex.trim();
                        result.add(vertex);
                    }
                }
            }
        }
        return (VertexB[]) result.toArray(new VertexB[0]);
    }
}
