package edu.ucsd.proteomics.msdeconv.env;

import org.apache.log4j.Logger;

import com.jap.proteomics.base.residue.MassConstant;

import edu.ucsd.proteomics.msdeconv.DeconvMng;

public class MatchEnvRefine {

    private static Logger logger = Logger.getLogger(MatchEnvRefine.class);

    private static double maxDistanceA = 1.0f;
    private static double maxDistanceB = 1.0f;

    private static double bestRatio;

    public static void mzRefine(DeconvMng mng, MatchEnv envs[]) {
        for (int i = 0; i < envs.length; i++) {
            mzRefine(mng, envs[i]);
        }
    }

    public static void mzRefine(DeconvMng mng, MatchEnv env) {
        RealEnv realEnv = env.getRealEnv();
        double curMz = realEnv.getReferMz();
        int charge = realEnv.getCharge();
        double prevMz = curMz - 1f / charge;
        double nextMz = curMz + 1f / charge;
        /* check if the mass is greater than the precursor mass */
        double baseMass = curMz * charge - charge * MassConstant.getProtonMass();
        /* get a reference distribution based on the base mass */
        Env referEnv = mng.distributionEnvFactory.getEnvByBaseMass(baseMass);
        /* add one zeros at both sides of the envelope */
        Env extReferEnv = referEnv.addZero(1);
        /**
         * convert the reference distribution to a theoretical distribution
         * based on the base mz and charge state
         */
        int maxBackwardPeakNum = realEnv.getReferIdx();
        int maxForwardPeakNum = realEnv.getPeakNum() - realEnv.getReferIdx()
                - 1;
        Env theoEnv = extReferEnv.distrToTheoBase(curMz, charge);
        double maxIntensity = theoEnv.getReferIntensity();
        theoEnv.changeIntensity(1.0f / maxIntensity);
        // logger.debug("max error " + max_err);
        Env curEnv = theoEnv.getSubEnv(maxBackwardPeakNum, maxForwardPeakNum);

        theoEnv = extReferEnv.distrToTheoBase(prevMz, charge);
        maxIntensity = theoEnv.getReferIntensity();
        theoEnv.changeIntensity(1.0f / maxIntensity);
        Env prevEnv;
        if (maxBackwardPeakNum >= 1
                && realEnv.isExist(realEnv.getReferIdx() - 1)) {
            prevEnv = theoEnv.getSubEnv(maxBackwardPeakNum - 1,
                    maxForwardPeakNum + 1);
        } else {
            prevEnv = null;
        }

        theoEnv = extReferEnv.distrToTheoBase(nextMz, charge);
        maxIntensity = theoEnv.getReferIntensity();
        theoEnv.changeIntensity(1.0f / maxIntensity);

        Env nextEnv;
        if (maxForwardPeakNum >= 1
                && realEnv.isExist(realEnv.getReferIdx() + 1)) {
            nextEnv = theoEnv.getSubEnv(maxBackwardPeakNum + 1,
                    maxForwardPeakNum - 1);
        } else {
            nextEnv = null;
        }

        double curDist = compEnvDist(realEnv, curEnv);
        double curRatio = bestRatio;
        double prevDist = compEnvDist(realEnv, prevEnv);
        double prevRatio = bestRatio;
        double nextDist = compEnvDist(realEnv, nextEnv);
        double nextRatio = bestRatio;

        if (curDist <= prevDist && curDist <= nextDist) {
        //if (curDist <= prevDist) {
            logger.trace("cur envelope " + curDist);
            curEnv.changeIntensity(curRatio);
            env.setTheoEnv(curEnv);
        } else if (prevDist <= nextDist){
            logger.trace("pre envelope " + prevDist);
            prevEnv.changeIntensity(prevRatio);
            env.setTheoEnv(prevEnv);
            realEnv.shift(-1);
        }
        else {
            logger.trace("next envelope " + nextDist);
            nextEnv.changeIntensity(nextRatio);
            env.setTheoEnv(nextEnv);
            realEnv.shift(1);
        }
    }

    public static double compEnvDist(Env realEnv, Env theoEnv) {
        if (theoEnv == null) {
            return Float.POSITIVE_INFINITY;
        } else {
            return compDistWithNorm(realEnv.getIntensities(), theoEnv
                    .getIntensities());
        }
    }

    // public static double compDistWithNorm(double real[], double theo[], double
    // ratio) {
    // double normReal[] = norm(real, ratio);
    // return compDistVerbose(normReal, theo);
    // }
    //
    // public static double compDistVerbose(double norm[], double theo[]) {
    // double result = 0;
    // for (int i = 0; i < norm.length; i++) {
    // double dist = Math.abs(norm[i] - theo[i]);
    // if (norm[i] > theo[i]) {
    // if (dist > maxDistanceA) {
    // dist = maxDistanceA;
    // }
    // } else {
    // if (dist > maxDistanceB) {
    // dist = maxDistanceB;
    // }
    // }
    // logger.debug(norm[i] + " " + theo[i] + " " + dist + " " + dist
    // * dist);
    // result = result + dist * dist;
    // }
    // return result;
    // }

    public static double compDistWithNorm(double real[], double theo[]) {
        double bestDist = Float.POSITIVE_INFINITY;
        bestRatio = -1;
        for (int i = 0; i < real.length; i++) {
            double ratio = real[i] / theo[i];
            if (ratio <= 0) {
                continue;
            }
            for (int j = 80; j <= 120; j++) {
                double curRatio = ratio * j / 100f;
                double normReal[] = norm(real, curRatio);
                double dist = compDist(normReal, theo);
                if (dist < bestDist) {
                    bestDist = dist;
                    bestRatio = curRatio;
                }
            }
        }
        return bestDist;
    }

    public static double[] norm(double obs[], double ratio) {
        double resutl[] = new double[obs.length];
        for (int i = 0; i < obs.length; i++) {
            resutl[i] = obs[i] / ratio;
        }
        return resutl;
    }

    public static double compDist(double norm[], double theo[]) {
        double result = 0;
        for (int i = 0; i < norm.length; i++) {
            double dist = Math.abs(norm[i] - theo[i]);
            if (norm[i] > theo[i]) {
                if (dist > maxDistanceA) {
                    dist = maxDistanceA;
                }
            } else {
                if (dist > maxDistanceB) {
                    dist = maxDistanceB;
                }
            }
            result = result + dist * dist;
        }
        return result;
    }
}
