package edu.ucsd.proteomics.msdeconv.detect;

public class CompComposition {

    static final float C_FREQ = 4.941f;
    static final float H_FREQ = 7.8261f;
    static final float N_FREQ = 1.3599f;
    static final float O_FREQ = 1.4696f;
    static final float S_FREQ = 0.0379f;

    static final float AVE_MASS = 110.93998f;

    static final double c_mass = 12;
    static final double h_mass = 1.0078246;
    static final double n_mass = 14.0030732;
    static final double o_mass = 15.9949141;
    static final double s_mass = 31.972070;

 

    public static String compIsoForm(float mass, int chrg) {
        float res_num = mass / AVE_MASS;
        int c_num = Math.round(res_num * C_FREQ);
        int h_num = Math.round(res_num * H_FREQ);
        int n_num = Math.round(res_num * N_FREQ);
        int o_num = Math.round(res_num * O_FREQ);
        int s_num = Math.round(res_num * S_FREQ);

        String rslt = "";
        if (c_num > 0) {
            rslt = rslt + "C" + c_num;
        }
        if (h_num > 0) {
            rslt = rslt + "H" + h_num;
        }
        if (n_num > 0) {
            rslt = rslt + "N" + n_num;
        }
        if (o_num > 0) {
            rslt = rslt + "O" + o_num;
        }
        if (s_num > 0) {
            rslt = rslt + "S" + s_num;
        }
        rslt = rslt + "," + chrg + "\n";
        double mono_mass = c_mass * c_num + h_mass * h_num + n_mass * n_num
                + o_mass * o_num + s_mass * s_num;

        return rslt + mono_mass;
    }

    public static void main(String args[]) {
        int chrg = 1;
        //double avg = C_FREQ * c_mass + H_FREQ * h_mass + N_FREQ * n_mass + O_FREQ * o_mass + S_FREQ * s_mass;
        //System.out.println("Average mass" + avg);

        for (float mass = 0f; mass < 60000f; mass += 10f) {
            String rslt = compIsoForm(mass, chrg);
            System.out.println(rslt);
        }
    }

}
