package edu.ucsd.proteomics.msdeconv.env;

import edu.ucsd.proteomics.msdeconv.DeconvMng;

public class MatchEnv implements Comparable<MatchEnv> {

    private int id;
    /* we divide envelopes into several groups based on monoisotopic 
     * masses */ 
    private int massGroup;

    private Env theoEnv;
    private RealEnv realEnv;
    private double score = 0;
    
    public MatchEnv(int massGroup, Env theoEnv, RealEnv realEnv) {
        this.massGroup = massGroup;
        this.theoEnv = theoEnv;
        this.realEnv = realEnv;
    }

    /** compare the matchenv instants based on its score */
    public int compareTo(MatchEnv y) {
        double y_scr = y.getScore();
        if (y_scr - score < 0) {
            return -1;
        } else if (y_scr - score > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    /*************************************************
     * Scoring function
     ************************************************/
    /** compute matching score */
    public void compScr(DeconvMng mng) {
        if (mng.doMzShift) {
            double bestShift = findBestShift(mng);
            theoEnv.changeMz(bestShift);
        }

        if (mng.doIntensityRatio) {
            double bestRatio = findBestRatio(mng);
            theoEnv.changeIntensity(bestRatio);
        }

        score = calcScrWithSftRatio(0, 1f, mng.scoreErrorTolerance);
    }

    /** search for best m/z shift */
    public double findBestShift(DeconvMng mng) {
        double bestScore = Float.NEGATIVE_INFINITY;
        int bestShift = 0;
        /* initialize start shift and end shift based on configuration */
        int bgnShift = (int)Math.round(-mng.mzTolerance * mng.shiftScale);
        int endShift = (int)Math.round(mng.mzTolerance * mng.shiftScale);

        for (int s = bgnShift; s <= endShift; s++) {
            double tmpScore = calcScrWithSftRatio((double) s / mng.shiftScale,
                    1.0f, mng.scoreErrorTolerance);
            if (tmpScore > bestScore) {
                bestScore = tmpScore;
                bestShift = s;
            }
        }
        return (double) bestShift / mng.shiftScale;
    }

    /** search for best intensity ratio */
    public double findBestRatio(DeconvMng mng) {
        double bestScore = Float.NEGATIVE_INFINITY;
        int bestRatio = 0;
        /* initialize start ratio and end ratio based on configuration */
        int bgnRatio = (int)Math.round(mng.bgnRatio * mng.intensityRatioScale);
        int endRatio = (int)Math.round(mng.endRatio * mng.intensityRatioScale);

        for (int r = bgnRatio; r <= endRatio; r++) {
            double tmpScore = calcScrWithSftRatio(0f, (double) r
                    / mng.intensityRatioScale, mng.scoreErrorTolerance);
            if (tmpScore > bestScore) {
                bestScore = tmpScore;
                bestRatio = r;
            }
        }
        return (double) bestRatio / mng.intensityRatioScale;
    }

    /** Calculating the score with shift. */
    public double calcScrWithSftRatio(double shift, double ratio, double tolerance) {
        double s = 0;
        for (int i = 0; i < realEnv.getPeakNum(); i++) {
            /* here mz_accu >= 0 and inte_scr >= 0 */
            double mzFactor = calcMzFactor(i, shift, tolerance);
            double intensityFactor = calcIntensityFactor(i, ratio);
            double peakScore = mzFactor * intensityFactor
                    * calcNormInteScr(theoEnv.getIntensity(i) * ratio);
            s += peakScore;
        }
        return s;
    }

    /** intensity normalization method */
    private double calcNormInteScr(double intensity) {
        return (double) Math.sqrt(intensity);
    }

    /** function of mz accuracy */
    private double calcMzFactor(int idx, double shift, double tolerance) {
        double mzFactor;
        if (realEnv.isExist(idx)) {
            double dist = Math.abs(theoEnv.getMz(idx) + shift
                    - realEnv.getMz(idx));
            mzFactor = (tolerance - dist) / tolerance;
            if (mzFactor < 0) {
                mzFactor = 0;
            }
        } else {
            mzFactor = 0f;

        }
        return mzFactor;
    }

    /** function of intensity accuracy */
    private double calcIntensityFactor(int idx, double ratio) {
        double factor;
        if (realEnv.isExist(idx)) {
            factor = calcIntensityFactor(theoEnv.getIntensity(idx) * ratio,
                    realEnv.getIntensity(idx));
        } else {
            factor = 0f;
        }
        return factor;
    }

    /** Calculate the score two intensities */
    private double calcIntensityFactor(double thoeIntensity, double realIntensity) {
        double ratio = thoeIntensity / realIntensity;
        double intensityFacotr;
        /* notice the special curve here : 2.0* and sqrt() */
        if (ratio > 1.0) {
            intensityFacotr = 1.0f - 2.0f * (ratio - 1.0f);
        } else {
            intensityFacotr = (double) Math.sqrt(ratio);
        }
        if (intensityFacotr < 0f) {
            intensityFacotr = 0f;
        }
        return intensityFacotr;
    }

    /*************************************************
     * Scoring function for peak sharing model
     ************************************************/
    /**
     * compute the score for shared peak
     * 
     * @param intensitySum
     *            is the sum of theoretical intensity of all theoretical peaks
     *            mapping to this peak.
     */
    public double calcPeakScr(int idx, double intensitySum, double tolerance) {
        double mzFactor = calcMzFactor(idx, 0f, tolerance);
        double intensityFactor = calcShareInteAccu(idx, intensitySum);
        double peakScore = mzFactor * intensityFactor
                * calcNormInteScr(theoEnv.getIntensity(idx));
        return peakScore;
    }

    public double calcShareInteAccu(int idx, double intensitySum) {
        double intensityFactor;
        double theoIntensity = theoEnv.getIntensity(idx);
        if (realEnv.isExist(idx)) {
            double realIntensity = realEnv.getIntensity(idx);
            double shareRatio = theoIntensity / intensitySum;
            double shareIntensity = realIntensity * shareRatio;
            intensityFactor = calcIntensityFactor(theoIntensity, shareIntensity);
        } else {
            intensityFactor = 0f;
        }
        return intensityFactor;
    }

    /*************************************************
     * Gets and sets
     ************************************************/
    public int getId() {
        return id;
    }

    public int getMassGroup() {
        return massGroup;
    }

    public RealEnv getRealEnv() {
        return realEnv;
    }

    public Env getTheoEnv() {
        return theoEnv;
    }

    public double getScore() {
        return score;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTheoEnv(Env theoEnv) {
        this.theoEnv = theoEnv;
    }
}
