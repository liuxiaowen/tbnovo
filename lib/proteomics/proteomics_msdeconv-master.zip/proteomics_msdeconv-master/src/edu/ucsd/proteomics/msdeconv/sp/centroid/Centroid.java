package edu.ucsd.proteomics.msdeconv.sp.centroid;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.jap.proteomics.base.util.BioArray;
import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;


/**
 * Centroid 
 *
 * @author  Xiaowen Liu
 * @date    2010-12-14
 */

public class Centroid{
    
    private static Logger logger = Logger.getLogger(Centroid.class);

    public CentroidMng mng;
    PeakList<RawPeak> sp;
    PeakList<RawPeak> centroid_sp;
    
    public Centroid() {
        mng = new CentroidMng();
    }


    public PeakList<RawPeak> go (PeakList<RawPeak> sp) throws Exception {
        this.sp = sp;
        sp.rmZeroPeaks();
        run();
        return centroid_sp;
    }

    private boolean isLocalMaxima (int left_limit, int cur_idx) 
		throws Exception {
        if (left_limit < cur_idx 
                && (sp.getPosition(cur_idx) - sp.getPosition(cur_idx -1)) <= mng.mz_thresh
                && sp.getIntensity(cur_idx) < sp.getIntensity(cur_idx -1)) {
            return false;
        }
        int last_idx = sp.size() -1;
        if (cur_idx < last_idx 
                && (sp.getPosition(cur_idx+1) - sp.getPosition(cur_idx )) <= mng.mz_thresh
                && sp.getIntensity(cur_idx) < sp.getIntensity(cur_idx+1)) {
            return false;
        }
        if (cur_idx + 1 < last_idx 
                && (sp.getPosition(cur_idx+1) - sp.getPosition(cur_idx )) <= 2 * mng.mz_thresh
                && sp.getIntensity(cur_idx) < sp.getIntensity(cur_idx+2)) {
            return false;
        }
        return true;
    }

    private int getRightLimit(int cur_idx) throws Exception {
        int last_idx = sp.size() - 1;
        int right_limit = cur_idx;
        double minus_one_inte = 0;
        double right_limit_inte = sp.getIntensity(right_limit);
        while (right_limit < last_idx) {
            int next_limit = right_limit + 1;
            // check mz difference */
            if (sp.getPosition(next_limit) - sp.getPosition(right_limit) > mng.mz_thresh) {
                break;
            }

            if (sp.getIntensity(next_limit) > right_limit_inte 
                    && sp.getIntensity(next_limit) > minus_one_inte) {
                break;
            }
            minus_one_inte = right_limit_inte;
            right_limit = next_limit;
            right_limit_inte = sp.getIntensity(right_limit);

        }
        if (right_limit > cur_idx && right_limit_inte > minus_one_inte) {
            right_limit --;
        }
        logger.debug(" current " + cur_idx + " right " + right_limit);
        
        return right_limit;
    }

    public void run() throws Exception {
        int peak_num = sp.size();
        ArrayList<Double> result_mz = new ArrayList<Double>();
        ArrayList<Double> result_inte = new ArrayList<Double>();

        // don't pick a spectrum with less than 3 data points
        if (peak_num < 3) {
            centroid_sp = sp;
            return;
        }

        // find local maxima in raw data
        int left_limit = 0;
        int right_limit = 0;
        int cur_idx = 0;
        while (cur_idx < peak_num) {
            if (isLocalMaxima(left_limit, cur_idx) ) {
                right_limit = getRightLimit(cur_idx);
                result_mz.add(sp.getPosition(cur_idx));
                result_inte.add(sp.getIntensity(cur_idx));
                logger.debug("left " + sp.getPosition(left_limit) + " current " + cur_idx + " right " + sp.getPosition(right_limit));
                left_limit = right_limit + 1;
                cur_idx = left_limit;
                right_limit = left_limit;
            }
            else {
                cur_idx ++;
                right_limit = cur_idx;
            }
        }

        double new_mz[] = BioArray.cnvtDoubleList(result_mz);
        double new_inte[] = BioArray.cnvtDoubleList(result_inte);
        centroid_sp = new PeakList<RawPeak>(RawPeak.getRawPeaks(new_mz, new_inte));

    }
}
