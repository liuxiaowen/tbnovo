/**
 * MsDeconv GUI
 * @author  Xiaowen Liu
 * @date    2011-05-01
 */

package edu.ucsd.proteomics.msdeconv.gui;

import javax.swing.SwingUtilities;

public class MsDeconvGui {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

    private static void createAndShowGUI() {
        MsDeconvFrame frame = new MsDeconvFrame();
        frame.setVisible(true);
    }
}

