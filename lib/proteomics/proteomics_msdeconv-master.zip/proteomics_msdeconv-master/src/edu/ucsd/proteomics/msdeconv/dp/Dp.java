/**
 * DP algorithm
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.dp;

import java.util.ArrayList;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.data.DeconvData;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class Dp {
    
    protected DeconvData data;
    protected DeconvMng mng;
    protected MatchEnv winEnvs[][];
    protected int nWindow;
    protected ArrayList<MatchEnv> result;

    public Dp (DeconvData data, MatchEnv winEnvs[][], DeconvMng mng) {
        this.data = data;
        this.winEnvs = winEnvs;
        this.mng = mng;
        Vertex.mng = mng;        
        this.nWindow = data.getWinNum();
    }


    /** add an envelope list to result list */
    protected void addEnv(ArrayList<MatchEnv> result, 
                          ArrayList<MatchEnv> prevEnv) {
        for (int i = 0; i < prevEnv.size(); i++) {
            result.add(prevEnv.get(i));
        }
    }
    
    public MatchEnv[] getResult() {
        return (MatchEnv[])result.toArray(new MatchEnv[0]);
    }
}

