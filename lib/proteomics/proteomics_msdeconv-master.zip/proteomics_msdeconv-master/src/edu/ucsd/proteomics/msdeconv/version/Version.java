package edu.ucsd.proteomics.msdeconv.version;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Version {
	String version;
	String svnRevision;
	String revDate;

	public Version() throws Exception {
		try {
			BufferedReader reader;
			reader = new BufferedReader(new InputStreamReader(this.getClass()
					.getResourceAsStream("version.txt")));
			version = reader.readLine().trim();
			reader.close();
			reader = new BufferedReader(new InputStreamReader(this.getClass()
					.getResourceAsStream("svn.properties")));
			for (int i = 0; i < 4; i++) {
				reader.readLine();
			}
			String line = reader.readLine();
			int pos = line.indexOf(" ");
			svnRevision = line.substring(pos + 1);
			for (int i = 0; i < 4; i++) {
				reader.readLine();
			}
			line = reader.readLine();
			StringTokenizer st = new StringTokenizer(line);
			for (int i = 0; i < 3; i++) {
				st.nextToken();
			}
			revDate = st.nextToken();
			reader.close();
		} catch (Exception e) {
			version = "0.12";
			svnRevision = "test";
			revDate = "2015/04/29";
		}
	}

	public String getVersion() {
		return version + "." + svnRevision;
	}

	public String getDate() {
		return revDate;
	}
}
