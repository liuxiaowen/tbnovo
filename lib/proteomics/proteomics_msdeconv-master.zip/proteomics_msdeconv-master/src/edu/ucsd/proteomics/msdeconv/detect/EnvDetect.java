/**
 * Envelope detection
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.detect;

import org.apache.log4j.Logger;

import com.jap.proteomics.base.residue.MassConstant;
import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.data.DeconvData;
import edu.ucsd.proteomics.msdeconv.env.Env;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.env.RealEnv;

public class EnvDetect {

	private static Logger logger = Logger.getLogger(EnvDetect.class);

	/** generate all candidate envelopes */
	public static MatchEnv[][] getCandidate(DeconvData data, DeconvMng mng)
			throws Exception {

		PeakList<RawPeak> sp = data.getPeakList();
		int nPeak = sp.size();
		int maxCharge = data.getMaxCharge();
		logger.debug(nPeak + " " + maxCharge);
		MatchEnv matchEnvs[][] = new MatchEnv[nPeak][maxCharge];
		for (int idx = 0; idx < nPeak; idx++) {
			for (int charge = 1; charge <= maxCharge; charge++) {
				matchEnvs[idx][charge - 1] = detectEnv(sp, idx, charge, data
						.getMaxMass(), mng);
			}
		}
		return matchEnvs;
	}

	/** detect a MatchEnv */
	public static MatchEnv detectEnv(PeakList<RawPeak> sp, int basePeak,
			int charge, double maxMass, DeconvMng mng) throws Exception {

		double baseMz = sp.getPosition(basePeak);
		/* check if the mass is greater than the precursor mass */
		double baseMass = baseMz * charge - charge
				* MassConstant.getProtonMass();
		if (baseMass >= maxMass || baseMass < mng.minMass) {
			return null;
		}

		/* get a reference distribution based on the base mass */
		Env ref_env = mng.distributionEnvFactory.getEnvByBaseMass(baseMass);
		if (ref_env == null) {
			logger.warn("reference envelope is null");
			return null;
		}

		/*
		 * convert the reference distribution to a theoretical distribution
		 * based on the base mz and charge state
		 */
		Env theoEnv = ref_env.distrToTheoBase(baseMz, charge);
		/* scale theoretical distribution */
		double ratio = calcInteRatio(theoEnv, sp, mng.mzTolerance);
		theoEnv.changeIntensity(ratio);

		int massGroup = mng.getMassGroup(baseMass);

		/* get the highest 85%--95% peaks */
		double percentage = mng.getPercentBound(massGroup);
		theoEnv = theoEnv.getSubEnv(percentage, mng.minIntensity,
				mng.maxBackwardPeakNum, mng.maxForwardPeakNum);
		
		/** get real envelope */
		if (sp.getIntensity(basePeak) < mng.minReferIntensity) {
			return null;
		}
		RealEnv realEnv = new RealEnv(sp, theoEnv, mng.mzTolerance,
				mng.minIntensity);
		return new MatchEnv(massGroup, theoEnv, realEnv);
	}

	/** compute the intensity ratio based on the top three peaks */
	private static double calcInteRatio(Env theoEnv, PeakList<RawPeak> sp,
			double tolerance) throws Exception {

		double theoIntensities[] = theoEnv.getIntensities();
		double theoreticalSum = 0;
		double observeSum = 0;
		int referIdx = theoEnv.getReferIdx();
		RawPeak rawPeak = new RawPeak(theoEnv.getMz(referIdx), 0);
		int peak = sp.getNearPeakIdx(rawPeak, tolerance);
		if (peak >= 0) {
			theoreticalSum += theoIntensities[referIdx];
			observeSum += sp.getIntensity(peak);
		}
		if (referIdx - 1 >= 0) {
			theoreticalSum += theoIntensities[referIdx - 1];
			rawPeak = new RawPeak(theoEnv.getMz(referIdx-1), 0);
			peak = sp.getNearPeakIdx(rawPeak, tolerance);
			if (peak >= 0) {
				observeSum += sp.getIntensity(peak);
			}
		}
		if (referIdx + 1 < theoEnv.getPeakNum()) {
			theoreticalSum += theoIntensities[referIdx + 1];
			rawPeak = new RawPeak(theoEnv.getMz(referIdx + 1), 0);
			peak = sp.getNearPeakIdx(rawPeak, tolerance);
			if (peak >= 0) {
				observeSum += sp.getIntensity(peak);
			}
		}
		if (theoreticalSum == 0) {
			return 1.0f;
		} else {
			return observeSum / theoreticalSum;
		}
	}
}
