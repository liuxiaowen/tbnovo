/**
 * The vertex for path graph.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.dp;

import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class VertexA extends Vertex implements Cloneable {

    /* the sum of scores of envelopes in previous window */
    private double thisScore;
    /*
     * current score for dp, only the scores of pre_match_env are included. The
     * reason is that we can only determine the score for sharing model when
     * envelopes in the next window are determined.
     */
    private double score;
    /* previous vertex for backtracking */
    private int prevVertex;

    public VertexA(int bgnPeak, int preWinPeakNum, int curWinPeakNum) {
        super(bgnPeak, preWinPeakNum, curWinPeakNum);
        thisScore = 0f;
        score = 0f;
        prevVertex = -1;
    }

    /** clone implementation */
    public Object clone() throws CloneNotSupportedException {
        VertexA newVertex = (VertexA) super.clone();
        return newVertex;
    }

    public boolean addPreEnv(MatchEnv env, int maxOverlap) {
        boolean result = super.addPreEnv(env, maxOverlap);
        thisScore += env.getScore();
        return result;
    }

    /*************************************************
     * Gets
     ************************************************/
    public double getThisScr() {
        return thisScore;
    }

    public double getScrA() {
        return score;
    }

    public void setScrA(double score) {
        this.score = score;
    }

    public int getPreA() {
        return prevVertex;
    }

    public void setPreA(int prev) {
        this.prevVertex = prev;
    }
}
