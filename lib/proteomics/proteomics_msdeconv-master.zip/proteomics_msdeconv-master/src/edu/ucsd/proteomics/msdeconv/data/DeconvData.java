/**
 * Describes data set for deconvolution.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.data;

import java.util.Arrays;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;


public class DeconvData {

	/** peak list */
	private PeakList<RawPeak> peakList;
	/** parent monoisotopic mass */
	private double maxMass;
	/** the maximum charge state */
	private int maxCharge;
	/** the number of windows */
	private int nWin;
	/** the length of each window */
	private double winSize;

	/** the window id for each peak */
	private int winIds[];
	/** the first peak of each window */
	private int winBgnPeaks[];
	/** the last peak of each window */
	private int winEndPeaks[];

	public DeconvData(PeakList<RawPeak> peakList, double maxMass, int maxCharge,
			double winSize) throws Exception {

		this.peakList = peakList;
		this.maxMass = maxMass;
		this.maxCharge = maxCharge;
		this.winSize = winSize;
		nWin = (int) Math.ceil(peakList.findMaxPos() / winSize) + 2;
		initWinId();
		initWinBgnEnd();
	}

	/** initialize the window id */
	private void initWinId() throws Exception {
		int nPeak = peakList.size();
		winIds = new int[nPeak];
		for (int i = 0; i < nPeak; i++) {
			winIds[i] = (int) Math.floor(peakList.getPosition(i) / winSize);
		}
	}

	/** initialize the first and last peak for each window */
	private void initWinBgnEnd() {
		int nPeak = peakList.size();
		winBgnPeaks = new int[nWin];
		winEndPeaks = new int[nWin];
		Arrays.fill(winBgnPeaks, nPeak);
		winBgnPeaks[0] = 0;
		Arrays.fill(winEndPeaks, -1);
		winEndPeaks[nWin - 1] = nPeak - 1;
		for (int i = 0; i < nPeak; i++) {
			int id = winIds[i];
			if (i < winBgnPeaks[id]) {
				winBgnPeaks[id] = i;
			}
			if (i > winEndPeaks[id]) {
				winEndPeaks[id] = i;
			}
		}

		int bgn = nPeak;
		for (int i = nWin - 1; i >= 0; i--) {
			if (winBgnPeaks[i] == nPeak) {
				winBgnPeaks[i] = bgn;
			} else {
				bgn = winBgnPeaks[i];
			}
		}
		int end = -1;
		for (int i = 0; i < nWin; i++) {
			if (winEndPeaks[i] == -1) {
				winEndPeaks[i] = end;
			} else {
				end = winEndPeaks[i];
			}
		}
	}

	/* Gets */
	public int getBgnPeak(int i) {
		return winBgnPeaks[i];
	}

	public int getEndPeak(int i) {
		return winEndPeaks[i];
	}

	public int getIntervalPeakNum(int i) {
		return winEndPeaks[i] - winBgnPeaks[i] + 1;
	}

	public double getMaxMass() {
		return maxMass;
	}

	public int getMaxCharge() {
		return maxCharge;
	}

	public PeakList<RawPeak> getPeakList() {
		return peakList;
	}

	public int getWinId(int i) {
		return winIds[i];
	}

	public int getWinNum() {
		return nWin;
	}

	public void setMaxCharge(int max_chrg) {
		this.maxCharge = max_chrg;
	}

	public void setMaxMass(double mass) {
		this.maxMass = mass;
	}

}
