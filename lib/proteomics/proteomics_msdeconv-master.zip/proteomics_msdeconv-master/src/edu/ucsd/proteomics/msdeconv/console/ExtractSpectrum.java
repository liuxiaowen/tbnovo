package edu.ucsd.proteomics.msdeconv.console;

import com.jap.proteomics.base.util.BioIo;
import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.rawsp.writer.MgfWriter;
import com.jap.proteomics.spec.sp.Ms;

import edu.ucsd.proteomics.msdeconv.sp.reader.MzXmlSingleReader;

public class ExtractSpectrum {
	public static void main(String[] args) throws Exception {
		try {
			String spFileName = args[0];
			int scanNumber = Integer.parseInt(args[1]);
			MzXmlSingleReader reader = new MzXmlSingleReader(spFileName, 1.5);
			reader.setCentroid(false);
			reader.setRefinePrec(false);

			Ms<RawPeak> sp;
			MgfWriter writer = new MgfWriter(args[1]);
			while ((sp = reader.getNextRawMs() ) != null) {
				if (sp.getHeader().getFirstScanNum() == scanNumber) {
					writer.writeMgf(sp.getHeader(), sp.getPositions(),
							sp.getIntensities(), true, true);
					break;
				}
				
			}
			writer.close();

		} catch (Exception e) {
			System.out.println(BioIo.getStackTraceAsString(e));
			System.exit(1);
		} catch (Error e) {
			System.out.println(BioIo.getStackTraceAsString(e));
			System.exit(1);
		}
	}
}
