/**
 * Filter Match Envelopes
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.filter;

import org.apache.log4j.Logger;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.data.DeconvData;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.env.RealEnv;

public class EnvFilter {

	private static Logger logger = Logger.getLogger(EnvFilter.class);

	/** Filtering methods */
	public static MatchEnv[][] filter(MatchEnv matchEnvs[][], DeconvData data,
			DeconvMng mng) throws Exception {
		PeakList<RawPeak> sp = data.getPeakList();

		logger.debug("Valid match envelope number " + cntValid(matchEnvs));
		logger.info("Filtering by real envelope peaks...");
		filterEnvByRealEnv(matchEnvs, mng);

		logger.debug("Valid match envelope number " + cntValid(matchEnvs));
		logger.info("Filtering by score...");
		/* compute scores of matching envelopes here to speed up */
		filterEnvByScr(matchEnvs, mng);

		logger.debug("Valid match envelope number " + cntValid(matchEnvs));
		logger.info("Filtering by charge...");
		filterEnvByChrg(matchEnvs);

		logger.debug("Valid match envelope number " + cntValid(matchEnvs));
		logger.info("Filtering by charge comparison...");
		filterEnvByChrgComp(matchEnvs, sp, mng);
		logger.debug("Valid match envelope number " + cntValid(matchEnvs));
		logger.info("Filtering by mz...");
		filterEnvByMz(matchEnvs, sp, mng);

		logger.debug("Valid match envelope number " + cntValid(matchEnvs));
		return matchEnvs;
	}

	/** Filtering methods */
    public static MatchEnv[][] multipleMassFilter(MatchEnv matchEnvs[][], DeconvData data,
            DeconvMng mng) throws Exception {

        logger.debug("Valid match envelope number " + cntValid(matchEnvs));
        logger.info("Filtering by real envelope peaks...");
        filterEnvByRealEnv(matchEnvs, mng);

        logger.debug("Valid match envelope number " + cntValid(matchEnvs));
        logger.info("Filtering by score...");
        /* compute scores of matching envelopes here to speed up */
        filterEnvByScr(matchEnvs, mng);

        logger.debug("Valid match envelope number " + cntValid(matchEnvs));
        logger.info("Filtering by charge...");
        filterEnvByChrg(matchEnvs);

        logger.debug("Valid match envelope number " + cntValid(matchEnvs));
        return matchEnvs;
    }

	/* count the number of valid matching envleops */
	private static int cntValid(MatchEnv matchEnvs[][]) {
		int cnt = 0;
		for (int i = 0; i < matchEnvs.length; i++) {
			for (int j = 0; j < matchEnvs[i].length; j++) {
				if (matchEnvs[i][j] != null) {
					cnt++;
				}
			}
		}
		return cnt;
	}

	/** Filtering by peak_num */
	private static void filterEnvByRealEnv(MatchEnv matchEnvs[][], DeconvMng mng) {
		for (int i = 0; i < matchEnvs.length; i++) {
			for (int j = 0; j < matchEnvs[i].length; j++) {
				if (matchEnvs[i][j] != null) {
					if (!testRealEnvValid(matchEnvs[i][j], mng)) {
						matchEnvs[i][j] = null;
					}
				}
			}
		}
	}

	/** Test match envelope has a valid real envelope */
	public static boolean testRealEnvValid(MatchEnv env, DeconvMng mng) {
		RealEnv realEnv = env.getRealEnv();
		int massGroup = env.getMassGroup();
		// 1. test if the number of matched peaks >= min_match_peak_num
		if (realEnv.getMatchPeakNum() < mng.minMatchPeakNum[massGroup]) {
			return false;
		}
		// 2. test if the number of missing peaks <= max_miss_peak_num
		if (realEnv.getMissPeakNum() > mng.maxMissPeakNum) {
			return false;
		}
		// 3. test if consecutive peak number >= peak_num - 3
		if (mng.checkConsecutivePeakNum) {
			// get threshold: peak_num - 3
			int nMinConsecutivePeak = mng.compMinConsPeakNum(realEnv
					.getPeakNum(), massGroup);
			if (realEnv.getMaxConsPeakNum() < nMinConsecutivePeak) {
				return false;
			}
		}
		return true;
	}

	/** Filtering by score */
	private static void filterEnvByScr(MatchEnv matchEnvs[][], DeconvMng mng) {
		for (int i = 0; i < matchEnvs.length; i++) {
			for (int j = 0; j < matchEnvs[i].length; j++) {
				if (matchEnvs[i][j] != null) {
					matchEnvs[i][j].compScr(mng);
					if (matchEnvs[i][j].getScore() < mng.minMatchEnvScore) {
						matchEnvs[i][j] = null;
					}
				}
			}
		}
	}

	/**
	 * Filtering by charge, if there is another envelope with k * charge and a
	 * better score, the envelope is removed.
	 */
	private static void filterEnvByChrg(MatchEnv matchEnvs[][]) {
		for (int i = 0; i < matchEnvs.length; i++) {
			for (int j = 0; j < matchEnvs[i].length; j++) {
				int charge = j + 1;
				for (int k = 2 * charge - 1; k < matchEnvs[i].length; k += charge) {
					if (matchEnvs[i][k] != null
							&& matchEnvs[i][j] != null
							&& matchEnvs[i][k].getScore() > matchEnvs[i][j]
									.getScore()) {
						matchEnvs[i][j] = null;
					}
				}
			}
		}
	}

	/**
	 * Filtering by comparing two envelopes with charge and charge + 1, the
	 * better one is kept.
	 */
	private static void filterEnvByChrgComp(MatchEnv matchEnvs[][],
			PeakList<RawPeak> sp, DeconvMng mng) throws Exception {

		for (int i = 0; i < matchEnvs.length; i++) {
			for (int j = mng.chargeComputationBgn - 1; j < matchEnvs[i].length - 1; j++) {
				if (matchEnvs[i][j] != null && matchEnvs[i][j + 1] != null) {
					int result = ChrgComp.comp(sp, matchEnvs[i][j],
							matchEnvs[i][j + 1],
							mng.chargeComputationMzTolerance);
					// rlst may be -1, 0, 1
					if (result == 1) {
						matchEnvs[i][j + 1] = null;
					} else if (result == -1) {
						matchEnvs[i][j] = null;
					}
				}
			}
		}
	}

	/**
	 * Filtering by comparing the envelope with its neighboring envelopes with
	 * the same charge. Onlythe best one is kept.
	 */
	private static void filterEnvByMz(MatchEnv matchEnvs[][],
			PeakList<RawPeak> sp, DeconvMng mng) throws Exception {

		for (int i = 0; i < matchEnvs.length; i++) {
			for (int j = 0; j < matchEnvs[i].length; j++) {
				if (matchEnvs[i][j] != null) {
					int rank = compRank(i, j + 1, matchEnvs, sp, mng);
					if (rank > mng.maxSimilarMzEnvRank) {
						matchEnvs[i][j] = null;
					}
				}
			}
		}
	}

	/** compute the rank of a matchenv in an interval */
	private static int compRank(int idx, int charge, MatchEnv matchEnvs[][],
			PeakList<RawPeak> sp, DeconvMng mng) throws Exception {

		int rank = 0;
		int peak = matchEnvs[idx][charge - 1].getRealEnv().getReferPeakIdx();
		double score = matchEnvs[idx][charge - 1].getScore();
		/* check left */
		int p = peak - 1;
		while (p >= 0
				&& (sp.getPosition(peak) - sp.getPosition(p)) * charge < mng.rankPeakDistance) {
			if (matchEnvs[p][charge - 1] != null
					&& matchEnvs[p][charge - 1].getScore() > score) {
				rank++;
			}
			p--;
		}
		/* check right */
		p = peak + 1;
		while (p < matchEnvs.length
				&& (sp.getPosition(p) - sp.getPosition(peak)) * charge < mng.rankPeakDistance) {
			if (matchEnvs[p][charge - 1] != null
					&& matchEnvs[p][charge - 1].getScore() > score) {
				rank++;
			}
			p++;
		}
		return rank;
	}
}
