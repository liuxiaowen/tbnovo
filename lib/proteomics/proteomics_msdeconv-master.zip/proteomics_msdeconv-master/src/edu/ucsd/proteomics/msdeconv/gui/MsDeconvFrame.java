/**
 * MsDeconv GUI
 * @author  Xiaowen Liu
 * @date    2011-05-01
 */

package edu.ucsd.proteomics.msdeconv.gui;

import java.awt.event.*;
import javax.swing.*;

public class MsDeconvFrame extends JFrame 
    implements WindowListener {

	private static final long serialVersionUID = 1L;
	MsDeconvPanel panel;

    public MsDeconvFrame() {
        setTitle("Ms-Deconv");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(this);
        panel = new MsDeconvPanel();
        add(panel);
        pack();
        setLocationRelativeTo(null);
    }

    public void windowClosing(java.awt.event.WindowEvent e) {
        if (panel.getStatus() == MsDeconvPanel.RUNNING) {
            int response = JOptionPane.showConfirmDialog(this, 
                    "Ms-Deconv is running. Do you want to exit?",
                    "Confirm",
                    JOptionPane.YES_NO_OPTION, 
                    JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                System.exit(1);
            }
        }
        else {
            System.exit(0);
        }
    } 
    public void windowDeactivated(WindowEvent e) {
    }
    public void windowActivated(WindowEvent e) {
    }
    public void windowDeiconified(WindowEvent e) {
    }
    public void windowIconified(WindowEvent e) {
    }
    public void windowClosed(WindowEvent e) {
    }
    public void windowOpened(WindowEvent e) {
    }
}

