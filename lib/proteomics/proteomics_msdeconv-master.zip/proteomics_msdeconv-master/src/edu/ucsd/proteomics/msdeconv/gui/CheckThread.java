/**
 * @author  Xiaowen Liu
 * @date    2011-05-01
 */

package edu.ucsd.proteomics.msdeconv.gui;

import javax.swing.*;

import org.apache.log4j.Logger;

import edu.ucsd.proteomics.msdeconv.DeconvProcess;

public class CheckThread extends Thread {

	private Logger logger = Logger.getLogger(CheckThread.class);

	DeconvProcess msdeconv;
	MsDeconvPanel panel;

	public CheckThread(DeconvProcess msdeconv, MsDeconvPanel panel) {
		this.msdeconv = msdeconv;
		this.panel = panel;
	}

	public void run() {
		try {
			boolean alive = true;
			while (alive) {
				Thread.sleep(1000);
				alive = msdeconv.isAlive();
				String msg = msdeconv.getMsg();
				if (alive) {
					panel.setInfoLabel(msg);
				} else {
					JOptionPane.showMessageDialog(panel, msg);
					panel.setInfoLabel("");
					panel.activeButton();
					panel.setStatus(MsDeconvPanel.NOT_RUNNING);
				}
			}
			msdeconv = null;
		} catch (Exception e) {
			logger.error(e);
			System.exit(1);
		}
	}
}
