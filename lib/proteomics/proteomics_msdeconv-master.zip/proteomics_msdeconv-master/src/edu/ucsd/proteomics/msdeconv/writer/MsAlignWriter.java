/**
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.writer;

import java.io.PrintWriter;

import com.jap.proteomics.spec.sp.MsHeader;

import edu.ucsd.proteomics.msdeconv.env.Env;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.env.RealEnv;

public class MsAlignWriter {

    public static void writeText(PrintWriter out, MatchEnv envs[],
            MsHeader header, int id) throws Exception {
        /*
         * if (env_list.length == 0) { return; }
         */
        out.println("BEGIN IONS");
        out.println("ID=" + id);
        out.println("SCANS=" + header.getScansString());
        if (header.getActivationType() != null) {
            out.println("ACTIVATION=" + header.getActivationType().getName());
        }
        if (header.getMsLevel() > 1) {
            out.println("PRECURSOR_MZ=" + header.getPrecMonoMz());
            out.println("PRECURSOR_CHARGE=" + header.getPrecChrg());
            out.println("PRECURSOR_MASS=" + header.getPrecMonoMass());
        }

        for (int i = 0; i < envs.length; i++) {
            MatchEnv env = envs[i];
            Env theo_env = env.getTheoEnv();
            RealEnv real_env = env.getRealEnv();
            out.print(real_env.getMonoMass());
            out.print("\t" + theo_env.compIntensitySum());
            out.print("\t" + theo_env.getCharge());
            out.println();
        }
        out.println("END IONS");
        out.println();
    }
}
