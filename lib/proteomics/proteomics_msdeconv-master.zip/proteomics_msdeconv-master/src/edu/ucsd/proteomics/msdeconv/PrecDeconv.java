/**
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv;

import org.apache.log4j.Logger;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;

import edu.ucsd.proteomics.msdeconv.detect.EnvDetect;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.filter.EnvFilter;

public class PrecDeconv {

	private static Logger logger = Logger.getLogger(PrecDeconv.class);

	private DeconvMng mng;
	private PeakList<RawPeak> sp;
	private double precMz;
	private int precCharge;

	private int peakBgn;
	private int peakEnd;
	private int nPeakNum;
	private int maxCharge;

	/* result */
	private double newPrecMonoMz;
	private double newPrecAvgMz;
	private int newPrecCharge;

	/** each peak charge pair has a reference theoretical envelop */
	private MatchEnv matchEnv[][];

	public PrecDeconv(double precWindowSize) throws Exception {
		mng = new DeconvMng();
		mng.minReferIntensity = 0f;
		mng.minIntensity = 0f;
		mng.maxMissPeakNum = 3;
		int num[] = { 1, 1, 1 };
		mng.minMatchPeakNum = num;
		mng.minConsecutivePeakNum = num;
		mng.precDeconvInterval = precWindowSize;
	}

	public void setData(PeakList<RawPeak> sp, double precMz, int precCharge) {
		this.sp = sp;
		this.precMz = precMz;
		this.precCharge = precCharge;
		newPrecMonoMz = 0;
		newPrecAvgMz = 0;
		newPrecCharge = 0;
	}

	public void run() throws Exception {
		logger.debug("Prec: " + precMz + " charge: " + precCharge);
		if (precMz <= 0) {
			return;
		}
		initMzIntv();
		if (nPeakNum == 0) {
			return;
		}
		initMaxChrg();
		logger.info("Calcate match envelopes...");
		initMatchEnv();
		logger.info("Do filtering...");
		MatchEnv env = findBest();
		if (env != null) {
			newPrecMonoMz = env.getRealEnv().getMonoMz();
			newPrecAvgMz = env.getTheoEnv().getAvgMz();
			newPrecCharge = env.getRealEnv().getCharge();
			logger.debug("New Prec: " + newPrecMonoMz + " New charge: "
					+ newPrecCharge);
		}

	}

	private void initMzIntv() throws Exception {
		double baseMz = precMz;
		double bgnMz = baseMz - mng.precDeconvInterval;
		double endMz = baseMz + mng.precDeconvInterval;
		//System.out.println("base " + baseMz + " begin " + bgnMz + " end " + endMz);
		peakBgn = sp.size();
		peakEnd = -1;
		for (int i = 0; i < sp.size(); i++) {
			if (sp.getPosition(i) >= bgnMz && sp.getPosition(i) <= endMz) {
				if (i < peakBgn) {
					peakBgn = i;
				}
				if (i > peakEnd) {
					peakEnd = i;
				}
			}
		}
		if (peakEnd < peakBgn) {
			nPeakNum = 0;
		} else {
			nPeakNum = peakEnd - peakBgn + 1;
		}
	}

	private void initMaxChrg() throws Exception {
		double minDistance = 1;
		for (int i = peakBgn - 1; i <= peakEnd; i++) {
			if (i < 0) {
				continue;
			}
			double cur_mz = sp.getPosition(i);
			if (i + 1 >= sp.size()) {
				continue;
			}
			double next_mz = sp.getPosition(i + 1);
			double distance = next_mz - cur_mz;
			if (distance < minDistance) {
				minDistance = distance;
			}
		}
		maxCharge = (int) Math.round(1.0 / minDistance);
		logger.debug("maximum charge: " + maxCharge);
	}

	/** called construction method */
	private void initMatchEnv() throws Exception {
		logger.debug(nPeakNum + " " + maxCharge);
		matchEnv = new MatchEnv[nPeakNum][maxCharge];

		for (int idx = peakBgn; idx <= peakEnd; idx++) {
			for (int charge = 1; charge <= maxCharge; charge++) {
				double mass = sp.getPosition(idx) * charge + 1;
				if (mass > mng.maxMass) {
					mass = mng.maxMass;
				}
				MatchEnv env = EnvDetect.detectEnv(sp, idx, charge, mass, mng);
				if (env != null) {
					// logger.debug("valid ");
					if (!EnvFilter.testRealEnvValid(env, mng)) {
						env = null;
					} else {
						env.compScr(mng);
					}
				}
				matchEnv[idx - peakBgn][charge - 1] = env;
			}
		}
	}

	private MatchEnv findBest() {
		MatchEnv bestEnv = null;
		double bestScore = -1;
		for (int i = peakBgn; i <= peakEnd; i++) {
			for (int j = 1; j <= maxCharge; j++) {
				if (matchEnv[i - peakBgn][j - 1] != null
						&& matchEnv[i - peakBgn][j - 1].getScore() > bestScore) {
					bestScore = matchEnv[i - peakBgn][j - 1].getScore();
					bestEnv = matchEnv[i - peakBgn][j - 1];
				}
			}
		}
		return bestEnv;
	}

	public double getNewPrecMonoMz() {
		return newPrecMonoMz;
	}

	public double getNewPrecAvgMz() {
		return newPrecAvgMz;
	}

	public int getNewPrecChrg() {
		return newPrecCharge;
	}
}
