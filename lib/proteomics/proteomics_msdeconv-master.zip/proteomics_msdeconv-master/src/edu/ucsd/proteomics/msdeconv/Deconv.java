/**
 * Deconvulotion 
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv;

import org.apache.log4j.Logger;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;

import edu.ucsd.proteomics.msdeconv.data.DeconvData;
import edu.ucsd.proteomics.msdeconv.data.DeconvDataFactory;
import edu.ucsd.proteomics.msdeconv.detect.EnvDetect;
import edu.ucsd.proteomics.msdeconv.dp.CoexistTbl;
import edu.ucsd.proteomics.msdeconv.dp.DpA;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.env.MatchEnvArrayFilter;
import edu.ucsd.proteomics.msdeconv.env.MatchEnvArrayUtil;
import edu.ucsd.proteomics.msdeconv.env.MatchEnvRefine;
import edu.ucsd.proteomics.msdeconv.filter.EnvAssign;
import edu.ucsd.proteomics.msdeconv.filter.EnvFilter;
import edu.ucsd.proteomics.msdeconv.util.BioStat;

public class Deconv {

	private static Logger logger = Logger.getLogger(Deconv.class);

	private DeconvMng mng;
	private DeconvData data;
	private MatchEnv resultEnvs[];

	public Deconv(DeconvMng mng) throws Exception {
		this.mng = mng;
	}

	public void setData(PeakList<RawPeak> sp) throws Exception {
		data = DeconvDataFactory.getData(sp, mng);
	}

	public void setData(PeakList<RawPeak> sp, double maxMass, int maxCharge)
			throws Exception {
		data = DeconvDataFactory.getData(sp, maxMass, maxCharge, mng);
	}

	public void run() throws Exception {
		preprocess();
		/* envelope detection */
		MatchEnv candidateEnvs[][] = EnvDetect.getCandidate(data, mng);
		/* envelope filter */
		candidateEnvs = EnvFilter.filter(candidateEnvs, data, mng);
		/* assign envelopes to 1 Da windows */
		MatchEnv windowEnvs[][] = EnvAssign.assignWinEnv(candidateEnvs, data,
				mng.nEnvPerWindow);

		/* prepare table for dp */
		if (mng.checkDoubleIncrease) {
			logger.debug("Generating coexisting table...");
			mng.coexistTable = CoexistTbl.initCoexistTable(windowEnvs,
					mng.scoreErrorTolerance);
		}
		/* dp */
		logger.debug("Generating Graph and DP...");
		DpA dp = new DpA(data, windowEnvs, mng);
		MatchEnv dpEnvs[] = dp.getResult();

		resultEnvs = postprocess(dpEnvs);
	}

	private void preprocess() {
		if (mng.doEstimationMinIntensity) {
			double min_inte = BioStat.getBaseLine(data.getPeakList()
					.getIntensities());
			//System.out.println("min_inte " + min_inte);
			mng.setMinInte(min_inte);
		}
	}

	private MatchEnv[] postprocess(MatchEnv dpEnvs[]) throws Exception {
		// assign intensity
		MatchEnvArrayUtil.assignIntensity(data.getPeakList(), dpEnvs);
		// refinement
        if (!mng.outputMultipleMass) {
            MatchEnvRefine.mzRefine(mng, dpEnvs);
        }

		MatchEnv resultEnvs[] = dpEnvs;
		if (mng.doFinalFiltering) {
			resultEnvs = MatchEnvArrayFilter.filter(dpEnvs, data.getMaxMass(),
					mng);
		}

		if (mng.keepUnusedPeaks) {
			resultEnvs = MatchEnvArrayUtil.addLowMassPeak(resultEnvs, data
					.getPeakList(), mng.mzTolerance);
		}
		// reassign intensity
		MatchEnvArrayUtil.assignIntensity(data.getPeakList(), resultEnvs);

        if (mng.outputMultipleMass) {
		    /* envelope detection */
		    MatchEnv candidateEnvs[][] = EnvDetect.getCandidate(data, mng);
		    /* envelope filter */
		    candidateEnvs = EnvFilter.multipleMassFilter(candidateEnvs, data, mng);
            resultEnvs = MatchEnvArrayUtil.addMultipleMass(resultEnvs, candidateEnvs,
                    mng.multipleMinMass, mng.multipleMinCharge, mng.multipleMinRatio);
        }

		return resultEnvs;
	}

	public MatchEnv[] getResult() {
		return resultEnvs;
	}
}
