/**
 *  Xiaowen Liu
 *  Jan 2, 2009
 *  
 *  This class is used to store the changable parameters 
 *  for spectrum package.
 */

package edu.ucsd.proteomics.msdeconv;

import edu.ucsd.proteomics.msdeconv.detect.DistrEnvFactory;

public class DeconvMng {
    

    public static double defaultMaxMass = 50000;
    public static int defaultMaxCharge = 30;

    /************************************************
     * Initialize data
     ************************************************/
    /* using input parameters to assign: max_chrg, max_mass */
    public int maxCharge = 30;
    public double maxMass = 110000f;
    public double windowSize = 1.0f;

    /************************************************
     * Preprocess
     ************************************************/
    /** estimate min intensity using thrash method. */
    public boolean doEstimationMinIntensity = true;
    /** signal noise ratio */
    public double snRatio = 1f;
    /** minimum peak intensity */
    public double minIntensity = 0f;
    /** minimum base peak intensity */
    /* minReferIntensity = minIntensity * snRatio */
    public double minReferIntensity = 0f;

    /************************************************
     * Envelope detection
     ************************************************/
    // min_inte and min_ref_inte is used in envelope detection

    /** Distribution Envelope factory */
    /* initialized before deconvolution */
    public DistrEnvFactory distributionEnvFactory;
    public String distributionEnvFileName = "theo_patt.txt";
    public int distributionEnvEntryNum = 11000;
    public double distributionEnvMassInterval = 10f;
    /* the minimum monoisotopic envelope for an envelope */
    public double minMass = 50f;
    /*
     * Several parameters are related with the mass of envelopes. We classify
     * envelopes into 3 groups based on its base mass. See getMassGroup().
     */
    public double massGroupBoundary[] = { minMass, minMass, 1500f,
            maxMass };
    /*
     * perc bound is used for remove low intensities in theoretical envelopes
     */
    public double percentageBound[] = { 0.95f, 0.95f, 0.85f };
    /*
     * maximum number of peaks left and right to the base peak in theoretical
     * envelopes
     */
    public int maxBackwardPeakNum = 8;
    public int maxForwardPeakNum = 8;

    /* error tolerance for matching real peaks to theoretical peaks */
    public double mzTolerance = 0.02f;

    /************************************************
     * Envelope filtering
     ************************************************/
    /*
     * 1. filtering based on real envelop an real envelope is valid if 1) peak
     * number >= 3 2) at most 1 missing peak 3) consecutive peak number >=
     * peak_num - 3, 3
     */
    /* minimum peak number in an envelope */
    public int minMatchPeakNum[] = { 1, 2, 3 };
    public int maxMissPeakNum = 1;
    /* check consecutive peaks */
    public boolean checkConsecutivePeakNum = true;
    public int relativeConsecutivePeakNum = -3;
    public int minConsecutivePeakNum[] = { 1, 2, 3 };
    /*
     * 2. filtering using score
     */
    /* parameters for computing scores of matching envelopes */
    /* if small mz shift is used */
    public boolean doMzShift = false;
    /*
     * when mz shift is used, the minimum shift is 0.001, shift_fold = 1/0.001
     */
    public int shiftScale = 1000;
    /* if intensity ratio is used */
    public boolean doIntensityRatio = false;
    /*
     * when intensity ratio is used, the minimum shift is 0.01, ratio_fold =
     * 1/0.01. We enumerate all possible intensity ratios from bgn_ratio to
     * end_ratio
     */
    public int intensityRatioScale = 100;
    public double bgnRatio = 0.8f;
    public double endRatio = 1.2f;
    /** maximum error in computing m/z accuracy */
    public double scoreErrorTolerance = mzTolerance;
    /** minimum score for matching envelopes */
    public double minMatchEnvScore = 0f;
    /*
     * 3. fitering using envelopes with charge X, 2X, 3X, ... no parameters here
     */
    /*
     * 4. filtering by comparing envelopes with similar charge
     */
    public int chargeComputationBgn = 15;
    public double chargeComputationMzTolerance = 0.002f;
    /*
     * 5. filtering by comparing envelopes with similar mz and same charge
     */
    /* filtering on mz */
    public double rankPeakDistance = 12f;
    public int maxSimilarMzEnvRank = 0;

    /************************************************
     * Envelope assigned to 1 Da intervals
     ************************************************/
    /** number of envelopes per window */
    public int nEnvPerWindow = 5;

    /*************************************************
     * DP algorithm
     ************************************************/
    /** Check double increasing when two envelopes overlap */
    public boolean checkDoubleIncrease = true;
    public boolean coexistTable[][];

    /** maximum number of envelopes sharing one peak */
    public int maxEnvNumPerPeak = 2;
    /** used in dpB to specify the number of output envelopes */
    public int dpEnvNum = 300;
    /** maximum number of vertices per window */
    public int maxEnvNumPerVertex = 10;
    
    /*************************************************
     * envelope final filtering
     ************************************************/
    // use filtering to keep only highest peaks. 
    public boolean doFinalFiltering = true;
    public double lowHighDividor = 1500f;
    public double aaAvgMass = 120;
    public double peakDensity = 2;
    
    /*************************************************
     * keep unused peaks
     *************************************************/
    public boolean keepUnusedPeaks = false;

    /** keep multiple mass */
    public boolean outputMultipleMass = false;
    public double multipleMinMass = 5000;
    public int multipleMinCharge = 20;
    public double multipleMinRatio = 0.9;
    
    /*************************************************
     * PrecDeconv
     *************************************************/
    public double precDeconvInterval = 2f;

    public DeconvMng() throws Exception {
        distributionEnvFactory = new DistrEnvFactory(distributionEnvFileName,
                distributionEnvEntryNum, distributionEnvMassInterval);
    }

    public void setMinInte(double min_inte) {
        this.minIntensity = min_inte;
        this.minReferIntensity = min_inte * snRatio;
    }

    /* get the mass group based on mass value */
    public int getMassGroup(double base_mass) {
        int group = -1;
        for (int i = 0; i < massGroupBoundary.length - 1; i++) {
            if (base_mass >= massGroupBoundary[i]
                    && base_mass < massGroupBoundary[i + 1]) {
                group = i;
                break;
            }
        }
        return group;
    }

    public double getPercentBound(int mass_group) {
        return percentageBound[mass_group];
    }

    /** compute minimum consecutive peak num: max{peak_num -3 , 3} */
    public int compMinConsPeakNum(int peak_num, int mass_group) {
        int min_cons_peak_num = peak_num + relativeConsecutivePeakNum;
        if (min_cons_peak_num < minConsecutivePeakNum[mass_group]) {
            min_cons_peak_num = minConsecutivePeakNum[mass_group];
        }
        return min_cons_peak_num;
    }
    
    public void setTolerance(double tolerance) {
        mzTolerance = tolerance;
        scoreErrorTolerance = tolerance;
    }
}
