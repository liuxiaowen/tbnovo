/**
 * The vertex for path graph with score 
 * for different number of envelopes.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.dp;

import java.util.Arrays;

public class VertexB extends Vertex implements Cloneable {

    /* dp scores for different number of envelopes */
    private double scores[];
    /* previous vertex id */
    private int prevs[];

    public VertexB(int bgnPeak, int nPreWinPeak, int nCurWinPeak, int nEnv) {
        super(bgnPeak, nPreWinPeak, nCurWinPeak);

        /* zero envelope is considered, so we have env_num + 1 */
        scores = new double[nEnv + 1];
        prevs = new int[nEnv + 1];
        Arrays.fill(scores, 0);
        Arrays.fill(prevs, -1);
    }

    /** clone */
    public Object clone() throws CloneNotSupportedException {
        VertexB newVertex = (VertexB) super.clone();
        newVertex.scores = (double[]) scores.clone();
        newVertex.prevs = (int[]) prevs.clone();
        return newVertex;
    }

    /*************************************************
     * Gets
     ************************************************/

    public double getScoreB(int i) {
        return scores[i];
    }

    public int getPrevB(int i) {
        return prevs[i];
    }

    public void setScoreB(int i, double s) {
        scores[i] = s;
    }

    public void setPrevB(int i, int p) {
        prevs[i] = p;
    }

}
