/**
 * The vertex for path graph.
 *
 * @author  Xiaowen Liu
 * @date    2009-1-2
 */

package edu.ucsd.proteomics.msdeconv.dp;

import java.util.Arrays;
import java.util.ArrayList;

import edu.ucsd.proteomics.msdeconv.DeconvMng;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class Vertex implements Cloneable {

    public static DeconvMng mng;

    protected int bgnPeak;
    protected int nPeak;
    protected int curBgnPos;

    protected int peakUseCnts[];

    /* for each envelope, there is a peak list */
    protected ArrayList<MatchEnv> preMatchEnv;
    protected ArrayList<MatchEnv> curMatchEnv;

    /* There is a list of EnvPeakPairs for each peak */
    protected ArrayList<EnvPeakPair> preEnvPeakPair[];
    protected ArrayList<EnvPeakPair> curEnvPeakPair[];

    @SuppressWarnings("unchecked")
    public Vertex(int bgnPeak, int preWinPeakNum, int curWinPeakNum) {
        this.bgnPeak = bgnPeak;
        nPeak = preWinPeakNum + curWinPeakNum;
        curBgnPos = preWinPeakNum;
        peakUseCnts = new int[nPeak];
        Arrays.fill(peakUseCnts, 0);

        preMatchEnv = new ArrayList<MatchEnv>();
        curMatchEnv = new ArrayList<MatchEnv>();

        preEnvPeakPair = new ArrayList[nPeak];
        curEnvPeakPair = new ArrayList[nPeak];
        for (int i = 0; i < nPeak; i++) {
            preEnvPeakPair[i] = new ArrayList<EnvPeakPair>();
            curEnvPeakPair[i] = new ArrayList<EnvPeakPair>();
        }
    }

    /** clone implementation */
    @SuppressWarnings("unchecked")
    public Object clone() throws CloneNotSupportedException {
        Vertex newVertex = (Vertex) super.clone();
        // deep copy
        newVertex.peakUseCnts = (int[]) peakUseCnts.clone();
        newVertex.preMatchEnv = new ArrayList<MatchEnv>();
        for (int i = 0; i < preMatchEnv.size(); i++) {
            newVertex.preMatchEnv.add(preMatchEnv.get(i));
        }
        newVertex.curMatchEnv = new ArrayList<MatchEnv>();
        for (int i = 0; i < curMatchEnv.size(); i++) {
            newVertex.curMatchEnv.add(curMatchEnv.get(i));
        }
        newVertex.preEnvPeakPair = new ArrayList[nPeak];
        newVertex.curEnvPeakPair = new ArrayList[nPeak];
        for (int i = 0; i < nPeak; i++) {
            newVertex.preEnvPeakPair[i] = new ArrayList<EnvPeakPair>();
            for (int j = 0; j < preEnvPeakPair[i].size(); j++) {
                newVertex.preEnvPeakPair[i].add(preEnvPeakPair[i].get(j));
            }
            newVertex.curEnvPeakPair[i] = new ArrayList<EnvPeakPair>();
            for (int j = 0; j < curEnvPeakPair[i].size(); j++) {
                newVertex.curEnvPeakPair[i].add(curEnvPeakPair[i].get(j));
            }
        }
        return newVertex;
    }

    /** check conexistance table */
    private boolean passDblIncrCheck(MatchEnv env) {
        int id = env.getId();
        int existId;
        for (int i = 0; i < preMatchEnv.size(); i++) {
            existId = preMatchEnv.get(i).getId();
            if (!mng.coexistTable[id][id - existId - 1]) {
                return false;
            }
        }

        for (int i = 0; i < curMatchEnv.size(); i++) {
            existId = curMatchEnv.get(i).getId();
            if (!mng.coexistTable[id][id - existId - 1]) {
                return false;
            }
        }
        return true;
    }

    /** check conexistance table */
    private boolean passDblIncrCheck(ArrayList<MatchEnv> envList) {
        for (int i = 0; i < envList.size(); i++) {
            if (!passDblIncrCheck(envList.get(i))) {
                return false;
            }
        }
        return true;
    }

    /** Add an envelope to the previous window envelope list */
    public boolean addPreEnv(MatchEnv env, int maxOverlap) {
        if (mng.checkDoubleIncrease && !passDblIncrCheck(env)) {
            return false;
        }
        int peakList[] = env.getRealEnv().getPeakIdxList();
        for (int i = 0; i < peakList.length; i++) {
            if (env.getRealEnv().isExist(i) && peakList[i] >= bgnPeak
                    && peakList[i] - bgnPeak < nPeak) {

                peakUseCnts[peakList[i] - bgnPeak]++;
                if (peakUseCnts[peakList[i] - bgnPeak] > maxOverlap) {
                    return false;
                }
                preEnvPeakPair[peakList[i] - bgnPeak].add(new EnvPeakPair(env,
                        i));
            }
        }
        preMatchEnv.add(env);
        return true;
    }

    /** Add an envelope to the current window envelope list */
    public boolean addCurEnv(MatchEnv env, int maxOverlap) {
        if (mng.checkDoubleIncrease && !passDblIncrCheck(env)) {
            return false;
        }
        int peakList[] = env.getRealEnv().getPeakIdxList();
        for (int i = 0; i < peakList.length; i++) {
            if (env.getRealEnv().isExist(i) && peakList[i] >= bgnPeak
                    && peakList[i] - bgnPeak < nPeak) {
                peakUseCnts[peakList[i] - bgnPeak]++;
                if (peakUseCnts[peakList[i] - bgnPeak] > maxOverlap) {
                    return false;
                }
                curEnvPeakPair[peakList[i] - bgnPeak].add(new EnvPeakPair(env,
                        i));
            }
        }
        curMatchEnv.add(env);
        return true;
    }

    public void trim() {
        preMatchEnv.trimToSize();
        curMatchEnv.trimToSize();

        for (int i = 0; i < nPeak; i++) {
            preEnvPeakPair[i].trimToSize();
            curEnvPeakPair[i].trimToSize();
        }
    }

    /** check if two vertices in neighboring windows are consistent */
    public static boolean checkConsist(Vertex pre, Vertex cur,
            int nMaxEnvPerPeak) {
        /* if same size */
        if (pre.curMatchEnv.size() != cur.preMatchEnv.size()) {
            return false;
        }
        /* if same envelope list */
        for (int i = 0; i < pre.curMatchEnv.size(); i++) {
            if (pre.curMatchEnv.get(i) != cur.preMatchEnv.get(i)) {
                return false;
            }
        }
        /* if no more than max overlap */
        for (int i = 0; i < pre.preEnvPeakPair.length; i++) {
            if (pre.preEnvPeakPair[i].size() > 0) {
                int peakIdx = i + pre.bgnPeak - cur.bgnPeak;
                if (peakIdx >= 0
                        && cur.peakUseCnts[peakIdx]
                                + pre.preEnvPeakPair[i].size() > nMaxEnvPerPeak) {
                    return false;
                }
            }
        }
        if (mng.checkDoubleIncrease
                && !pre.passDblIncrCheck(cur.getCurMatchEnv())) {
            return false;
        }

        return true;
    }

    /** compute the score for peak sharing model */
    public static double getShareScr(Vertex pre, Vertex cur) {
        double score = 0f;
        for (int curPnt = 0; curPnt < cur.curBgnPos; curPnt++) {
            /* merge three peak pair list */
            int prePnt = curPnt + cur.bgnPeak - pre.bgnPeak;
            int nEnv = pre.preEnvPeakPair[prePnt].size()
                    + cur.preEnvPeakPair[curPnt].size()
                    + cur.curEnvPeakPair[curPnt].size();
            EnvPeakPair pair[] = new EnvPeakPair[nEnv];
            int cnt = 0;
            for (int i = 0; i < pre.preEnvPeakPair[prePnt].size(); i++) {
                pair[cnt] = pre.preEnvPeakPair[prePnt].get(i);
                cnt++;
            }
            for (int i = 0; i < cur.preEnvPeakPair[curPnt].size(); i++) {
                pair[cnt] = cur.preEnvPeakPair[curPnt].get(i);
                cnt++;
            }
            for (int i = 0; i < cur.curEnvPeakPair[curPnt].size(); i++) {
                pair[cnt] = cur.curEnvPeakPair[curPnt].get(i);
                cnt++;
            }
            /* compute sum of intensity */
            double intensitySum = 0f;
            for (int i = 0; i < nEnv; i++) {
                intensitySum += pair[i].getTheoIntensity();
            }
            /* compute score */
            for (int i = 0; i < nEnv; i++) {
                score += pair[i].getPeakScore(intensitySum, mng.scoreErrorTolerance);
            }
        }
        return score;
    }

    /*************************************************
     * Gets
     ************************************************/
    public int getMatchEnvSize() {
        return preMatchEnv.size() + curMatchEnv.size();
    }

    public int[] getPeakUseCnt() {
        return peakUseCnts;
    }

    public ArrayList<MatchEnv> getPreMatchEnv() {
        return preMatchEnv;
    }

    public ArrayList<MatchEnv> getCurMatchEnv() {
        return curMatchEnv;
    }

    public int getPreMatchEnvSize() {
        return preMatchEnv.size();
    }

    public static void setDeconvMng(DeconvMng mng) {
        Vertex.mng = mng;
    }
}
