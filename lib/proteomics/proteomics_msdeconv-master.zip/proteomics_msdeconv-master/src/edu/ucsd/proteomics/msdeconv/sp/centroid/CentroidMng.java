package edu.ucsd.proteomics.msdeconv.sp.centroid;


/**
 *  Xiaowen Liu
 *  Dec 14, 2010
 *  
 *  This class for storing the parameters for spectral centroiding.
 */
public class CentroidMng {

    public float sn_ratio = 1f; 
    public float mz_thresh = 0.02f; 

    public CentroidMng() {
    //    BasicConfigurator.configure();
    //    logger.getRootLogger().setLevel(Level.WARN);
    }
}


