/**
 * Assign Match Envelopes to 1 Da intervals
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */


package edu.ucsd.proteomics.msdeconv.filter;

import java.util.ArrayList;
import java.util.Collections;

import edu.ucsd.proteomics.msdeconv.data.DeconvData;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;

public class EnvAssign {
    
    /** compute the best envelope for each window */
    @SuppressWarnings("unchecked")
    public static MatchEnv[][] assignWinEnv(MatchEnv matchEnvs[][],
                                            DeconvData data,
                                            int nEnvPerWindow) {
        int nWindow = data.getWinNum();
        ArrayList<MatchEnv> envList[] = new ArrayList[nWindow];
        for (int i = 0; i < nWindow; i++) {
            envList[i] = new ArrayList<MatchEnv>();
        }
        /* add matchenv to the list */
        for (int i = 0; i < matchEnvs.length; i++) {
            // i is peak idx 
            int winId = data.getWinId(i);
            for (int j = 0; j < matchEnvs[i].length; j++) {
                if (matchEnvs[i][j] != null) {
                    envList[winId].add(matchEnvs[i][j]);
                }
            }
        }
        /* sort the matched envelopes and keep the best */
        for (int i = 0; i < nWindow; i++) {
            Collections.sort(envList[i]);
            if (envList[i].size() > nEnvPerWindow) {
                for (int j = envList[i].size() - 1; 
                        j >= nEnvPerWindow; j--) { 
                    envList[i].remove(j);
                }
            }
        }
        /* convert to array */
        MatchEnv winEnvs[][] = new MatchEnv[nWindow][];
        for (int i = 0; i < nWindow; i++) {
            winEnvs[i] = (MatchEnv[])envList[i].toArray(new MatchEnv[0]);
        }
        return winEnvs;
    }
}

