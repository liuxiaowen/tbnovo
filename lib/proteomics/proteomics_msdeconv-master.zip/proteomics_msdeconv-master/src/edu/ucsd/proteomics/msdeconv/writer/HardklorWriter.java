/**
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.writer;

import java.io.PrintWriter;

import com.jap.proteomics.spec.sp.MsHeader;

import edu.ucsd.proteomics.msdeconv.env.Env;
import edu.ucsd.proteomics.msdeconv.env.MatchEnv;
import edu.ucsd.proteomics.msdeconv.env.RealEnv;

public class HardklorWriter {

    public static void writeText(PrintWriter out, MatchEnv envs[],
            MsHeader header) throws Exception {

        String retentionTime = header.getRetentionTime();
        String time = retentionTime.substring(2, retentionTime.length() - 3);
        if (header.getMsLevel() > 1) {
			out.println("S\t" + header.getFirstScanNum() + "\t" + time + "\t"
					+ header.getFileName() + "\t" + header.getPrecMonoMass()
					+ "\t" + header.getPrecChrg() + "\t"
					+ header.getPrecMonoMz());
        }
        else {
            out.println("S\t" + header.getFirstScanNum() + "\t" + time + "\t"
                    + header.getFileName());	
        }
        for (int i = 0; i < envs.length; i++) {
            MatchEnv env = envs[i];
            Env theoEnv = env.getTheoEnv();
            RealEnv realEnv = env.getRealEnv();
            out.print("P");
            out.print("\t" + realEnv.getMonoMass());
            out.print("\t" + realEnv.getCharge());
            out.print("\t" + theoEnv.compIntensitySum());
            out.print("\t" + realEnv.getMonoMz());
            out.print("\t" + realEnv.getMonoMz() + "-" + realEnv.getMonoMz());
            out.print("\t0.0000");
            out.print("\t-");
            out.print("\t1.0000");
            out.println();
        }
    }
}
