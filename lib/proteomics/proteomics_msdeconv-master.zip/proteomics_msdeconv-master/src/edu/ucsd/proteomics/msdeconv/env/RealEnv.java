/**
 * Describes a real envolope
 *
 * @author  Xiaowen Liu
 * @date    2009-10-9
 */

package edu.ucsd.proteomics.msdeconv.env;

import java.util.Arrays;

import org.apache.log4j.Logger;

import com.jap.proteomics.spec.rawsp.RawPeak;
import com.jap.proteomics.spec.sp.PeakList;


public class RealEnv extends Env {
	private static Logger logger = Logger.getLogger(RealEnv.class);

	private static int NON_EXIST_PEAK = -1;

	/** peak index in the spectrum */
	// if peak_idx[i] == NO_EXIST_PEAK, it does not exist */
	private int[] peakIdxes;
	/** number of missing peaks */
	private int nMissPeak;
	/** maximum number of consecutive peaks */
	private int nMaxConsecutivePeak;

	/** Get a real env from a ref envelope and a spectrum */
	public RealEnv(PeakList<RawPeak> sp, Env theoEnv, double tolerance,
			double minIntensity) throws Exception {

		/* copy */
		referIdx = theoEnv.referIdx;
		charge = theoEnv.charge;
		monoMz = theoEnv.monoMz;

		/* map peaks in theo_env to the peaks in sp */
		mapPeakList(sp, theoEnv, tolerance, minIntensity);
		/* remove duplicated matches */
		remvDuplMatch(theoEnv);
		/* count missing peak number */
		cntMissPeakNum();
		/* count maximum consecutive peak number */
		cntMaxConsPeakNum();
	}



	/** map peaks in theo_env to the peaks in sp */
	private void mapPeakList(PeakList<RawPeak> sp, Env theoEnv, double tolerance,
			double minIntensity) throws Exception {
		int nPeak = theoEnv.getPeakNum();
		mzs = new double[nPeak];
		intensities = new double[nPeak];
		peakIdxes = new int[nPeak];
		Arrays.fill(peakIdxes, NON_EXIST_PEAK);
		Arrays.fill(mzs, NON_EXIST_PEAK);
		for (int i = 0; i < nPeak; i++) {
			logger.trace("mz " + i + " is " + theoEnv.mzs[i]);
			RawPeak rawPeak = new RawPeak(theoEnv.mzs[i], 0);
			int peak = sp.getNearPeakIdx(rawPeak, tolerance);
			logger.trace("peak idx " + peakIdxes);
			if (peak >= 0 && sp.getIntensity(peak) >= minIntensity) {
				peakIdxes[i] = peak;
				mzs[i] = sp.getPosition(peakIdxes[i]);
				intensities[i] = sp.getIntensity(peakIdxes[i]);
			}
		}
	}

	/**
	 * remove duplicated matches. If two theoretical peaks are matched to the
	 * same real peak, only the one with less mz error is kept.
	 */
	private void remvDuplMatch(Env theoEnv) {
		for (int i = 0; i < getPeakNum() - 1; i++) {
			if (isExist(i) && peakIdxes[i] == peakIdxes[i + 1]) {
				if (Math.abs(theoEnv.mzs[i] - mzs[i]) < Math
						.abs(theoEnv.mzs[i + 1] - mzs[i + 1])) {
					peakIdxes[i + 1] = NON_EXIST_PEAK;
					mzs[i + 1] = NON_EXIST_PEAK;
					intensities[i + 1] = 0;
				} else {
					peakIdxes[i] = NON_EXIST_PEAK;
					mzs[i] = NON_EXIST_PEAK;
					intensities[i] = 0;
				}
			}
		}
	}

	/** Count missing peak number */
	private void cntMissPeakNum() {
		nMissPeak = 0;
		for (int i = 0; i < getPeakNum(); i++) {
			if (!isExist(i)) {
				nMissPeak++;
			}
		}
	}

	/** Compute maximum number of consecutive matched peaks */
	private void cntMaxConsPeakNum() {
		nMaxConsecutivePeak = 0;
		int n = 0;
		for (int i = 0; i < getPeakNum(); i++) {
			if (isExist(i)) {
				n++;
				if (n > nMaxConsecutivePeak) {
					nMaxConsecutivePeak = n;
				}
			} else {
				n = 0;
			}
		}
	}

	/*************************************************
	 * Get and set
	 ************************************************/
	public int getMissPeakNum() {
		return nMissPeak;
	}

	public int getMatchPeakNum() {
		return getPeakNum() - nMissPeak;
	}

	public int getMaxConsPeakNum() {
		return nMaxConsecutivePeak;
	}

	public int getPeakIdx(int i) {
		return peakIdxes[i];
	}

	public int[] getPeakIdxList() {
		return peakIdxes;
	}

	public int getReferPeakIdx() {
		return peakIdxes[referIdx];
	}

	public boolean isExist(int i) {
		if (peakIdxes[i] != NON_EXIST_PEAK) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean testPeakShare(RealEnv a, RealEnv b) {
		int peakA[] = a.peakIdxes;
		int peakB[] = b.peakIdxes;
		for (int i = 0; i < peakA.length; i++) {
			for (int j = 0; j < peakB.length; j++) {
				if (peakA[i] >= 0 && peakB[j] == peakA[i]) {
					return true;
				}
			}
		}
		return false;
	}
}

//public RealEnv(int referIdx, int charge, double monoMz, double mzs[],
//		double intensities[], int peakIdxes[], int nMissPeak,
//		int nMaxConsecutivePeak) {
//	super(referIdx, charge, monoMz, mzs, intensities);
//	this.peakIdxes = peakIdxes;
//	this.nMissPeak = nMissPeak;
//	this.nMaxConsecutivePeak = nMaxConsecutivePeak;
//}

