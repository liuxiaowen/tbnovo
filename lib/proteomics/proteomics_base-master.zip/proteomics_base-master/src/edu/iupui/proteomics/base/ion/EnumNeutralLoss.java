package edu.iupui.proteomics.base.ion;


public enum EnumNeutralLoss {
	
	NONE("", 0),
	WATER("Water", 18.0106),
	AMMONIA("Ammonia", 17.0265);


	private String name;

	private double mass;

	EnumNeutralLoss(String name, double mass) {
		this.name = name;
		this.mass = mass;
	}

	/**
	 * Gets
	 */
	public String getName() {
		return name;
	}

	public double getMass() {
		return mass;
	}

}
