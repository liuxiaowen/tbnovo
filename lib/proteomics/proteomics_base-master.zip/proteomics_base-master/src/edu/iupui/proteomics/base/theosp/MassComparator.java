package edu.iupui.proteomics.base.theosp;

import java.util.Comparator;


/**
 * Comparator based on sum of residue masses/molecular masses of sequences.
 */
public class MassComparator implements Comparator<BpSpec> {
	public int compare(BpSpec s1, BpSpec s2) {
		if (s1.getResSeq().getResMassSum() < s2.getResSeq().getResMassSum()) {
			return -1;
		} else if (s1.getResSeq().getResMassSum() > s2.getResSeq()
				.getResMassSum()) {
			return 1;
		} else {
			return 0;
		}
	}
}
