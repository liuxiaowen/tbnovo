/**
 * Implements the idea of a residue containing an acid and a ptm. 
 * When the acid does not have a ptm, it is represented by a ptm with mass 0.0.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.residue;

public class Res {
	/** amino acid */
	private Acid acid;
	/** post-translational modification */
	private Ptm ptm;
	/** residue mass */
	private double mass;

	Res(Acid acid, Ptm ptm) {
		this.acid = acid;
		this.ptm = ptm;
		mass = acid.getResidueMonoMass() + ptm.getMonoMass();
	}

	/** Get amino acid. */
	public Acid getAcid() {
		return acid;
	}
	
	/** Get residue mass. */
	public double getMass() {
		return mass;
	}

	/** Get post-translational modification. */
	public Ptm getPtm() {
		return ptm;
	}

	/**
	 * Checks if the residue contains the same amino acid and ptm.
	 */
	public boolean isSame(Acid acid, Ptm ptm) {
		return this.acid == acid && this.ptm == ptm;
	}
	
	/** Get string representation */
	public String toString(char delimBgn, char delimEnd) {
		if (ptm.isEmpty()) {
			return acid.getOneLetter();
		} else {
			return acid.getOneLetter() + delimBgn + ptm.getAbbrName()
					+ delimEnd;
		}
	}
}
