/**
 * The class for reading fasta files.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.seqdb;

import java.io.File;


import edu.iupui.proteomics.base.residue.Acid;
import edu.iupui.proteomics.base.residue.AcidList;
import edu.iupui.proteomics.base.residue.Res;
import edu.iupui.proteomics.base.residue.ResArrayUtil;
import edu.iupui.proteomics.base.residue.ResList;
import edu.iupui.proteomics.base.seq.ResSeq;


public class ResReader {

	FastaSeqReader reader;
	/** amino acid list */
	AcidList acidList;
	/** residue list */
	ResList resList;

	/**
	 * Constructs an instance with a File and acid list and residue list.
	 */

	public ResReader(File proteinDatabase, ResList resList)
			throws Exception {
		reader = new FastaSeqReader(proteinDatabase);
		this.acidList = AcidList.getCompleteAcidList();
		this.resList = resList;
	}
	
	public ResReader(FastaSeqReader reader, ResList resList) {
		this.reader = reader;
		this.acidList = AcidList.getCompleteAcidList();
		this.resList = resList;
	}

	/**
	 * Read FASTA file and return next protein as an ResSeq.
	 */
	public ResSeq getNextResSeq() throws Exception {
		String[] seqInfo = reader.getNextSeq();
		if (seqInfo == null) {
			return null;
		}
		String name = seqInfo[0];
		String seq = seqInfo[1];
		Acid acids[] = acidList.convert(seq);
		Res residues[] = ResArrayUtil.getResArrayByAcid(resList, acids);
		return new ResSeq(name, residues);
	}
}
