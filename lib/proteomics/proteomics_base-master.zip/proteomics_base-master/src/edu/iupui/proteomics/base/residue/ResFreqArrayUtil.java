package edu.iupui.proteomics.base.residue;

public class ResFreqArrayUtil {
	/** Gets average mass. */
	public static double getAvgMass (ResFreq residues[]) {
		double massSum = 0;
		double freqSum = 0;
		for (int i = 0; i < residues.length; i++) {
			massSum = massSum + residues[i].getMass() * residues[i].getFreq();
			freqSum = freqSum + residues[i].getFreq();
		}
		return massSum / freqSum;
	}
	
	/** Gets frequencies of residues. */
	public static double[] getFrequencies(ResFreq residues[]) {
		double frequencies[] = new double[residues.length];
		for (int i = 0; i < residues.length; i++) {
			frequencies[i] = residues[i].getFreq();
		}
		return frequencies;
	}
	
	public static ResFreq[] getResFreqArray(Res residues[]) {
		ResFreq resFreqs[] = new ResFreq[residues.length];
		for (int i = 0; i < residues.length; i++) {
			Res res = residues[i];
			resFreqs[i] = new ResFreq(res.getAcid(), res.getPtm(), res.getAcid().getAcidFreq());
		}
		return resFreqs;
	}

}
