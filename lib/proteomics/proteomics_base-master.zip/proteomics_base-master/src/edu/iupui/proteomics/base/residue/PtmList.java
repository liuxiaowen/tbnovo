/**
 * A list of post translational modifications (ptms).
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.residue;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

public class PtmList extends ArrayList<Ptm> {
	private static final long serialVersionUID = 1L;
	
	/** Complete PTM list, all other PTM list are subset of this list */
	private static PtmList completeList;
	static {
		try {
			completeList = getDefinedList();
		}
		catch (Exception ex) {
			System.err.println("Error in initializing the complete ptm list");
			ex.printStackTrace();
			System.exit(1);
		}
	}
	
	/**
	 * Checks if the list contains a ptm with the specific abbreviation name.
	 */
	public boolean containsAbbrName(String abbrName) {
		return getPtmByAbbrName(abbrName) != null;
	}
	
	public Ptm getEmptyPtm () {
		for (int i = 0; i < size(); i++) {
			if (get(i).isEmpty()) {
				return get(i);
			}
		}
		return null;
	}

	/**
	 * Returns a PTM based on the abbreviation name. Returns null if the abbreviation name
	 * does not exist.
	 */
	public Ptm getPtmByAbbrName(String abbrName) {
		for (int i = 0; i < size(); i++) {
			String n = get(i).getAbbrName();
			if (n.equals(abbrName)) {
				return get(i);
			}
		}
		return null;
	}
	
	public static PtmList getCompletePtmList() {
		return completeList;
	}

	/**
	 * Returns a default PTM list.
	 */
	private static PtmList getDefinedList()
			throws Exception {
		/* get the factory */
		AcidList acidList = AcidList.getCompleteAcidList();
		InputStream stream = ResMng.getDefinedPtmXmlStream();
		return getInstance(stream, acidList, true);
	}
	
	/**
	 * Returns a PTM list from a xml file.
	 */
	public static PtmList getFileInstance(File file)
			throws Exception {
		/* get the factory */
		AcidList acidList = AcidList.getCompleteAcidList();
		InputStream stream = new FileInputStream(file);
		return getInstance(stream, acidList, false);
	}
	
	private static PtmList getInstance(InputStream stream, AcidList acidList, boolean isCompleteList)
			throws Exception {
		/* get the factory */
		SAXBuilder builder = new SAXBuilder();
		Document doc = builder.build(stream);
		Element root = doc.getRootElement();
		List<?> ptmElements = root.getChildren();
		PtmList ptmList = new PtmList();
		for (int i = 0; i < ptmElements.size(); i++) {
			ptmList.addPtmElement(acidList, (Element)ptmElements.get(i), isCompleteList);
		}
		stream.close();
		return ptmList;
	}
	
    public void addPtmElement(AcidList acidList, Element element, boolean isCompleteList) throws Exception {
    	String abbrName = element.getChildText("abbreviation");
		if (abbrName == null) {
			abbrName = "";
		}
		double monoMass = Double.parseDouble(element.getChildText("mono_mass"));
		boolean isEmpty = Boolean.parseBoolean(element.getChildText("is_empty"));
		String anywhere = null;
		List<?> residueList = element.getChildren("residues");
		for (int i = 0; i < residueList.size(); i++) {
			Element residueElement = (Element) residueList.get(i);
			String location = residueElement.getAttributeValue("location")
					.trim();
			if (location.equals("N-term")) {
				// nTerm = XmlTools.getNodeName(res_el);
			} else if (location.equals("C-term")) {
				// cTerm = XmlTools.getNodeName(res_el);
			} else if (location.equals("Anywhere")) {
				anywhere = residueElement.getText();
			}
		}
		Acid validAcids[] = acidList.convert(anywhere);
		if (isCompleteList) {
			Ptm ptm = new Ptm(abbrName, monoMass, validAcids, isEmpty);
			add(ptm);
		}
		else {
			Ptm ptm = PtmList.completeList.addPtm(abbrName, monoMass, validAcids, isEmpty);
			add(ptm);
		}
	}
    
    public Ptm addPtm(String abbrName, double monoMass, Acid validAcids[], boolean isEmpty) {
    	Ptm ptm = getPtmByAbbrName(abbrName);
    	if (ptm == null) {
    		ptm = new Ptm(abbrName, monoMass, validAcids, isEmpty);
    		add(ptm);
    	}
    	return ptm;
    }
}
