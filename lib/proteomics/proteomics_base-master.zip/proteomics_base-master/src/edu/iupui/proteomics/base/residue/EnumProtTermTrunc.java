/**
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.residue;

import edu.iupui.proteomics.base.seq.ResSeq;

public enum EnumProtTermTrunc {

	/** n terminal modification */

	NONE(0, ""), NME(1, "M");

	private int truncLen;
	private Acid[] acids;
	private double shift;

	EnumProtTermTrunc(int truncLen, String acidStr) {
		this.truncLen = truncLen;
		acids = new Acid[acidStr.length()];
		shift = 0;
		for (int i = 0; i < acids.length; i++) {
			acids[i] = AcidList.getCompleteAcidList().getAcidByOneLetter(
					acidStr.substring(i, i + 1));
			shift = shift - acids[i].getResidueMonoMass();
		}
	}

	/**
	 * Gets
	 */
	public int getTruncLen() {
		return truncLen;
	}
	
	public double getShift() {
		return shift;
	}

	public boolean isSameTrunc(int len, ResSeq resSeq) {
		if (truncLen != len) {
			return false;
		}
		for (int i = 0; i < truncLen; i++) {
			if (acids[i] != resSeq.getRes(i).getAcid()) {
				return false;
			}
		}
		return true;
	}
}
