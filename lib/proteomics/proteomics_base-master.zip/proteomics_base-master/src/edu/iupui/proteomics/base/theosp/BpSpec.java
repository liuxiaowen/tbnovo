package edu.iupui.proteomics.base.theosp;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Logger;


import edu.iupui.proteomics.base.ion.BreakPoint;
import edu.iupui.proteomics.base.ion.EnumActivation;
import edu.iupui.proteomics.base.ion.EnumIonType;
import edu.iupui.proteomics.base.seq.ResSeq;
import edu.iupui.proteomics.base.util.BioArray;


public class BpSpec  {
	
	private static Logger logger = Logger.getLogger(BpSpec.class);
	
	/* Residue sequence */
	ResSeq seq;
	/* extended break points */
	protected BreakPoint[] extBps;

	public BpSpec(ResSeq seq) {
		this.seq = seq;
		initBreakPoints();
	}

	private void initBreakPoints() {
		int extLen = seq.getLen() + 1;
		if (extLen <= 1) {
			extLen = 2;
		}
		extBps = new BreakPoint[extLen];
		extBps[0] = new BreakPoint(0, seq.getResMassSum());
		double prm = 0;
		for (int i = 0; i < seq.getLen() - 1; i++) {
			prm += seq.getRes(i).getMass();
			double srm = seq.getResMassSum() - prm;
			if (srm < 0) {
				logger.warn("prms is larger than total mass ");
			}
			extBps[i + 1] = new BreakPoint(prm, srm);
		}
		extBps[extLen - 1] = new BreakPoint(seq.getResMassSum(), 0);
	}

	/** Get residue sequence */
	public ResSeq getResSeq() {
		return seq;
	}

	/** Get the array of break points */
	public BreakPoint[] getExtBps() {
		return extBps;
	}
	
	/** Get the ith break point */
	public BreakPoint getExtBp(int i) {
		return extBps[i];
	}
	
	
	public double[] getExtBMasses() {
        double extBMasses[] = new double[extBps.length];
        for (int i = 0; i < extBps.length; i++) {
            extBMasses[i] = extBps[i].getBMass();
        }
        Arrays.sort(extBMasses);
		return extBMasses;
	}
	
	public double[] getExtYMasses() {
        double extYMasses[] = new double[extBps.length];
        for (int i= 0; i < extBps.length; i++) {
            extYMasses[i] = extBps[i].getYMass();
        }
        Arrays.sort(extYMasses);
		return extYMasses;
	}

    public double[] getExtCMasses() {
        double extCMasses[] = new double[extBps.length];
        for (int i= 0; i < extBps.length; i++) {
            extCMasses[i] = extBps[i].getCMass();
        }
        Arrays.sort(extCMasses);
		return extCMasses;
    }

    public double[] getExtZDotMasses() {
        double extZDotMasses[] = new double[extBps.length];
        for (int i= 0; i < extBps.length; i++) {
            extZDotMasses[i] = extBps[i].getZDotMass();
        }
        Arrays.sort(extZDotMasses);
		return extZDotMasses;
    }

	
	public double[] getExtBYMasses(double nTermShift, double cTermShift,
			double minMass) {
		ArrayList<Double> result = new ArrayList<Double>();
		result.add(0.0);
		double newSeqMass = getResSeq().getSeqMass() + nTermShift + cTermShift;
		// b
		for (int i = 0; i < extBps.length; i++) {
			double mass = extBps[i].getBMass() + nTermShift;
			addMass(mass, newSeqMass, minMass, result);
		}
		// y
		for (int i = 0; i < extBps.length; i++) {
			double mass = extBps[i].getYMass() + cTermShift;
			addMass(mass, newSeqMass, minMass, result);
		}
		result.add(newSeqMass);
		double masses[] = BioArray.cnvtDoubleList(result);
		Arrays.sort(masses);
		return masses;
	}

	public double[] getExtCZDotMasses(double nTermShift, double cTermShift,
			double minMass) {
		ArrayList<Double> result = new ArrayList<Double>();
		result.add(0.0);
		double newSeqMass = getResSeq().getSeqMass() + nTermShift + cTermShift;
		// c
		for (int i = 0; i < extBps.length; i++) {
			double mass = extBps[i].getCMass() + nTermShift;
			addMass(mass, newSeqMass, minMass, result);
		}
		// z
		for (int i = 0; i < extBps.length; i++) {
			double mass = extBps[i].getZDotMass() + cTermShift;
			addMass(mass, newSeqMass, minMass, result);
		}
		result.add(newSeqMass);
		double masses[] = BioArray.cnvtDoubleList(result);
		Arrays.sort(masses);
		return masses;
	}
	
	private void addMass(double mass, double seqMass, double minMass,
			ArrayList<Double> list) {
		if (mass >= minMass && mass <= seqMass - minMass) {
			list.add(mass);
		}
	}
	
	
	public int[] getScaledBMasses(double scale) {
		int[] scaledBMasses = new int[extBps.length];
		for (int i = 0; i < extBps.length; i++) {
			scaledBMasses[i] = (int) Math.round(extBps[i].getBMass() * scale);
		}
		return scaledBMasses;
	}

	public double[] getNTermMasses (EnumActivation type) {
		if (type.getNIonType() == EnumIonType.B) {
			return getExtBMasses();
		}
		else if (type.getNIonType() == EnumIonType.C) {
			return getExtCMasses();
		}
        return null;
	}
	
	public double[] getCTermMasses(EnumActivation type) {
		if (type.getCIonType()  == EnumIonType.Y) {
			return getExtYMasses();
		}
		else if (type.getCIonType() == EnumIonType.Z_DOT) {
			return getExtZDotMasses();
		}
        return null;
	}
}

///**
//* Returns a sub-peptide of the original peptide.
//* 
//* @param bgn
//*            The beginning position of the sub-peptide.
//* @param end
//*            The ending position of the sub-pepide.
//* @return A new Pep instance.
//*/
//public MsAlignSeq getSubResMassSeq(int bgn, int end) {
//	if (end - bgn < 0) {
//		return new MsAlignSeq(new ResSeq("", new Res[0]));
//	} else {
//		Res subResidues[] = new Res[end - bgn + 1];
//		for (int i = bgn; i <= end; i++) {
//			subResidues[i - bgn] = getResSeq().getRes(i);
//		}
//		return new MsAlignSeq(new ResSeq("", subResidues));
//	}
//}

//public boolean allowsNMod (EnumProtTermMod nMod) {
//Res residues[] = getResSeq().getResidues();
//if (nMod == EnumProtTermMod.NONE) {
//  return true;
//} else if (nMod == EnumProtTermMod.NME) {
//  if (residues.length >= 2
//          && residues[0].getAcid().getOneLetter().equals("M")) {
//      return true;
//  } else {
//      return false;
//  }
//
//} else if (nMod == EnumProtTermMod.ACETYLATION) {
//  return true;
//} else if (nMod == EnumProtTermMod.NME_ACETYLATION) {
//  if (residues.length >= 2
//          && residues[0].getAcid().getOneLetter().equals("M")) {
//      return true;
//  } else {
//      return false;
//  }
//}
//return false;
//}
