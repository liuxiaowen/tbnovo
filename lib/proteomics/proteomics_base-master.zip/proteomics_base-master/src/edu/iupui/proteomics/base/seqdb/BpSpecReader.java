/**
 * @author  Xiaowen Liu
 */

package edu.iupui.proteomics.base.seqdb;


import java.io.File;
import java.util.ArrayList;


import edu.iupui.proteomics.base.residue.EnumProtTermMod;
import edu.iupui.proteomics.base.residue.ResList;
import edu.iupui.proteomics.base.residue.ResListFactory;
import edu.iupui.proteomics.base.seq.ResSeq;
import edu.iupui.proteomics.base.theosp.BpSpec;
import edu.iupui.proteomics.base.theosp.NModBpSpec;
import edu.iupui.proteomics.base.theosp.NModBpSpecFactory;

public class BpSpecReader {

    /** initialize sequence list */
    public static BpSpec[] readDb(ResReader reader)
            throws Exception {
        ArrayList<BpSpec> bpSpecList = new ArrayList<BpSpec>();
        ResSeq resSeq;
        int id = 0;
        while ((resSeq = reader.getNextResSeq()) != null) {
            resSeq.setId(id);
            id++;
            bpSpecList.add(new BpSpec(resSeq));
        }
        BpSpec bpSpecs[] = bpSpecList.toArray(new BpSpec[0]);
        bpSpecList = null;
        reader = null;
        return bpSpecs;
    }

    public static BpSpec[] readFastaDb(String dbFileName, String resFileName)
            throws Exception {
    	File dbFile = new File(dbFileName);
        ResList resList = ResListFactory.getSystemInstance(resFileName);
        ResReader reader = new ResReader(dbFile, resList);
        return BpSpecReader.readDb(reader);
    }
    

    public static NModBpSpec[] getNModBpSpecs(String dbFileName, String resFileName,
            EnumProtTermMod allowProtNTermMods[]) throws Exception {
        File dbFile = new File(dbFileName);
        ResList resList = ResListFactory.getSystemInstance(resFileName);
        BpSpec bpSpecs[] = BpSpecReader.readDb(new ResReader(dbFile, resList));
        return NModBpSpecFactory.getInstances(bpSpecs, allowProtNTermMods);
    }
}
