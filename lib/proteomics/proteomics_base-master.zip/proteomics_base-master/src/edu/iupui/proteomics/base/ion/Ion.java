/**
 * Describes a fragment ion.
 * 
 * @author Xiaowen Liu
 * @date 2009-8-26
 */

package edu.iupui.proteomics.base.ion;


public class Ion {
	protected EnumIonType ionType;
	protected EnumNeutralLoss neutralLoss;

	/** charge state */
	protected int charge;
	/** breakage_position from left to right 0, 1, ... */
	protected int pos;
	/** breakage name_position */
	protected int displayPos;

	/**
	 * Constructs an instance with all member variables.
	 */
	public Ion(EnumIonType type, EnumNeutralLoss neutralLoss, int chrg,
			int pos, int displayPos) {
		this.ionType = type;
		this.neutralLoss = neutralLoss;
		this.charge = chrg;
		this.pos = pos;
		this.displayPos = displayPos;
	}

	/**
	 * Gets
	 */
	public EnumIonType getIonType() {
		return ionType;
	}

	public String getDisplayName() {
		return ionType.getName() + displayPos;
	}

	public int getPos() {
		return pos;
	}
	
	public int getDisplayPos() {
	    return displayPos;
	}
	
	public int getCharge() {
	    return charge;
	}
}
