package edu.iupui.proteomics.base.ion;

import org.apache.log4j.Logger;


public class BreakPoint {
	
	private static Logger logger = Logger.getLogger(BreakPoint.class);

	private double prm;
	private double srm;

	public BreakPoint(double prm, double srm) {
		this.prm = prm;
		this.srm = srm;
	}

	public double getBMass() {
		return prm;
	}

	public double getCMass() {
		return prm + EnumIonType.C.getShift();
	}

	public double getPrm() {
		return prm;
	}

	public double getSrm() {
		return srm;
	}

	public double getYMass() {
		return srm + EnumIonType.Y.getShift();
	}
	
	public double getZDotMass() {
		return srm + EnumIonType.Z_DOT.getShift();
	}
	
	public double getNTermMass(EnumActivation type) {
		if (type.getNIonType() == EnumIonType.B) {
			return getBMass();
		}
		else if (type.getNIonType() == EnumIonType.C) {
			return getCMass();
		}
		else {
			logger.warn("Incorrect spectral activation type");
		}
        return -1;
	}
	
	public double getCTermMass(EnumActivation type) {
		if (type.getCIonType()  == EnumIonType.Y) {
			return getYMass();
		}
		else if (type.getCIonType() == EnumIonType.Z_DOT) {
			return getZDotMass();
		}
		else {
			logger.warn("Incorrect spectral activation type");
		}
        return -1;
		
	}
}
