/**
 * The class factory for amino acid sequence.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.seqdb;

import org.apache.log4j.Logger;

public class FastaPreprocess {
    private static Logger logger = Logger.getLogger(FastaPreprocess.class);

    /** Process the string */
    public static String[] process(String name, String seq) {
        String newSeq = rmChar(seq);
        if (!newSeq.equals(seq)) {
            logger.info("Reading sequence. Unknown letter occurred. " + seq);
        }
        String[] result = new String[2];
        result[0] = name;
        result[1] = newSeq;
        return result;
    }

    /** process fasta string and remove unknown letters */
    public static String rmChar(String str) {
        String seq = "";
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c < 'A' || c > 'Z') {
                continue;
            }
            char r = c;
            if (c == 'B') {
                r = 'D';
            } else if (c == 'Z') {
                r = 'E';
            } else if (c == 'X') {
                r = 'A';
            }
            seq = seq + r;
        }
        return seq;
    }

}
