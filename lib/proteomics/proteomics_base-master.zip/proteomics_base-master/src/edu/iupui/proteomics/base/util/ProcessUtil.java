package edu.iupui.proteomics.base.util;

public class ProcessUtil {
	public static String updateMsg(String str, String scan, int nSpectra,
			int nProcessed, long startTime) {
		String percentage = Integer.toString(nProcessed * 100 / nSpectra);
		String msg = "\r" + str + ": Processing spectrum scan " + scan + "...";
		while (msg.length() < 40) {
			msg += " ";
		}
		msg = msg + percentage + "% finished";
		int min = (int) (System.currentTimeMillis() - startTime) / 60000;
		msg = msg + " (" + min + " minutes used).";
		return msg;
	}
}
