package edu.iupui.proteomics.base.residue;

import java.io.InputStream;


public class ResMng {
	public  static String configDir = "config/";
	private static String acidFileName = "acid.xml";
	private static String ptmFileName = "ptm.xml";
	private static String resFileName = "residue.xml";
	
	/**
	 * Generate an input stream to run an xml file containing acid information.
	 */
	public static InputStream getAcidXmlStream() {
		InputStream stream = new ResMng().getClass()
				.getResourceAsStream(configDir + acidFileName);
		return stream;
	}
	
	/**
	 * Generate an input stream to run an xml file containing ptm information.
	 */
	public static InputStream getDefinedPtmXmlStream() {
		InputStream stream = new ResMng().getClass()
				.getResourceAsStream(configDir + ptmFileName);
		return stream;
	}
	
	/**
	 * Generate an input stream to run an xml file containing residue information.
	 */
	public static InputStream getDefinedResXmlStream() {
		InputStream stream = new ResMng().getClass()
				.getResourceAsStream(configDir + resFileName);
		return stream;
	}
}
