package edu.iupui.proteomics.base.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.StringWriter;

public class BioIo {

    public static int getLineNum(String listName) {
        int cnt = 0;
        try {
            BufferedReader input = new BufferedReader(new FileReader(listName));

            while (input.readLine() != null) {
                cnt++;
            }
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        return cnt;
    }

    public static String getBaseName(String oriName) {
        int bgnIdx = 0;
        if (oriName.lastIndexOf("/") >= 0) {
            bgnIdx = oriName.lastIndexOf("/") + 1;
        }
        if (oriName.lastIndexOf("\\") >= 0) {
            bgnIdx = oriName.lastIndexOf("\\") + 1;
        }
        int endIdx = oriName.length();
        if (oriName.lastIndexOf(".") >= 0) {
            endIdx = oriName.lastIndexOf(".");
        }
        return oriName.substring(bgnIdx, endIdx);
    }

    public static void printArray(PrintWriter out, float[] nums)
            throws Exception {
        if (nums.length > 0) {
            out.print(nums[0]);
            for (int i = 1; i < nums.length; i++) {
                out.print("\t" + nums[i]);
            }
        }
        out.println();
    }

    public static String getStackTraceAsString(Exception exception) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.print("[ ");
        pw.print(exception.getClass().getName());
        pw.print(" ] ");
        pw.print(exception.getMessage());
        exception.printStackTrace(pw);
        return sw.toString();
    }
    
    public static String getStackTraceAsString(Error exception) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.print("[ ");
        pw.print(exception.getClass().getName());
        pw.print(" ] ");
        pw.print(exception.getMessage());
        exception.printStackTrace(pw);
        return sw.toString();
    }
    
    public static void printLongerTrace(Throwable t){
        for(StackTraceElement e: t.getStackTrace())
            System.out.println(e);
    }
}
