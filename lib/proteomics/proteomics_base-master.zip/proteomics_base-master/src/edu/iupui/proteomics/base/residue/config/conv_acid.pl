#!/usr/bin/perl 
open(f, $ARGV[0]);
my @line = <f>;

print "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n"; 
print "<amino_acid_list>\n";
for ($i = 0; $i < @line; $i++) {
    $line[$i] =~ s/\n//;
    @word = split(/\t/, $line[$i]);
    print "<amino_acid>\n";
    print "\t<name>". $word[0] . "</name>\n";
    print "\t<one_letter>". $word[1] . "</one_letter>\n";
    print "\t<three_letter>". $word[2] . "</three_letter>\n";
    print "\t<composition>". $word[3] . "</composition>\n";
    print "\t<mono_mass>". $word[4] . "</mono_mass>\n";
    print "\t<average_mass>". $word[5] . "</average_mass>\n";
    print "\t<frequency>". $word[6] . "</frequency>\n";
    print "</amino_acid>\n";
}
print "</amino_acid_list>\n";
