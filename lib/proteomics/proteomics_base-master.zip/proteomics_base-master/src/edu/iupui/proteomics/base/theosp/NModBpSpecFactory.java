package edu.iupui.proteomics.base.theosp;

import java.util.ArrayList;
import java.util.Arrays;


import edu.iupui.proteomics.base.residue.EnumProtTermMod;
import edu.iupui.proteomics.base.residue.Ptm;
import edu.iupui.proteomics.base.residue.PtmList;
import edu.iupui.proteomics.base.residue.Res;
import edu.iupui.proteomics.base.residue.ResList;
import edu.iupui.proteomics.base.seq.ResSeq;


public class NModBpSpecFactory {

    public static NModBpSpec getInstance(BpSpec bpSpec, EnumProtTermMod nMod) throws Exception {

    	Ptm acetylation = PtmList.getCompletePtmList().getPtmByAbbrName("Acetylation");
    	ResSeq resSeq = bpSpec.getResSeq();
        if (!resSeq.allowsMod(nMod)) {
            return null;
        }
        String name = bpSpec.getResSeq().getName();
        Res residues[] = bpSpec.getResSeq().getResidues();

        if (nMod == EnumProtTermMod.NONE) {
            return new NModBpSpec(name, residues, bpSpec, nMod);
        } else if (nMod == EnumProtTermMod.NME) {
            Res modRes[] = Arrays.copyOfRange(residues, 1, residues.length);
            return new NModBpSpec(name, modRes, bpSpec, nMod);
        } else if (nMod == EnumProtTermMod.ACETYLATION) {
            Res modRes[] = Arrays.copyOfRange(residues, 0, residues.length);
            modRes[0] = ResList.addToCompleteList(modRes[0].getAcid(), acetylation);
            return new NModBpSpec(name, modRes, bpSpec, nMod);
        } else if (nMod == EnumProtTermMod.NME_ACETYLATION) {
            Res modRes[] = Arrays.copyOfRange(residues, 1, residues.length);
            modRes[0] = ResList.addToCompleteList(modRes[0].getAcid(), acetylation);
            return new NModBpSpec(name, modRes, bpSpec, nMod);
        }
        return null;
    }

    public static NModBpSpec[] getInstances(BpSpec seq[],
            EnumProtTermMod nMods[]) throws Exception {
        ArrayList<NModBpSpec> nModSeqList = new ArrayList<NModBpSpec>();
        for (int i = 0; i < seq.length; i++) {
            for (int j = 0; j < nMods.length; j++) {
                NModBpSpec nModSeq = getInstance(seq[i], nMods[j]);
                if (nModSeq != null) {
                    nModSeqList.add(nModSeq);
                }
            }
        }
        return nModSeqList.toArray(new NModBpSpec[0]);
    }
}
