package edu.iupui.proteomics.base.ion;

import java.util.HashMap;
import java.util.Map;


public enum EnumActivation {
	CID("CID", 0, 0, EnumIonType.B, EnumIonType.Y),
    HCD("HCD", 0, 0, EnumIonType.B, EnumIonType.Y),
	ETD("ETD", EnumIonType.C.getShift() - EnumIonType.B.getShift(), EnumIonType.Z_DOT.getShift() - EnumIonType.Y.getShift(), EnumIonType.C, EnumIonType.Z_DOT);
	/** static map initialization */
	public static Map<String, EnumActivation> names = new HashMap<String, EnumActivation>();

	static {
		for (EnumActivation type : EnumActivation.values()) {
			names.put(type.getName(), type);
		}
	}

	/** Get Activation type */
	public static EnumActivation getActivationType(String name) {
		return names.get(name);
	}

	private String name;
	private double nShift;
	private double cShift;
    private EnumIonType nIonType;
    private EnumIonType cIonType;

	EnumActivation(String name, double nShift, double cShift, EnumIonType nIonType, EnumIonType cIonType) {
		this.name = name;
		this.nShift = nShift;
		this.cShift = cShift;
        this.nIonType = nIonType;
        this.cIonType = cIonType;
	}

	/**
	 * Gets
	 */
	public String getName() {
		return name;
	}
	
	public double getNShift() {
		return nShift;
	}

	public double getCShift() {
		return cShift;
	}

    public EnumIonType getNIonType() {
        return nIonType;
    }

    public EnumIonType getCIonType() {
        return cIonType;
    }

}
