/**
 * Several string utilities related to residue operation.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.util;

import java.util.ArrayList;

public class StrUtil {
	/**
	 * Breaks a residue string into an array of residue strings. For example,
	 * break "C(CamC)AB" to "C(CamC)", "A" and "B".
	 */
	public static String[] brkStr(String s, char delimBgn, char delimEnd) {
		ArrayList<String> strList = new ArrayList<String>();
		int bgn = 0;
		int end = 0;
		while (end < s.length()) {
			if (end == s.length() - 1 || s.charAt(end + 1) != delimBgn) {
				end++;
				strList.add(s.substring(bgn, end));
				bgn = end;
			} else {
				while (s.charAt(end) != delimEnd) {
					end++;
				}
				end++;
				strList.add(s.substring(bgn, end));
				bgn = end;
			}
		}
		return strList.toArray(new String[0]);
	}

	/**
	 * Breaks a residue name, for example "C(CamC)", into two parts "C" and
	 * "CamC". The first part is acid name, and the second part is the ptm
	 * abbreviation name.
	 * 
	 * @param resName
	 *            The name of the residue.
	 * @return name[0] is the acid name and name[1] is the ptm abbreviation
	 *         name.
	 */

	public static String[] brkAcidPtm(String resName) {
		String[] names = new String[2];
		if (resName.length() == 1) {
			names[0] = resName;
			names[1] = "";
		} else {
			names[0] = resName.substring(0, 1);
			names[1] = resName.substring(2, resName.length() - 1);
		}
		return names;
	}
	
	public static String[] trypticDigestion(String s) {
        ArrayList<String> pepList = new ArrayList<String>();
        String peptide = "";
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            peptide = peptide + c;
            if (c == 'R' || c== 'K') {
                pepList.add(peptide);
                peptide = "";
            }
        }
        return pepList.toArray(new String[0]);
	}

}
