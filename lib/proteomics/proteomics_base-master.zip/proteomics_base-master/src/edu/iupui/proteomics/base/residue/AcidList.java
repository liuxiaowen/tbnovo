/**
 * Class for a list of amino acids.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-25
 * @version 1.0
 */

package edu.iupui.proteomics.base.residue;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

public class AcidList extends ArrayList<Acid>  {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(AcidList.class);

	/** Complete amino acid list */
	private static AcidList completeList;
	static {
		try {
			completeList = getInstance();
		}
		catch (Exception ex) {
			System.err.println("Error in initializing the complete acid list");
			System.exit(1);
		}
	}

	/**
	 * Checks if the list contains an amino acid with the specific name.
	 */
	public boolean containsName(String name) {
		return getAcidByName(name) != null;
	}

	/**
	 * Checks if the list contains an amino acid with the specific one letter
	 * representation.
	 */
	public boolean containsOneLetter(String oneLetter) {
		return getAcidByOneLetter(oneLetter) != null;
	}

	/**
	 * Checks if the list contains an amino acid with the specific three letter
	 * representation.
	 */
	public boolean containsThreeLetter(String threeLetter) {
		return getAcidByThreeLetter(threeLetter) != null;
	}

	/**
	 * Converts a protein sequence (with one letter representation of amino
	 * acids) to an amino acid array.
	 */
	public Acid[] convert(String string) {
		if (string == null) {
			return new Acid[0];
		} else {
			Acid acids[] = new Acid[string.length()];
			for (int i = 0; i < string.length(); i++) {
				acids[i] = getAcidByOneLetter(string.substring(i, i + 1));
			}
			return acids;
		}
	}
	
	/**
	 * Returns an amino acid based on the the name. Returns null if the amino
	 * acid name does not exist.
	 */
	public Acid getAcidByName(String name) {
		for (int i = 0; i < size(); i++) {
			String n = get(i).getName();
			if (n.equals(name)) {
				return get(i);
			}
		}
		return null;
	}

	/**
	 * Returns an amino acid based on the one letter representation. Returns
	 * null if the one letter representation does not exist.
	 */
	public Acid getAcidByOneLetter(String oneLetter) {
		for (int i = 0; i < size(); i++) {
			String l = get(i).getOneLetter();
			if (l.equals(oneLetter)) {
				return get(i);
			}
		}
		logger.debug("Acid not found " + oneLetter);
		return null;
	}

	/**
	 * Returns an amino acid based on the three letter representation. Returns
	 * null if the three letter representation does not exist.
	 */
	public Acid getAcidByThreeLetter(String threeLetter) {
		for (int i = 0; i < size(); i++) {
			String l = get(i).getThreeLetter();
			if (l.equals(threeLetter)) {
				return get(i);
			}
		}
		return null;
	}
	
	public static AcidList getCompleteAcidList() {
		return completeList;
	}
	
	/**
	 * Returns an AcidList instance with 22 amino acids.
	 */
	private static AcidList getInstance() throws Exception {
		// get the factory
		InputStream stream = ResMng.getAcidXmlStream();
		SAXBuilder builder = new SAXBuilder();
		Document doc = builder.build(stream);
		Element root = doc.getRootElement();
		List<?> acidElements = root.getChildren();
		AcidList acidList = new AcidList();
		for (int i = 0; i < acidElements.size(); i++) {
			acidList.add(new Acid((Element)acidElements.get(i)));
		}
		stream.close();
		return acidList;
	}
}
