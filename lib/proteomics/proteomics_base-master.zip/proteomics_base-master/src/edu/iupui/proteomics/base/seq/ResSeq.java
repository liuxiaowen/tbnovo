/**
 * A residue sequence.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.seq;


import edu.iupui.proteomics.base.residue.EnumProtTermMod;
import edu.iupui.proteomics.base.residue.MassConstant;
import edu.iupui.proteomics.base.residue.Res;
import edu.iupui.proteomics.base.residue.ResArrayUtil;
import edu.iupui.proteomics.base.util.ArrayUtil;


public class ResSeq {
	/** id of the sequence */
	private int id;
	/** sequence name */
	private String name;
	/** residue list */
	private Res[] residues;
	/** the sum of residue mass */
	private double resMassSum;

	public ResSeq(String name, Res[] residues) {
		this.name = name;
		this.residues = residues;
		/* get residue mass sum */
		resMassSum = ArrayUtil.getSum(ResArrayUtil.getMasses(residues));
	}

	/**
	 * Constructs an empty ResSeq instance with length 0 (not NULL).
	 */
	public static ResSeq getEmptyResSeq() {
		return new ResSeq("", new Res[0]);
	}

	/**
	 * Returns a sub-peptide of the original peptide.
	 * 
	 * @param bgn
	 *            The beginning position of the sub-peptide.
	 * @param end
	 *            The ending position of the sub-pepide.
	 * @return A new Pep instance.
	 */
	public ResSeq getSubResSeq(int bgn, int end) {
		if (end - bgn < 0) {
			return getEmptyResSeq();
		} else {
			Res subResidues[] = new Res[end - bgn + 1];
			for (int i = bgn; i <= end; i++) {
				subResidues[i - bgn] = residues[i];
			}
			return new ResSeq("", subResidues);
		}
	}

	/**
	 * Checks if this peptide has the same mass array to another peptide. I and L
	 * are treated as same mass pair.
	 */
	public boolean isSameMassArray(ResSeq seq) {
		if (residues.length != seq.residues.length) {
			return false;
		}
		for (int i = 0; i < residues.length; i++) {
			if (residues[i].getMass() != seq.residues[i].getMass()) {
				return false;
			}
		}
		return true;
	}

	/** Gets the acid string of the peptide, wrapper of ResArrayUtil.getAcidString */
	public String getAcidString() {
		return ResArrayUtil.getAcidString(residues);
	}
	
	/** Gets Id */
	public int getId () {
		return id;
	}

	/** Gets length */
	public int getLen() {
		return residues.length;
	}

	/** Gets sequences */
	public String getName() {
		return name;
	}

	/** Gets residue at position i */
	public Res getRes(int i) {
		return residues[i];
	}
	
	/** Gets all residues */
	public Res[] getResidues() {
	    return residues;
	}
	
	/** Gets a residue string of the sequence, wrapper of ResArrayUtil.toString */
	public String getResString() {
		return ResArrayUtil.toString(residues, '[', ']');
	}

	/** Gets a residue string of the sequence with specific delmiters */ 
	public String getResString(char delimBgn, char delimEnd) {
		return ResArrayUtil.toString(residues, delimBgn, delimEnd);
	}

	/** Gets sequence molecular mass */
	public double getSeqMass() {
		return resMassSum + MassConstant.getWaterMass();
	}

	/** Gets the sum of residue masses */
	public double getResMassSum() {
		return resMassSum;
	}

	/** Checks if the first residue is methionine */
	public boolean isFirstMet() {
		if (residues.length > 0
				&& residues[0].getAcid().getOneLetter().equals("M")) {
			return true;
		} else {
			return false;
		}
	}
	
	/** Sets id */
	public void setId (int id) {
		this.id = id;
	}
	
	public boolean allowsMod(EnumProtTermMod mod) {
		Res residues[] = getResidues();
		if (mod == EnumProtTermMod.NONE) {
			return true;
		} else if (mod == EnumProtTermMod.NME) {
			if (residues.length >= 2
					&& residues[0].getAcid().getOneLetter().equals("M")) {
				return true;
			} else {
				return false;
			}

		} else if (mod == EnumProtTermMod.ACETYLATION) {
			return true;
		} else if (mod == EnumProtTermMod.NME_ACETYLATION) {
			if (residues.length >= 2
					&& residues[0].getAcid().getOneLetter().equals("M")) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
}

