/**
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.residue;

public enum EnumProtTermMod {

    /** n terminal modification */

    NONE(0, EnumProtTermTrunc.NONE, "No PTM"),
        ACETYLATION(1, EnumProtTermTrunc.NONE, "Acetylation"),
        NME(2, EnumProtTermTrunc.NME, "No PTM"),
        NME_ACETYLATION(3, EnumProtTermTrunc.NME, "Acetylation");
 
    private int code;
    private EnumProtTermTrunc trunc;
    private Ptm ptm;
    private double protShift;
    private double pepShift;

    EnumProtTermMod(int code, EnumProtTermTrunc trunc, String ptmAbbrName) {
        this.code = code;
        this.trunc = trunc;
        this.ptm = PtmList.getCompletePtmList().getPtmByAbbrName(ptmAbbrName);
        this.protShift = ptm.getMonoMass() + trunc.getShift();
        this.pepShift = ptm.getMonoMass();
    }

    /**
     * Gets 
     */
    public int getCode() {
    	return code;
    }
    
    public EnumProtTermTrunc getTrunc() {
    	return trunc;
    }
    
    public double getProtTermShift() {
        return protShift;
    }
    
    public double getPepTermShift() {
    	return pepShift;
    }
}
