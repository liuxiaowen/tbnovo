package edu.iupui.proteomics.base.seqdb;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

public class FastaFilter {
	
    public static void main(String[] args) throws Exception {
    	FastaSeqReader reader = new FastaSeqReader(new File(args[0]));

    	ArrayList<String[]> proteins = new ArrayList<String[]>();
    	String info[];
    	while ((info = reader.getNextSeq()) != null) {
    		proteins.add(info);
    	}

    	int count = 0;
    	for (int i = 0; i < proteins.size(); i++) {

    		if (proteins.get(i)[1].length() >= 200 && proteins.get(i)[1].length() <=300) {
    			count++;
            	PrintWriter writer = new PrintWriter(args[1] + count);
    			writer.println(">" + proteins.get(i)[0]);
    			writer.println(proteins.get(i)[1]);
    	    	writer.close();
    		}
    	}


    }

}
