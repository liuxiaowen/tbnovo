/**
 * Implements several utility functions for peptide array operation.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.seq;

import java.util.ArrayList;

import edu.iupui.proteomics.base.residue.Res;


public class ResSeqArrayUtil {
    /**
     * Returns compute the sum of mass values of several peptides.
     * 
     * @param peptides
     *            An Pep array.
     * 
     * @param bgn
     *            The beginning position of the pep array.
     * 
     * @param end
     *            The ending position of the pep array.
     * 
     * @return The sum of the peptides from pep_list[bgn] to pep_list[end].
     */
    public static double compResSeqArrayMass(ResSeq[] peptides, int bgn, int end) {
        double massSum = 0;
        for (int i = bgn; i <= end; i++) {
            massSum += peptides[i].getSeqMass();
        }
        return massSum;
    }

    /**
     * Returns compute the sum of lengths of several peptides.
     * 
     * @param peptides
     *            An Pep array.
     * 
     * @param bgn
     *            The beginning position of the pep array.
     * 
     * @param end
     *            The ending position of the pep array.
     * 
     * @return The sum of the lengths from pep_list[bgn] to pep_list[end].
     */
    public static int compResSeqArrayLen(ResSeq[] peptides, int bgn, int end) {

        int lenSum = 0;
        for (int i = bgn; i <= end; i++) {
            lenSum += peptides[i].getLen();
        }
        return lenSum;
    }

    /**
     * Returns the concatenation of several peptides.
     * 
     * @param peptides
     *            An Pep array.
     * 
     * @param bgn
     *            The beginning position of the pep array.
     * 
     * @param end
     *            The ending position of the pep array.
     * 
     * @return The concatenation of several peptides.
     */
    public static Res[] getConnResSeqArray(ResSeq[] peptides, int bgn, int end) {

        int lenSum = compResSeqArrayLen(peptides, bgn, end);
        Res connResidues[] = new Res[lenSum];
        int p = 0;
        for (int i = bgn; i <= end; i++) {
            for (int j = 0; j < peptides[i].getLen(); j++) {
                connResidues[p] = peptides[i].getRes(j);
                p++;
            }
        }
        return connResidues;
    }

    /**
     * Checks if a peptide string is in a Peptide list.
     * 
     * @param peptides
     *            A Peptide list.
     * 
     * @param pepStr
     *            A peptide string.
     * 
     * @return Return true if the pep list contains the pep str. Otherwise,
     *         false.
     */
    public static boolean contains(ArrayList<ResSeq> peptides, String pepStr) {

        for (int i = 0; i < peptides.size(); i++) {
            if (peptides.get(i).getResString().equals(pepStr)) {
                return true;
            }
        }
        return false;
    }
}
