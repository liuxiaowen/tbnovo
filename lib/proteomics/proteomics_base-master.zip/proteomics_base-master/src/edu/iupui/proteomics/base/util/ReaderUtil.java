package edu.iupui.proteomics.base.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

public class ReaderUtil {
    public static Properties readPropertiesUntil(BufferedReader result, String sign) throws IOException {
        String s;
        Properties ans = new Properties();
        while ((s = result.readLine())!= null) {
            int equalIndex = s.indexOf("=");
            if (equalIndex > 0) {
                ans.put(s.substring(0, equalIndex).trim(), s.substring(equalIndex + 1).trim());
            }
            if (s.startsWith(sign))
                break;
        }
        return ans;
    }

    public static List<String[]> readDataUntil(BufferedReader result, String sign) throws IOException {
        String s;
        List<String[]> ans = new ArrayList<String[]>();
        while (!(s = result.readLine()).equalsIgnoreCase(sign)) {
            ans.add(getDataArray(s));
        }
        return ans;
    }

    public static String[] getDataArray(String s) {
        return s.split("[ \t]");
    }

    public static String getValue(Properties prop, String key) {
        return prop.getProperty(key);
    }

    public static int getIntValue(Properties prop, String key) {
        String value = prop.getProperty(key).trim();
        StringTokenizer st = new StringTokenizer(value);
        return Integer.parseInt(st.nextToken());
    }

    public static double getDoubleValue(Properties prop, String key) {
        //System.out.println("prop " + prop);
        String value = prop.getProperty(key).trim();
        StringTokenizer st = new StringTokenizer(value);
        return Double.parseDouble(st.nextToken());
    }


    public static boolean getBooleanValue(Properties prop, String key) {
        return "true".equalsIgnoreCase(prop.getProperty(key));
    }
    
    public static Properties getProperties(String lines[]) throws IOException {
        Properties properties = new Properties();
        for (String line : lines) {
            int equalIndex = line.indexOf("=");
            if (equalIndex > 0) {
                properties.put(line.substring(0, equalIndex).trim(), line.substring(equalIndex + 1).trim());
            }
        }
        return properties;
    }
    
    public static String[] getPeakLines(String lines[]) throws IOException {
        ArrayList<String> peakLines = new ArrayList<String>();
        for (String line : lines) {
            if (Character.isDigit(line.charAt(0))) {
                peakLines.add(line);
            }
        }
        return peakLines.toArray(new String[0]);
    }
}
