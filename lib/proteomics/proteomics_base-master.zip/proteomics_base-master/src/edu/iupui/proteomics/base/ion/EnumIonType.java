/**
 * Describes a fragment ion.
 * 
 * @author Xiaowen Liu
 * @date 2009-8-26
 */

package edu.iupui.proteomics.base.ion;

import java.util.HashMap;
import java.util.Map;

public enum EnumIonType {

	B("B", true, 0), 
	Y("Y", false, 18.0106),
	C("C", true, 17.0265), 
	Z_DOT("Z_DOT", false, 1.9919),
	PREC("PREC", false, 18.0106);

	/** static map initialization */
	public static Map<String, EnumIonType> names = new HashMap<String, EnumIonType>();

	static {
		for (EnumIonType ionType : EnumIonType.values()) {
			names.put(ionType.getName(), ionType);
		}
	}

	/** Gets IonType by name */
	public static EnumIonType getIonTypeByName(String name) {
		return names.get(name);
	}

	/** ion name */
	private String name;
	/** A B C are n-terminal ions and X Y Z are non-n-terminal ions */
	private boolean nTerminal;
	/**
	 * Shift stands for the shift of the ion compared to M. For example, the
	 * shift for B ion is 0, and the shift for Y ion is 18 (chrg 0);
	 */
	private double shift;

	EnumIonType(String name, boolean nTerminal, double shift) {
		this.name = name;
		this.nTerminal = nTerminal;
		this.shift = shift;
	}

	/**
	 * Gets
	 */
	public String getName() {
		return name;
	}

	public boolean isNTerm() {
		return nTerminal;
	}

	public double getShift() {
		return shift;
	}

}
