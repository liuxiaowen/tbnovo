package edu.iupui.proteomics.base.theosp;


import edu.iupui.proteomics.base.residue.EnumProtTermMod;
import edu.iupui.proteomics.base.residue.Res;
import edu.iupui.proteomics.base.seq.ResSeq;


/** This class is only used for non-ptm search */
public class NModBpSpec extends BpSpec {
    BpSpec unModBpSpec;
    EnumProtTermMod nMod;

    public NModBpSpec(String name, Res residues[], BpSpec unModBpSpec,
            EnumProtTermMod nMod) throws Exception {
        super(new ResSeq(name, residues));
        this.unModBpSpec = unModBpSpec;
        this.nMod = nMod;
    }
    
    public BpSpec getUnModBpSpec () {
        return unModBpSpec;
    }
    
    public EnumProtTermMod getNMod () {
        return nMod;
    }
}
