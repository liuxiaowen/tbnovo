/**
 * Implements several common functions for a residue array.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.residue;

public class ResArrayUtil {
	
	/**
	 * Gets an acid array from a residue array. 
	 */
	public static Acid[] getAcidArray(Res[] residues) {
	    Acid acids[] = new Acid[residues.length];
	    for (int i = 0; i < residues.length; i++) {
	        acids[i] = residues[i].getAcid();
	    }
	    return acids;
	}
	/**
	 * Gets an acid string from a residue array. 
	 */
	public static String getAcidString(Res[] residues) {
		String result = "";
		for (int i = 0; i < residues.length; i++) {
			result += residues[i].getAcid().getOneLetter();
		}
		return result;
	}
	


	/** Gets a mass array from a residue array. */
	public static double[] getMasses(Res residues[]) {
		double residueMasses[] = new double[residues.length];
		for (int i = 0; i < residues.length; i++) {
			residueMasses[i] = residues[i].getMass();
		}
		return residueMasses;
	}
	
	/**
	 * Gets a residue array from an acid array.
	 */
	public static Res[] getResArrayByAcid(ResList resList, Acid[] acids) {
		Res[] residues = new Res[acids.length];
		for (int i = 0; i < acids.length; i++) {
			residues[i] = resList.getResByAcid(acids[i]);
		}
		return residues;
	}
		
	/**
	 * Gets a string from a residue array.
	 */
	public static String toString(Res[] residues, char delimBgn, char delimEnd) {
		String s = "";
		for (int i = 0; i < residues.length; i++) {
			s += residues[i].toString(delimBgn, delimEnd);
		}
		return s;
	}	
}
