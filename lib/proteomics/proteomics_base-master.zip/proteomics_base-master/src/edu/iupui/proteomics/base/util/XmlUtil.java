package edu.iupui.proteomics.base.util;

import org.jdom.Element;
import org.jdom.Document;
import org.jdom.input.SAXBuilder;

import java.text.DecimalFormatSymbols;
import java.text.DecimalFormat;
import java.util.Set;
import java.io.InputStream;

public class XmlUtil {

    public static Document getDocument(InputStream stream) throws Exception {
        SAXBuilder builder = new SAXBuilder();
        return builder.build(stream); 
    }

    public static Element addElement(Element element, String tag) {
        element.addContent(new Element(tag));
        return element;
    }

    public static Element addElement(Element element, String tag, String value) {
        element.addContent(new Element(tag).addContent(value));
        return element;
    }

    public static Element addElement(Element element, String tag, char value) {
        element.addContent(new Element(tag).addContent(Character.toString(value)));
        return element;
    }

    public static Element addElement(Element element, String tag, int value) {
        return  addElement(element, tag, Integer.toString(value));
    }

    public static Element addElement(Element element, String tag, boolean value) {
        return  addElement(element, tag, Boolean.toString(value));
    }
    
    public static Element addElement(Element element, String tag, double value) {
        return  addElement(element, tag, Double.toString(value));
    }


    public static Element addFormatElement(Element element, String tag, double value) {
        DecimalFormat formatter = new DecimalFormat("#.####");
        DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();
        decimalFormatSymbols.setDecimalSeparator('.');
        formatter.setDecimalFormatSymbols(decimalFormatSymbols);
        return  addElement(element, tag, formatter.format(value));
    }

    public static void addTags(Element prsm, Set<String> tags) {
        for (String tag : tags) {
            Element tagElement = new Element("tag");
            addElement(tagElement, "value", tag);
            prsm.addContent(tagElement);
        }
    }
}
