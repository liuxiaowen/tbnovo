/**
 * Common mass values in mass spectrometry.
 * 
 * @author Xiaowen Liu
 * @date 2009-8-26
 */

package edu.iupui.proteomics.base.residue;

public class MassConstant {

	/**
	 * Returns the mass of an ammonia (NH3).
	 */
	public static double getAmmoniaMass() {
		return 17.0265;
	}
	
	/**
	 * Returns the mass difference between two isotopic peaks.
	 */
	public static double getIsotopeMass() {
		/* from Thrash paper */
		return 1.00235;
	}

	/**
	 * Returns the mass of an oxygen molecular.
	 */
	public static double getOxygenMass() {
		return 15.9949;
	}

	/**
	 * Returns the mass of a proton. 
	 */
	public static double getProtonMass() {
		return 1.007276;
	}

	/**
	 * Returns the mass of a water molecule (H2O).
	 */
	public static double getWaterMass() {
		return 18.010565;
	}
}
