/**
 * Class for amino acid residues.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-25
 * @version 1.0
 */

package edu.iupui.proteomics.base.residue;

import org.jdom.Element;

public class Acid {
	/** Name of amino acid */
	private String name;
	/** One letter representation */
	private String oneLetter;
	/** Three letter representation */
	private String threeLetter;
	/** amino acid chemical composition */
	private String acidComposition;
	/** residue monoisotopic mass */
	private double residueMonoMass;
	/** Residue average mass */
	private double residueAvgMass;
	private double freq;

	public Acid(Element element) throws Exception {
		name = element.getChildText("name");
		oneLetter = element.getChildText("one_letter");
		threeLetter = element.getChildText("three_letter");
		acidComposition = element.getChildText("composition");
		residueMonoMass = Double.parseDouble(element.getChildText("mono_mass"));
		residueAvgMass = Double.parseDouble(element
				.getChildText("average_mass"));

		freq = Double.parseDouble(element.getChildText("frequency"));
	}

	/** Get amino acid composition. */
	public String getAcidComposition() {
		return acidComposition;
	}

	/** Get amino acid frequency. */
	public double getAcidFreq() {
		return freq;
	}

	/** Get residue average mass. */
	public double getResidueAvgMass() {
		return residueAvgMass;
	}

	/** Get residue monoisotopic mass. */
	public double getResidueMonoMass() {
		return residueMonoMass;
	}

	/** Get amino acid name. */
	public String getName() {
		return name;
	}

	/** Get amino acid one letter representation. */
	public String getOneLetter() {
		return oneLetter;
	}

	/** Get amino acid three letter representation. */
	public String getThreeLetter() {
		return threeLetter;
	}
}
