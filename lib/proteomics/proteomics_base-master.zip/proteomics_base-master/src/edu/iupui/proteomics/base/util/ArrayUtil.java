package edu.iupui.proteomics.base.util;

public class ArrayUtil {
	
	/** Calculate the sum of an array of numbers */
	public static double getSum (double elements[]) {
		double sum = 0.0;
		for (int i = 0; i < elements.length; i++) {
			sum = sum + elements[i];
		}
		return sum;
	}
	/** Convert an array of double values to integer values */
	public static int[] toIntegers (double elements[], double convertRatio) {
		int results[] = new int[elements.length];
		for (int i = 0; i < results.length; i++) {
			results[i] = (int) Math.round(elements[i] * convertRatio);
		}
		return results;
	}

}
