/**
 * Class for post translational modifications (PTMs).
 *
 * @author  Xiaowen Liu
 * @date    2009-8-25
 * @version 1.0
 */

package edu.iupui.proteomics.base.residue;

public class Ptm {
    /** Abbreviation name */
    private String abbrName;
	/** Monoisotopic mass */
    private double monoMass;
    /** A set of amino acid residues the PTM can apply */
    private Acid[] validAcids;
    /** Is it an empty ptm */
    private boolean isEmpty;
    
    public Ptm (String abbrName, double mass, Acid[] validAcids, boolean isEmpty) {
        this.abbrName = abbrName;
        this.monoMass = mass;
        this.validAcids = validAcids;
        this.isEmpty = isEmpty;
    }
 
    /** Returns PTM abbreviation name. */
    public String getAbbrName() {
		return abbrName;
	}

    /** Returns PTM monoisotopic mass. */
    public double getMonoMass()      {
		return monoMass;
	}
    
    /** Returns a list of amino acid residues the PTM can apply */
    public Acid[] getValidAcids() {
        return validAcids;
    }
 
    /** Returns true if it is the empty PTM */
    public boolean isEmpty()    {
    	return isEmpty;
    }
}
    
