/**
 * Implements several utility functions for MsAlignSeq operation.
 *
 * @author  Xiaowen Liu
 * @date    2009-8-26
 */

package edu.iupui.proteomics.base.theosp;

public class BpSpecUtil {
	public static int getFirstResPos(double nTermShift, double[] extBMasses) {
		double truncLen = -nTermShift;
		int bestPos = -1;
		double bestShift = Float.POSITIVE_INFINITY;
		for (int i = 0; i < extBMasses.length; i++) {
			if (Math.abs(extBMasses[i] - truncLen) < bestShift) {
				bestPos = i;
				bestShift = Math.abs(extBMasses[i] - truncLen);
			}
		}
		return bestPos;
	}

	public static int getLastResPos(double cTermShift, double[] extBMasses)
			throws Exception {
		double truncLen = -cTermShift;
		int bestPos = -1;
		double bestShift = Float.POSITIVE_INFINITY;
		double pepMass = extBMasses[extBMasses.length - 1];
		for (int i = 0; i < extBMasses.length; i++) {
			if (Math.abs(pepMass - extBMasses[i] - truncLen) < bestShift) {
				bestPos = i;
				bestShift = Math.abs(pepMass - extBMasses[i] - truncLen);
			}
		}
		/* we consider position based on letters */
		if (bestPos < 0) {
			throw new Exception("get last residue postion error!");
		}
		return bestPos - 1;
	}
}

///**
//* Returns get an array of matched breakage points given two peptides.
//* 
//* @param a
//*            The first MsAlignSeq.
//* 
//* @param b
//*            The second MsAlignSeq.
//* 
//* @param tolerance
//*            The error tolerance for two mass values.
//* 
//* @return An array of pointers. If result[i] = -1, then the ith breakage
//*         point in sequence "a" has no matching breakage points in sequence
//*         "b". If result[i] = j, then the ith breakage point in sequence
//*         "a" is matched to the jth breakage points in sequence "b".
//*/
//private static int[] getBrkMatch(BpSpec a, BpSpec b,
//		double tolerance) {
//	// we use extended break point list
//	BreakPoint[] brksA = a.getExtBps();
//	BreakPoint[] brksB = b.getExtBps();
//	int[] result = new int[brksA.length];
//	Arrays.fill(result, -1);
//	/* a pointer and b pointer */
//	int ap = 0;
//	int bp = 0;
//	while (ap < brksA.length && bp < brksB.length) {
//		if (Math.abs(brksA[ap].getPrm() - brksB[bp].getPrm()) <= tolerance) {
//			result[ap] = bp;
//			ap++;
//			bp++;
//		} else if (brksA[ap].getPrm() <= brksB[bp].getPrm()) {
//			ap++;
//		} else {
//			bp++;
//		}
//	}
//	return result;
//}

///**
//* Returns the number of matched breakage points given two MsAlignSeq
//* peptides.
//* 
//* @param a
//*            The first MsAlignSeq.
//* 
//* @param b
//*            The second MsAlignSeq.
//* 
//* @param tolerance
//*            The error tolerance for two mass values.
//* 
//* @return The number of matched breakage points.
//*/
//public static int getBrkMatchNum(BpSpec a, BpSpec b,
//		double tolerance) {
//	int[] matches = getBrkMatch(a, b, tolerance);
//	int cnt = 0;
//	for (int i = 0; i < matches.length; i++) {
//		if (matches[i] >= 0) {
//			cnt++;
//		}
//	}
//	return cnt;
//}
//
///**
//* Returns the boolean array of matched residues given two peptides.
//* 
//* @param a
//*            The first MsAlignSeq.
//* 
//* @param b
//*            The second MsAlignSeq.
//* 
//* @param err_tol
//*            The error tolerance for two mass values.
//* 
//* @return A boolean array. If result[i] = true, then the ith residue in
//*         SpPep "a" has a matching residue in SpPep "b". Otherwise,
//*         result[i] = false.
//*/
//public static boolean[] getResMatch(BpSpec a, BpSpec b,
//		double tolerance) {
//	int[] matches = getBrkMatch(a, b, tolerance);
//	boolean[] result = new boolean[a.getResSeq().getLen()];
//	Arrays.fill(result, false);
//	/* check the middle residues */
//	for (int i = 0; i < matches.length - 1; i++) {
//		if (matches[i] >= 0 && matches[i + 1] >= 0) {
//			if (matches[i + 1] == matches[i] + 1) {
//				result[i] = true;
//			}
//		}
//	}
//	return result;
//}
//
///**
//* Returns the number of matched residues given two peptides
//* 
//* @param a
//*            The first MsAlignSeq.
//* 
//* @param b
//*            The second MsAlignSeq.
//* 
//* @param tolerance
//*            The error tolerance for two mass values.
//* 
//* @return The number of matched residues.
//*/
//public static int getResMatchNum(BpSpec a, BpSpec b,
//		double tolerance) {
//	boolean[] matches = getResMatch(a, b, tolerance);
//	int cnt = 0;
//	for (int i = 0; i < matches.length; i++) {
//		if (matches[i]) {
//			cnt++;
//		}
//	}
//	return cnt;
//}
//
///**
//* Checks if two peptides have a matched sub-peptide with a given length.
//* 
//* @param a
//*            The first MsAlignSeq.
//* 
//* @param b
//*            The second MsAlignSeq.
//* 
//* @param tolerance
//*            The error tolerance for two mass values.
//* 
//* @param len
//*            The threshold for the length of matched peptide.
//* 
//* @return Returns TRUE if there is a matched sub-peptide with length "len".
//*         Otherwise, FALSE.
//*/
//public static boolean isExistTag(BpSpec a, BpSpec b,
//		double tolerance, int len) {
//	boolean[] matches = getResMatch(a, b, tolerance);
//	int best_len = 0;
//	for (int i = 0; i < matches.length; i++) {
//		if (matches[i]) {
//			best_len++;
//		} else {
//			best_len = 0;
//		}
//		if (best_len >= len) {
//			return true;
//		}
//	}
//	return false;
//}
//
///**
//* Returns the number of matched breakage points given three peptides
//* 
//* @param a
//*            The first MsAlignSeq.
//* 
//* @param b
//*            The second MsAlignSeq.
//* 
//* @param c
//*            The third MsAlignSeq.
//* 
//* @param tolerance
//*            The error tolerance for two mass values.
//* 
//* @return The number of matched breakage points.
//*/
//public static int getBrkMatchNum(BpSpec a, BpSpec b, BpSpec c,
//		double tolerance) {
//	BreakPoint[] brksA = a.getExtBps();
//	BreakPoint[] brksB = b.getExtBps();
//	BreakPoint[] brksC = c.getExtBps();
//	int cnt = 0;
//	/* a , b, c pointers */
//	int ap, bp, cp;
//	ap = bp = cp = 0;
//	while (ap < brksA.length && bp < brksB.length && cp < brksC.length) {
//
//		if (Math.abs(brksA[ap].getPrm() - brksB[bp].getPrm()) <= tolerance
//				&& Math.abs(brksA[ap].getPrm() - brksC[cp].getPrm()) <= tolerance) {
//			cnt++;
//			ap++;
//			bp++;
//			cp++;
//		} else if (brksA[ap].getPrm() <= brksB[bp].getPrm()
//				&& brksA[ap].getPrm() <= brksC[cp].getPrm()) {
//			ap++;
//		} else if (brksB[bp].getPrm() <= brksC[cp].getPrm()) {
//			bp++;
//		} else {
//			cp++;
//		}
//	}
//	return cnt;
//}
