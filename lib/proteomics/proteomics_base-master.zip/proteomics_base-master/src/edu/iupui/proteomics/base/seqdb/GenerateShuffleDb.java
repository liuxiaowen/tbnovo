/**
 * @author  Xiaowen Liu
 */

package edu.iupui.proteomics.base.seqdb;

import java.util.ArrayList;
import java.util.Random;
import java.io.File;
import java.io.PrintWriter;


public class GenerateShuffleDb {
	static Random rand = new Random(1);

	public static void setRandomSeed(int seed) {
		rand = new Random(seed);
	}

	/** shuttle protein sequence */
	public static String randomizeAllSeq(String seq) {
		char[] aa = new char[seq.length()];
		for (int i = 0; i < seq.length(); i++) {
			aa[i] = seq.charAt(i);
		}

		String rand_seq = "";
		for (int cnt = seq.length(); cnt > 0; cnt--) {
			int pos = rand.nextInt(cnt);
			rand_seq = rand_seq + aa[pos];
			for (int j = pos; j < cnt - 1; j++) {
				aa[j] = aa[j + 1];
			}
		}
		return rand_seq;
	}

	/** shuttle protein sequence */
	public static String randomizeKeepN(String seq) {
		char[] aa = new char[seq.length()];
		for (int i = 0; i < seq.length(); i++) {
			aa[i] = seq.charAt(i);
		}
		if (seq.length() < 2) {
			return seq;
		}

		String rand_seq = "";
		/* keep the first two N-terminal amino acids */
		rand_seq = rand_seq + aa[0] + aa[1];
		for (int j = 0; j < seq.length() - 2; j++) {
			aa[j] = aa[j + 2];
		}
		for (int cnt = seq.length() - 2; cnt > 0; cnt--) {
			int pos = rand.nextInt(cnt);
			rand_seq = rand_seq + aa[pos];
			for (int j = pos; j < cnt - 1; j++) {
				aa[j] = aa[j + 1];
			}
		}
		return rand_seq;
	}

	/** initialize sequence list */
	public static void generate(String fileName, String targetDecoyFileName)
			throws Exception {

		FastaSeqReader reader = new FastaSeqReader(new File(fileName));

		ArrayList<String[]> proteins = new ArrayList<String[]>();
		String info[];
		while ((info = reader.getNextSeq()) != null) {
			proteins.add(info);
		}
		PrintWriter writer = new PrintWriter(targetDecoyFileName);
		for (int i = 0; i < proteins.size(); i++) {
			writer.println(">" + "DECOY_" + proteins.get(i)[0]);
			writer.println(randomizeKeepN(proteins.get(i)[1]));
			writer.println(">" + proteins.get(i)[0]);
			writer.println(proteins.get(i)[1]);
		}
		writer.close();
	}
}
