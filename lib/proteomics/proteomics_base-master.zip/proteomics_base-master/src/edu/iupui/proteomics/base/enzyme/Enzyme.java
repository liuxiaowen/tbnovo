package edu.iupui.proteomics.base.enzyme;

import edu.iupui.proteomics.base.residue.Acid;

public class Enzyme {
	private String name;
	private Acid lp1[];
	private Acid rp1[];
	
	public Enzyme (String name, Acid lp1[], Acid rp1[]) {
		this.setName(name);
		this.setLp1(lp1);
		this.setRp1(rp1);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Acid[] getLp1() {
		return lp1;
	}

	public void setLp1(Acid lp1[]) {
		this.lp1 = lp1;
	}

	public Acid[] getRp1() {
		return rp1;
	}

	public void setRp1(Acid rp1[]) {
		this.rp1 = rp1;
	}

}
