package edu.iupui.proteomics.base.util;

import java.lang.Math;
import java.util.Arrays;
import java.util.ArrayList;

public class BioArray {

    public static int search(double[] arr, double val) {
        int rank = Arrays.binarySearch(arr, val);
        if (rank < 0) {
            rank = -rank - 1;
        }
        return rank;
    }

    public static int getMaxPos(float[] scores) {
        int maxPos = -1;
        float maxScore = Float.NEGATIVE_INFINITY;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > maxScore) {
                maxScore = scores[i];
                maxPos = i;
            }
        }
        return maxPos;
    }

    public static double getMax(double[] scores) {
        double maxScore = Float.NEGATIVE_INFINITY;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > maxScore) {
                maxScore = scores[i];
            }
        }
        return maxScore;
    }

    public static int getMaxPos(double[] scores) {
        int maxPos = -1;
        double maxScore = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > maxScore) {
                maxScore = scores[i];
                maxPos = i;
            }
        }
        return maxPos;
    }

    public static int getMax(int[] scores) {
        int maxScore = Integer.MIN_VALUE;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > maxScore) {
                maxScore = scores[i];
            }
        }
        return maxScore;
    }

    public static float getSum(float s[][]) {
        float sum;
        int i, j;
        sum = 0;
        for (i = 0; i < s.length; i++) {
            for (j = 0; j < s[i].length; j++) {
                sum += s[i][j];
            }
        }
        return sum;
    }

    public static float getSum(float s[]) {
        float sum;
        int i;
        sum = 0;
        for (i = 0; i < s.length; i++) {
            sum += s[i];
        }
        return sum;
    }

    public static double getSum(double s[]) {
        double sum;
        int i;
        sum = 0;
        for (i = 0; i < s.length; i++) {
            sum += s[i];
        }
        return sum;
    }

    public static int getSum(int s[]) {
        int sum;
        int i;
        sum = 0;
        for (i = 0; i < s.length; i++) {
            sum += s[i];
        }
        return sum;
    }

    /** get inner product */
    public static double innerProd(float[] a, float[] b) {
        int i;
        double innerScore;
        innerScore = 0.0f;
        for (i = 0; i < a.length; i++) {
            innerScore = innerScore + a[i] * b[i];
        }
        return innerScore;
    }

    /** get cosin angle */
    public static double cosinAngle(float[] a, float[] b) {
        int i;
        double aScore, bScore, innerScore;
        aScore = bScore = innerScore = 0.0;
        for (i = 0; i < a.length; i++) {
            aScore = aScore + a[i] * a[i];
            bScore = bScore + b[i] * b[i];
            innerScore = innerScore + a[i] * b[i];
        }
        if (aScore == 0 || bScore == 0) {
            return 0.0;
        } else {
            return innerScore / Math.sqrt(aScore * bScore);
        }
    }

    /** convert list to an array */
    public static float[] cnvtFloatList(ArrayList<Float> list) {
        float result[] = new float[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i).floatValue();
        }
        return result;
    }

    /** convert list to an array */
    public static double[] cnvtDoubleList(ArrayList<Double> list) {
        double result[] = new double[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i).doubleValue();
        }
        return result;
    }

    /** convert list to an array */
    public static int[] cnvtIntegerList(ArrayList<Integer> list) {
        int result[] = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = ((Integer) list.get(i)).intValue();
        }
        return result;
    }
}
