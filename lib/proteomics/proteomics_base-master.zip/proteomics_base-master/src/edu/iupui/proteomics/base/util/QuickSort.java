package edu.iupui.proteomics.base.util;

import java.util.LinkedList;

public class QuickSort {

    public static void sortOnFirst(double[] a, double[] b) {
        if (a.length == 0) {
            return;
        }
        quickSort(a, b, 0, a.length - 1);
    }

    /* quicksort a[left] to a[right] */
    public static void quickSortA(double[] a, double[] b, int left, int right) {

        for (int i = left; i <= right; i++) {
            for (int j = i + 1; j <= right; j++) {
                if (a[i] > a[j]) {
                    exch(a, b, i, j);
                }
            }
        }
    }

    /* quicksort a[left] to a[right] */
    public static void quickSort(double[] a, double[] b, int left, int right) {

        LinkedList<Integer> leftList = new LinkedList<Integer>();
        LinkedList<Integer> rightList = new LinkedList<Integer>();
        leftList.add(left);
        rightList.add(right);
        while (leftList.size() > 0) {
            left = leftList.removeLast();
            right = rightList.removeLast();
            if (left < right) {
                int i = partition(a, b, left, right);
                leftList.add(left);
                rightList.add(i - 1);
                leftList.add(i + 1);
                rightList.add(right);
            }
        }
    }

    /* partition a[left] to a[right], assumes left < right */
    private static int partition(double[] a, double[] b, int left, int right) {

        int i = left - 1;
        int j = right;
        while (true) {
            /* find item on left to swap a[right] acts as sentinel */
            while (a[++i] < a[right])
                ;
            /* find item on right to swap */
            while (a[right] < a[--j]) {
                /* don't go out-of-bounds */
                if (j == left)
                    break;
            }
            /* check if pointers cross */
            if (i >= j)
                break;
            /* swap two elements into place */
            exch(a, b, i, j);
        }
        /* swap with partition element */
        exch(a, b, i, right);
        return i;
    }

    /* exchange */
    private static void exch(double[] a, double[] b, int i, int j) {
        double swap;
        double b_swap;
        swap = a[i];
        a[i] = a[j];
        a[j] = swap;
        b_swap = b[i];
        b[i] = b[j];
        b[j] = b_swap;
    }

    public static void sortOnFirst(double[] a, int[] b) {
        quickSort(a, b, 0, a.length - 1);
    }

    /* quicksort a[left] to a[right] */
    public static void quickSort(double[] a, int[] b, int left, int right) {
        LinkedList<Integer> leftList = new LinkedList<Integer>();
        LinkedList<Integer> rightList = new LinkedList<Integer>();
        leftList.add(left);
        rightList.add(right);
        while (leftList.size() > 0) {
            left = leftList.removeLast();
            right = rightList.removeLast();
            if (left < right) {
                int i = partition(a, b, left, right);
                leftList.add(left);
                rightList.add(i - 1);
                leftList.add(i + 1);
                rightList.add(right);
            }
        }
    }

    /* partition a[left] to a[right], assumes left < right */
    private static int partition(double[] a, int[] b, int left, int right) {
        int i = left - 1;
        int j = right;
        while (true) {
            /* find item on left to swap a[right] acts as sentinel */
            while (a[++i] < a[right])
                ;
            /* find item on right to swap */
            while (a[right] < a[--j]) {
                /* don't go out-of-bounds */
                if (j == left)
                    break;
            }
            /* check if pointers cross */
            if (i >= j)
                break;
            /* swap two elements into place */
            exch(a, b, i, j);
        }
        /* swap with partition element */
        exch(a, b, i, right);
        return i;
    }

    /* exchange */
    private static void exch(double[] a, int[] b, int i, int j) {
        double swap;
        int b_swap;
        swap = a[i];
        a[i] = a[j];
        a[j] = swap;
        b_swap = b[i];
        b[i] = b[j];
        b[j] = b_swap;
    }

    public static void sortOnFirst(int[] a, int[] b) {
        quickSort(a, b, 0, a.length - 1);
    }

    /* quicksort a[left] to a[right] */
    public static void quickSort(int[] a, int[] b, int left, int right) {
        LinkedList<Integer> leftList = new LinkedList<Integer>();
        LinkedList<Integer> rightList = new LinkedList<Integer>();
        leftList.add(left);
        rightList.add(right);
        while (leftList.size() > 0) {
            left = leftList.removeLast();
            right = rightList.removeLast();
            if (left < right) {
                int i = partition(a, b, left, right);
                leftList.add(left);
                rightList.add(i - 1);
                leftList.add(i + 1);
                rightList.add(right);
            }
        }
    }

    /* partition a[left] to a[right], assumes left < right */
    private static int partition(int[] a, int[] b, int left, int right) {
        int i = left - 1;
        int j = right;
        while (true) {
            /* find item on left to swap a[right] acts as sentinel */
            while (a[++i] < a[right])
                ;
            /* find item on right to swap */
            while (a[right] < a[--j]) {
                /* don't go out-of-bounds */
                if (j == left)
                    break;
            }
            /* check if pointers cross */
            if (i >= j)
                break;
            /* swap two elements into place */
            exch(a, b, i, j);
        }
        /* swap with partition element */
        exch(a, b, i, right);
        return i;
    }

    /* exchange */
    private static void exch(int[] a, int[] b, int i, int j) {
        int swap;
        int b_swap;
        swap = a[i];
        a[i] = a[j];
        a[j] = swap;
        b_swap = b[i];
        b[i] = b[j];
        b[j] = b_swap;
    }

    public static void sortOnFirst(int[] a, float[] b) {
        quickSort(a, b, 0, a.length - 1);
    }

    /* quicksort a[left] to a[right] */
    public static void quickSort(int[] a, float[] b, int left, int right) {
        LinkedList<Integer> leftList = new LinkedList<Integer>();
        LinkedList<Integer> rightList = new LinkedList<Integer>();
        leftList.add(left);
        rightList.add(right);
        while (leftList.size() > 0) {
            left = leftList.removeLast();
            right = rightList.removeLast();
            if (left < right) {
                int i = partition(a, b, left, right);
                leftList.add(left);
                rightList.add(i - 1);
                leftList.add(i + 1);
                rightList.add(right);
            }
        }

    }

    /* partition a[left] to a[right], assumes left < right */
    private static int partition(int[] a, float[] b, int left, int right) {
        int i = left - 1;
        int j = right;
        while (true) {
            /* find item on left to swap a[right] acts as sentinel */
            while (a[++i] < a[right])
                ;
            /* find item on right to swap */
            while (a[right] < a[--j]) {
                /* don't go out-of-bounds */
                if (j == left)
                    break;
            }
            /* check if pointers cross */
            if (i >= j)
                break;
            /* swap two elements into place */
            exch(a, b, i, j);
        }
        /* swap with partition element */
        exch(a, b, i, right);
        return i;
    }

    /* exchange */
    private static void exch(int[] a, float[] b, int i, int j) {
        int swap;
        float b_swap;
        swap = a[i];
        a[i] = a[j];
        a[j] = swap;
        b_swap = b[i];
        b[i] = b[j];
        b[j] = b_swap;
    }

    public static void main(String[] args) {
        double a[] = new double[100];
        double b[] = new double[100];
        for (int i = 0; i < a.length; i++) {
            a[i] = 100 - i;
            b[i] = i;
        }
        sortOnFirst(a, b);
        for (int i = 0; i < a.length; i++) {
            System.out.println("a " + a[i] + " b " + b[i]);
        }

    }
}
