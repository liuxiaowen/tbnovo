package edu.iupui.proteomics.base.residue;

import java.util.ArrayList;

public class PtmUtil {
    
	/**
	 * Return an array of valid acids of a list of ptms. 
	 */
    public static Acid[] getValidAcids(Ptm ptms[]) {
        ArrayList<Acid> acidList = new ArrayList<Acid>();
        for (int i = 0; i < ptms.length; i++) {
            Acid acids[] = ptms[i].getValidAcids();
            for (int j = 0; j < acids.length; j++) {
                if (!acidList.contains(acids[j])) {
                    acidList.add(acids[j]);
                }
            }
        }
        return acidList.toArray(new Acid[0]);
    }
}
