package edu.iupui.proteomics.base.residue;


public class ResFreq extends Res {
	
	private double freq;
	
	public ResFreq(Acid acid, Ptm ptm, double freq) {
		super(acid, ptm);
		this.freq = freq;
	}
	
	public double getFreq() {
		return freq;
	}
	
	public void setFreq(double freq) {
		this.freq = freq;
	}
}
