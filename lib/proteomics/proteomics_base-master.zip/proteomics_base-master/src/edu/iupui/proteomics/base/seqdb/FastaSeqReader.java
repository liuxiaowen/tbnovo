package edu.iupui.proteomics.base.seqdb;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class FastaSeqReader {
	    BufferedReader input;
	    String oriName;

	    /**
	     * Constructs an instance with a File.
	     */
	    public FastaSeqReader(File proteinDatabase) throws Exception {
	        input = new BufferedReader(new InputStreamReader(new FileInputStream(
	                proteinDatabase), "UTF-8"));
	        oriName = input.readLine();
	    }

	    /**
	     * Read FASTA file and return next protein name and sequence. result[0] is
	     * protein name and result[1] is sequence.
	     */
	    public String[] getNextSeq() throws Exception {
	        if (input == null) {
	            return null;
	        }

	        /* get the letters of sequence */
	        String oriSeq = "";
	        String protName = oriName.substring(1);
	        String line;
	        while ((line = input.readLine()) != null) {
	            if (line.length() >= 1 && line.charAt(0) == '>') {
	                oriName = line;
	                return FastaPreprocess.process(protName, oriSeq);
	            }
	            oriSeq = oriSeq + line.trim();
	        }
	        input.close();
	        input = null;
	        return FastaPreprocess.process(protName, oriSeq);
	    }
}
